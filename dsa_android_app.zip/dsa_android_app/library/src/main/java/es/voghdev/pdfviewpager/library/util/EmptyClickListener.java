package es.voghdev.pdfviewpager.library.util;

import android.view.View;

public class EmptyClickListener implements View.OnClickListener {
    @Override
    public void onClick(View view) {
        /* Empty */
    }
}
