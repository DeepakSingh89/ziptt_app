package com.ziploan.dsaapp.utils;

import java.util.List;

import com.ziploan.dsaapp.model.ZiploanPhoto;

public interface LoadPhotoListener {
    public void getImages(ZiploanPhoto arrImages, int sourceType);
    public void processingImages();
}
