package com.ziploan.dsaapp.viewmodel.details;

import android.content.Context;
import android.graphics.Point;
import android.os.Bundle;
import android.text.TextUtils;
import android.util.Log;
import android.view.View;
import android.view.ViewGroup;
import android.view.ViewParent;
import android.widget.ScrollView;
import android.widget.SeekBar;

import com.warkiz.widget.IndicatorSeekBar;

import java.util.ArrayList;
import java.util.List;

import androidx.databinding.Observable;
import androidx.databinding.ObservableBoolean;
import androidx.databinding.ObservableField;
import com.ziploan.dsaapp.MyApplication;
import com.ziploan.dsaapp.R;
import com.ziploan.dsaapp.base.BaseViewModel;
import com.ziploan.dsaapp.base.extras.network.APIExecutor;
import com.ziploan.dsaapp.fragments.details.BusinessDetailsFragment;
import com.ziploan.dsaapp.fragments.details.CoApplicantFragment;
import com.ziploan.dsaapp.fragments.details.DocumentUploadDetailsFragment;
import com.ziploan.dsaapp.fragments.home.SuccessFragment;
import com.ziploan.dsaapp.model.header.HeaderModel;
import com.ziploan.dsaapp.model.request.BusinessInfoRequest;
import com.ziploan.dsaapp.model.response.business_info.BusinessInfoResponse;
import com.ziploan.dsaapp.model.response.personal.get_personal.GetPersonalInfoResponse;
import com.ziploan.dsaapp.model.response.pincode.PincodeResponse;
import com.ziploan.dsaapp.utils.CommonUtils;
import com.ziploan.dsaapp.utils.Constant;
import com.ziploan.dsaapp.utils.NavController;
import com.ziploan.dsaapp.utils.permissons.PermissionConstant;
import retrofit2.Call;
import retrofit2.Callback;
import retrofit2.Response;

public class BusinessDetailsViewModel extends BaseViewModel{
    public ObservableField<String> BusinessName = new ObservableField<>();
    public ObservableField<String> PanNumber = new ObservableField<>();
    public ObservableBoolean PanEnable = new ObservableBoolean(true);
    public ObservableBoolean AddressEnable = new ObservableBoolean(true);
    public ObservableBoolean PincodeEnable = new ObservableBoolean(true);

    public ObservableField<String> BusinessAddress = new ObservableField<>();
    public ObservableField<String> Pincode = new ObservableField<>();
    public ObservableField<String> City = new ObservableField<>();
    public ObservableField<String> State = new ObservableField<>();

    public ObservableBoolean SelfOwnedSelected = new ObservableBoolean(false);
    public ObservableBoolean RentedSelected = new ObservableBoolean(false);
    public ObservableBoolean SolePropSelected = new ObservableBoolean(false);
    public ObservableBoolean PartnershipSelected = new ObservableBoolean(false);
    public ObservableBoolean CompanySelected = new ObservableBoolean(false);
    public ObservableBoolean LLPSelected = new ObservableBoolean(false);
    public ObservableBoolean OnePersonSelected = new ObservableBoolean(false);
    public ObservableBoolean SameAsResident = new ObservableBoolean(false);
    public ObservableBoolean BusinessTypeError = new ObservableBoolean(false);
    private String business_type = "";
    private String residentialPlaceOwnership;
    private boolean validPincode;
    private int margine;
    private boolean callPatch;
    private String panNumber;
    private com.ziploan.dsaapp.model.response.personal.get_personal.Response PersonalInfoData;
    private com.ziploan.dsaapp.model.response.form_config.Response formResponse;

    public ObservableField<HeaderModel> headerModelObservableField = new ObservableField<>();
    private String loan_req_id;
    private IndicatorSeekBar seekbar;

    private Context context;

    public ObservableBoolean BusinessNameInvalid = new ObservableBoolean();
    public ObservableField<String> BusinessNameInvalidText = new ObservableField<>();
    public ObservableBoolean BusinessPanInvalid = new ObservableBoolean();
    public ObservableField<String> BusinessPanInvalidText = new ObservableField<>();

    public ObservableBoolean BusniessAddressInvalid = new ObservableBoolean();
    public ObservableField<String> BusinessAddressInvalidText = new ObservableField<>();
    public ObservableBoolean PincodeInvalid = new ObservableBoolean();
    public ObservableField<String> PincodeInvalidText = new ObservableField<>();


    public BusinessDetailsViewModel(Bundle bundle, Context context){
        this.context = context;
        if(bundle != null){
            loan_req_id = bundle.getString("loan_req_id");
//            seNumOfPages(bundle.getInt("num_of_pages"));
        }
        if(MyApplication.formResponse != null)
            getFormConfigResponse(MyApplication.formResponse);
        else
            headerModelObservableField.set(HeaderModel.setForBusiness());
        getProductInfo(loan_req_id);
        getBusinessInfo(loan_req_id);

        Observable.OnPropertyChangedCallback onPropertyChangedCallback = new Observable.OnPropertyChangedCallback() {
            @Override
            public void onPropertyChanged(Observable sender, int propertyId) {
                if(SameAsResident.get()){
                    showResident();
                } else {
                    hideResident();
                }
            }
        };

        SameAsResident.addOnPropertyChangedCallback(onPropertyChangedCallback);
    }

    public void setPanNumber(String panNumber){
        this.panNumber = panNumber;
    }

    public void seNumOfPages(){
//        if(numOfPages > 3){
//            headerModelObservableField.set(HeaderModel.setForBusinessWithCoApplicant());
//        } else if(numOfPages == 3){
//            headerModelObservableField.set(HeaderModel.setForBusiness());
//        }
        reqFormConfig(loan_req_id);
    }

    public void onClick(View view, BusinessDetailsFragment businessDetailsFragment) {
        switch (view.getId()){
            case R.id.business_save_btn:
                reset();
                if(canSubmit(businessDetailsFragment)){
                    showLoading(businessDetailsFragment.getContext());
                    postBusinessInfo(businessDetailsFragment);
                }
                break;
            case R.id.sole:
                business_type = "sole_proprietorship";
                if(PersonalInfoData != null
                        && !TextUtils.isEmpty(PersonalInfoData.getPan())){
                    PanNumber.set(PersonalInfoData.getPan());
                    BusinessPanInvalid.set(false);
                    BusinessPanInvalidText.set("");
                    PanEnable.set(false);
                } else if(!TextUtils.isEmpty(panNumber)){
                    PanNumber.set(panNumber);
                    BusinessPanInvalid.set(false);
                    BusinessPanInvalidText.set("");
                    PanEnable.set(false);
                }
                SolePropSelected.set(true);
                PartnershipSelected.set(false);
                CompanySelected.set(false);
                LLPSelected.set(false);
                OnePersonSelected.set(false);
//                headerModelObservableField.set(HeaderModel.setForBusiness());
//                resetTopOnTypeClick(MyApplication.formResponse);
                break;
            case R.id.partner:
                if(business_type.equalsIgnoreCase("sole_proprietorship")){
                    PanNumber.set("");
                }
                business_type = "partnership";
                PanEnable.set(true);
                SolePropSelected.set(false);
                PartnershipSelected.set(true);
                CompanySelected.set(false);
                LLPSelected.set(false);
                OnePersonSelected.set(false);
//                headerModelObservableField.set(HeaderModel.setForBusinessWithCoApplicant());
//                resetTopOnTypeClick(MyApplication.formResponse);
                break;
            case R.id.company:
                if(business_type.equalsIgnoreCase("sole_proprietorship")){
                    PanNumber.set("");
                }
                business_type = "company";
                PanEnable.set(true);
                SolePropSelected.set(false);
                PartnershipSelected.set(false);
                CompanySelected.set(true);
                LLPSelected.set(false);
                OnePersonSelected.set(false);
//                resetTopOnTypeClick(MyApplication.formResponse);
//                headerModelObservableField.set(HeaderModel.setForBusinessWithCoApplicant());
                break;
            case R.id.llp:
                if(business_type.equalsIgnoreCase("sole_proprietorship")){
                    PanNumber.set("");
                }
                business_type = "limited_liability_partnership";
                PanEnable.set(true);
                SolePropSelected.set(false);
                PartnershipSelected.set(false);
                CompanySelected.set(false);
                LLPSelected.set(true);
                OnePersonSelected.set(false);
//                resetTopOnTypeClick(MyApplication.formResponse);
//                headerModelObservableField.set(HeaderModel.setForBusinessWithCoApplicant());
                break;
            case R.id.one_person:
                if(business_type.equalsIgnoreCase("sole_proprietorship")){
                    PanNumber.set("");
                }
                business_type = "one_person_company";
                PanEnable.set(true);
                SolePropSelected.set(false);
                PartnershipSelected.set(false);
                CompanySelected.set(false);
                LLPSelected.set(false);
                OnePersonSelected.set(true);
//                resetTopOnTypeClick(MyApplication.formResponse);
//                headerModelObservableField.set(HeaderModel.setForBusiness());
                break;
            case R.id.self_owned:
                residentialPlaceOwnership = "self_owned";
                SelfOwnedSelected.set(true);
                RentedSelected.set(false);
                break;
            case R.id.rented:
                residentialPlaceOwnership = "rented";
                RentedSelected.set(true);
                SelfOwnedSelected.set(false);
                break;
        }
    }

    private void reset(){
        BusinessNameInvalid.set(false);
        BusinessNameInvalidText.set("");
        BusinessPanInvalid.set(false);
        BusinessPanInvalidText.set("");
        BusniessAddressInvalid.set(false);
        BusinessAddressInvalidText.set("");
        PincodeInvalid.set(false);
        PincodeInvalidText.set("");
        BusinessTypeError.set(false);
    }

    private boolean validatePan(){
        if(SolePropSelected.get()){
            return CommonUtils.validateSolePersonalPan(PanNumber.get());
        } else if(CompanySelected.get() || OnePersonSelected.get()){
            return CommonUtils.validateCompanyOnePersonPan(PanNumber.get(),BusinessName.get());
        } else if(LLPSelected.get() || PartnershipSelected.get()){
            return CommonUtils.validateLLPPartnershipPan(PanNumber.get(),BusinessName.get());
        }
        return false;
    }

    private boolean canSubmit(BusinessDetailsFragment fragment){
        Context context = fragment.getContext();
        boolean canSubmit = false;
        if(!TextUtils.isEmpty(business_type)) {
            if (!TextUtils.isEmpty(BusinessName.get())) {
                if (!TextUtils.isEmpty(PanNumber.get())) {
                    if (validatePan()) {
                        if (!TextUtils.isEmpty(BusinessAddress.get())) {
                            if (!TextUtils.isEmpty(Pincode.get())) {
                                if (validPincode) {
                                    if (!TextUtils.isEmpty(City.get())) {
                                        if (!TextUtils.isEmpty(State.get())) {
                                            if (margine > 0) {
                                                canSubmit = true;
                                            } else {
                                                scrollToView(fragment.getParentView().mainScroll, fragment.getParentView().indecativeseekbar);
                                                showToast(context, context.getString(R.string.select_business_marnie));
                                            }
                                        } else {
                                            showToast(context, context.getString(R.string.fill_state_name));
                                        }
                                    } else {
                                        showToast(context, context.getString(R.string.fill_city_name));
                                    }
                                } else {
                                    PincodeInvalid.set(true);
                                    PincodeInvalidText.set(context.getString(R.string.pincode_invalid));
                                }
                            } else {
                                PincodeInvalid.set(true);
                                PincodeInvalidText.set(context.getString(R.string.required_field));
                            }
                        } else {
                            BusniessAddressInvalid.set(true);
                            BusinessAddressInvalidText.set(context.getString(R.string.required_field));
                            scrollToView(fragment.getParentView().mainScroll, fragment.getParentView().businessAddress);
                        }
                    } else {
                        BusinessPanInvalid.set(true);
                        BusinessPanInvalidText.set(context.getString(R.string.pan_not_valid));
                        scrollToView(fragment.getParentView().mainScroll, fragment.getParentView().businessPan);
                    }
                } else {
                    BusinessPanInvalid.set(true);
                    BusinessPanInvalidText.set(context.getString(R.string.required_field));
                    scrollToView(fragment.getParentView().mainScroll, fragment.getParentView().businessPan);
                }
            } else {
                BusinessNameInvalid.set(true);
                BusinessNameInvalidText.set(context.getString(R.string.required_field));
                scrollToView(fragment.getParentView().mainScroll, fragment.getParentView().businessName);
            }
        } else {
            BusinessTypeError.set(true);
            scrollToView(fragment.getParentView().mainScroll, fragment.getParentView().businessTypeText);
        }
        return canSubmit;
    }

    private void postBusinessInfo(BusinessDetailsFragment businessDetailsFragment) {
        BusinessInfoRequest businessInfoRequest = new BusinessInfoRequest();
        businessInfoRequest.setLoanRequestId(loan_req_id);

        if(MyApplication.formResponse != null)
            businessInfoRequest.setApplicationType(MyApplication.formResponse.getApplicationType());
        else
            businessInfoRequest.setApplicationType(Constant.EDIT_APPLICATION_TYPE);
        businessInfoRequest.setBusinessAddress(BusinessAddress.get());
        businessInfoRequest.setBusinessName(BusinessName.get());
        businessInfoRequest.setBusinessPanNo(PanNumber.get());
        businessInfoRequest.setCity(City.get());
        businessInfoRequest.setState(State.get());
        businessInfoRequest.setPincode(Pincode.get());
        businessInfoRequest.setBusinessPlaceOwnership(residentialPlaceOwnership);
        businessInfoRequest.setEntityTypeName(business_type);
        businessInfoRequest.setSpecifiedMargin(margine);

        Call<BusinessInfoResponse> businessInfoResponseCall;

        if(formResponse != null
                && formResponse.getBusinessInfoFilled())
            businessInfoResponseCall = APIExecutor.getAPIService().patchBusinessInfo(businessInfoRequest);
        else
            businessInfoResponseCall = APIExecutor.getAPIService().postBusinessInfo(businessInfoRequest);

        businessInfoResponseCall.enqueue(new Callback<BusinessInfoResponse>() {
            @Override
            public void onResponse(Call<BusinessInfoResponse> call, Response<BusinessInfoResponse> response) {
                if (response.isSuccessful()
                        && response.body() != null) {
                    if (response.body().getStatus().equalsIgnoreCase(Constant.SUCCESS)) {
                        if(!TextUtils.isEmpty(response.body().getApplicationStatus())
                                    && response.body().getApplicationStatus().equalsIgnoreCase(Constant.REJECTED)){
                            NavController.getInstance().addFragment(SuccessFragment.newInstance(false), true);
                            hideLoading();
                        } else {
                            reqFormConfigForNavigation(MyApplication.LOAN_REQ_ID);
                        }
                    } else {
                        try {
                            if (response.body().getResponse().getBusinessPanNo() != null) {
                                List<String> panError = (ArrayList<String>) response.body().getResponse().getBusinessPanNo();
                                if (panError != null) {
                                    BusinessPanInvalid.set(true);
                                    BusinessPanInvalidText.set(context.getString(R.string.pan_not_valid));
                                    scrollToView(businessDetailsFragment.getParentView().mainScroll, businessDetailsFragment.getParentView().businessPan);
                                }
                            }
                        } catch (Exception e){}
                        showToast(context,response.body().getStatusMessage());
                        hideLoading();
                    }
                } else {
                    hideLoading();
                }
            }

            @Override
            public void onFailure(Call<BusinessInfoResponse> call, Throwable t) {

            }
        });
    }

    @Override
    protected void getFormConfigResponseForNav(com.ziploan.dsaapp.model.response.form_config.Response response) {
        hideLoading();
        if (business_type.equalsIgnoreCase("sole_proprietorship") || business_type.equalsIgnoreCase("one_person_company")) {
            NavController.getInstance()
                    .addFragment(DocumentUploadDetailsFragment.newInstance(loan_req_id), true);
        } else {
            NavController.getInstance()
                    .addFragment(CoApplicantFragment.newInstance(loan_req_id), true);
        }
    }

    public void setPincode(String pincode){
//        if(SameAsResident.get()){
//            SameAsResident.set(false);
//        }
        checkPincode(pincode);
    }

    private void checkPincode(String pincode){
        Call<PincodeResponse> pincodeResponseCall = APIExecutor.getAPIService().checkPincode(pincode);
        pincodeResponseCall.enqueue(new Callback<PincodeResponse>() {
            @Override
            public void onResponse(Call<PincodeResponse> call, Response<PincodeResponse> response) {
                if(response.isSuccessful() && response.body().getStatus().equalsIgnoreCase(Constant.SUCCESS)){
                    validPincode = true;
                    City.set(response.body().getResponse().getCity().getValue());
                    State.set(response.body().getResponse().getState().getValue());
                } else {
                    if(response.body() != null) {
                        PincodeInvalidText.set(response.body().getStatusMessage());
                        PincodeInvalid.set(true);
                    }
                }
                hideLoading();
            }

            @Override
            public void onFailure(Call<PincodeResponse> call, Throwable t) {
                hideLoading();
                Log.d("failed",t.getMessage());
            }
        });
    }

    private void getBusinessInfo(String loan_req_id){
        showLoading(context);
        Call<BusinessInfoResponse> getPersonalInfoResponseCall = APIExecutor.getAPIService().getBusinessInfo(loan_req_id,Constant.PERSONAL_INFO_APPLICANT_TYPE,Constant.EDIT_APPLICATION_TYPE);
        getPersonalInfoResponseCall.enqueue(new Callback<BusinessInfoResponse>() {
            @Override
            public void onResponse(Call<BusinessInfoResponse> call, Response<BusinessInfoResponse> response) {
                if(response.isSuccessful() && response.body() != null && response.body().getResponse() != null){
                    callPatch = true;
                    fillbusinessInfoData(response.body().getResponse());
                }
                hideLoading();
            }

            @Override
            public void onFailure(Call<BusinessInfoResponse> call, Throwable t) {
                hideLoading();
                Log.d("failed",t.getMessage());
            }
        });
    }

    private void fillbusinessInfoData(com.ziploan.dsaapp.model.response.business_info.Response response) {
        if(response != null){
            BusinessName.set(response.getBusinessName());
            BusinessAddress.set(response.getBusinessAddress());
            if(response.getBusinessPanNo() != null)
                PanNumber.set(response.getBusinessPanNo().toString());
            Pincode.set(response.getPincode());
            validPincode = true;
            City.set(response.getCity());
            State.set(response.getState());
            if(Integer.parseInt(response.getSpecifiedMargin()) > 0){
                seekbar.setProgress(Integer.parseInt(response.getSpecifiedMargin()));
            }

            if(response.getBusinessPlaceOwnership() != null) {
                if (response.getBusinessPlaceOwnership().equalsIgnoreCase("rented")) {
                    RentedSelected.set(true);
                    SelfOwnedSelected.set(false);
                    residentialPlaceOwnership = "rented";
                } else if (response.getBusinessPlaceOwnership().equalsIgnoreCase("self_owned")) {
                    residentialPlaceOwnership = "self_owned";
                    SelfOwnedSelected.set(true);
                    RentedSelected.set(false);
                }
            }

            if(response.getEntityTypeName() != null) {
                if (response.getEntityTypeName().equalsIgnoreCase("partnership")) {
                    business_type = "partnership";
                    SolePropSelected.set(false);
                    PartnershipSelected.set(true);
                    CompanySelected.set(false);
                    LLPSelected.set(false);
                    OnePersonSelected.set(false);
//                    headerModelObservableField.set(HeaderModel.setForBusinessWithCoApplicant());
                } else if (response.getEntityTypeName().equalsIgnoreCase("sole_proprietorship")) {
                    business_type = "sole_proprietorship";
                    if(PersonalInfoData != null
                            && !TextUtils.isEmpty(PersonalInfoData.getPan())){
                        PanNumber.set(PersonalInfoData.getPan());
                    } else if(!TextUtils.isEmpty(panNumber)){
                        PanNumber.set(panNumber);
                    }
                    PanEnable.set(false);
                    SolePropSelected.set(true);
                    PartnershipSelected.set(false);
                    CompanySelected.set(false);
                    LLPSelected.set(false);
                    OnePersonSelected.set(false);
//                    headerModelObservableField.set(HeaderModel.setForBusiness());
                } else if (response.getEntityTypeName().equalsIgnoreCase("company")) {
                    business_type = "company";
                    SolePropSelected.set(false);
                    PartnershipSelected.set(false);
                    CompanySelected.set(true);
                    LLPSelected.set(false);
                    OnePersonSelected.set(false);
//                    headerModelObservableField.set(HeaderModel.setForBusinessWithCoApplicant());
                } else if (response.getEntityTypeName().equalsIgnoreCase("limited_liability_partnership")) {
                    business_type = "limited_liability_partnership";
                    SolePropSelected.set(false);
                    PartnershipSelected.set(false);
                    CompanySelected.set(false);
                    LLPSelected.set(true);
                    OnePersonSelected.set(false);
//                    headerModelObservableField.set(HeaderModel.setForBusinessWithCoApplicant());
                } else if (response.getEntityTypeName().equalsIgnoreCase("one_person_company")) {
                    business_type = "one_person_company";
                    SolePropSelected.set(false);
                    PartnershipSelected.set(false);
                    CompanySelected.set(false);
                    LLPSelected.set(false);
                    OnePersonSelected.set(true);
//                    headerModelObservableField.set(HeaderModel.setForBusiness());
                }
            }
        }
    }

    public void setMargine(int margine){
        this.margine = margine;
    }

    public void setSeekbar(IndicatorSeekBar seekbar){
        this.seekbar = seekbar;
    }

    private void getProductInfo(String loan_req_id){
        Call<GetPersonalInfoResponse> getPersonalInfoResponseCall = APIExecutor.getAPIService().getPersonalInfo(loan_req_id,Constant.PERSONAL_INFO_APPLICANT_TYPE,Constant.EDIT_APPLICATION_TYPE);
        getPersonalInfoResponseCall.enqueue(new Callback<GetPersonalInfoResponse>() {
            @Override
            public void onResponse(Call<GetPersonalInfoResponse> call, Response<GetPersonalInfoResponse> response) {
                if(response.isSuccessful() && response.body() != null
                        && response.body().getResponse() != null){
                    fillPersonalInfoData(response.body().getResponse());
                }
                hideLoading();
            }

            @Override
            public void onFailure(Call<GetPersonalInfoResponse> call, Throwable t) {
                hideLoading();
                Log.d("failed",t.getMessage());
            }
        });
    }

    private void fillPersonalInfoData(com.ziploan.dsaapp.model.response.personal.get_personal.Response response) {
        this.PersonalInfoData = response;
    }


    @Override
    protected void getFormConfigResponse(com.ziploan.dsaapp.model.response.form_config.Response response) {
        this.formResponse = response;
        if(response != null) {
            MyApplication.formResponse  = response;
            if (response.getDocumentsFilled()) {
                if (response.getCoapplicantFilled()) {
                    headerModelObservableField.set(HeaderModel.setForDocumentFilledWithCoApplicant(Constant.BUSINESS_INFO_TAG));
                } else if (response.getShowPages().size() == 4) {
                    headerModelObservableField.set(HeaderModel.setForDocumentFilledWithCoApplicantunfilled(Constant.BUSINESS_INFO_TAG));
                } else {
                    headerModelObservableField.set(HeaderModel.setForDocumentFilled(Constant.BUSINESS_INFO_TAG));
                }
            } else if (response.getCoapplicantFilled()) {
                headerModelObservableField.set(HeaderModel.setForCoapplicantFilled(Constant.BUSINESS_INFO_TAG));
            } else if (response.getBusinessInfoFilled()) {
                if (response.getShowPages().size() == 4) {
                    headerModelObservableField.set(HeaderModel.setForBusinessCoapplicantFilled(Constant.BUSINESS_INFO_TAG));
                } else {
                    headerModelObservableField.set(HeaderModel.setForBusinessFilled(Constant.BUSINESS_INFO_TAG));
                }
            } else if (response.getPersonalInfoFilled()) {
                if (response.getCoapplicantFilled()) {
                    headerModelObservableField.set(HeaderModel.setForPersonalInfoFilledCo(Constant.BUSINESS_INFO_TAG));
                } else {
                    headerModelObservableField.set(HeaderModel.setForPersonalInfoFilled(Constant.BUSINESS_INFO_TAG));
                }
            } else
                headerModelObservableField.set(HeaderModel.setForBusiness());
        } else
            headerModelObservableField.set(HeaderModel.setForBusiness());
    }

    private void resetTopOnTypeClick(com.ziploan.dsaapp.model.response.form_config.Response response){
        if(response != null) {
            if (response.getDocumentsFilled()) {
                if (showCoapplicant()) {
                    if(response.getCoapplicantFilled())
                    headerModelObservableField.set(HeaderModel.setForDocumentFilledWithCoApplicant(Constant.BUSINESS_INFO_TAG));
                    else
                        headerModelObservableField.set(HeaderModel.setForBusinessCoapplicantFilled(Constant.BUSINESS_INFO_TAG));
                } else {
                    headerModelObservableField.set(HeaderModel.setForDocumentFilled(Constant.BUSINESS_INFO_TAG));
                }
            } else if (response.getCoapplicantFilled()) {
                if (showCoapplicant()) {
                    headerModelObservableField.set(HeaderModel.setForCoapplicantFilled(Constant.BUSINESS_INFO_TAG));
                } else {
                    if (response.getBusinessInfoFilled()) {
                        headerModelObservableField.set(HeaderModel.setForBusinessFilled(Constant.BUSINESS_INFO_TAG));
                    } else {
                        headerModelObservableField.set(HeaderModel.setForBusiness());
                    }
                }

            } else if (response.getBusinessInfoFilled()) {
                if (showCoapplicant()) {
                    headerModelObservableField.set(HeaderModel.setForBusinessCoapplicantFilled(Constant.BUSINESS_INFO_TAG));
                } else {
                    headerModelObservableField.set(HeaderModel.setForBusinessFilled(Constant.BUSINESS_INFO_TAG));
                }
            } else if (response.getPersonalInfoFilled() ) {
                if (showCoapplicant()) {
                    if(response.getCoapplicantFilled())
                        headerModelObservableField.set(HeaderModel.setForPersonalInfoFilledCo(Constant.BUSINESS_INFO_TAG));
                    else
                        headerModelObservableField.set(HeaderModel.setForCoApplicantDesabled());
                } else {
                    headerModelObservableField.set(HeaderModel.setForPersonalInfoFilled(Constant.BUSINESS_INFO_TAG));
                }
            }
        }
    }

    private boolean showCoapplicant(){
        return !business_type.equalsIgnoreCase("one_person_company")
                && !business_type.equalsIgnoreCase("sole_proprietorship");
    }

    private void showResident() {
        if(PersonalInfoData != null){
            BusinessAddress.set(PersonalInfoData.getResidentialAddress());
            Pincode.set(PersonalInfoData.getResidentialPincode());
            City.set(PersonalInfoData.getResidentialCity());
            State.set(PersonalInfoData.getResidentialState());
            if(PersonalInfoData.getResidentialPlaceOwnership() != null) {
                if (PersonalInfoData.getResidentialPlaceOwnership().equalsIgnoreCase("rented")) {
                    RentedSelected.set(true);
                    SelfOwnedSelected.set(false);
                    residentialPlaceOwnership = "rented";
                } else if (PersonalInfoData.getResidentialPlaceOwnership().equalsIgnoreCase("self_owned")) {
                    residentialPlaceOwnership = "self_owned";
                    SelfOwnedSelected.set(true);
                    RentedSelected.set(false);
                }
            }
//            AddressEnable.set(false);
//            PincodeEnable.set(false);
        }
    }
    private void scrollToView(final ScrollView scrollViewParent, final View view) {
        Point childOffset = new Point();
        getDeepChildOffset(scrollViewParent, view.getParent(), view, childOffset);
        scrollViewParent.smoothScrollTo(0, childOffset.y);
    }

    private void getDeepChildOffset(final ViewGroup mainParent, final ViewParent parent, final View child, final Point accumulatedOffset) {
        ViewGroup parentGroup = (ViewGroup) parent;
        accumulatedOffset.x += child.getLeft();
        accumulatedOffset.y += child.getTop();
        if (parentGroup.equals(mainParent)) {
            return;
        }
        getDeepChildOffset(mainParent, parentGroup.getParent(), parentGroup, accumulatedOffset);
    }
    private void hideResident() {
//            BusinessAddress.set("");
//            Pincode.set("");
//            City.set("");
//            State.set("");
//            AddressEnable.set(true);
//            PincodeEnable.set(true);
    }
}
