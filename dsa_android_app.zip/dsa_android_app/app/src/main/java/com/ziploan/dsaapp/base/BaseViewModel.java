package com.ziploan.dsaapp.base;

import android.app.ProgressDialog;
import android.content.Context;
import android.content.DialogInterface;
import android.os.Build;
import android.view.inputmethod.InputMethodManager;
import android.widget.Toast;

import androidx.appcompat.app.AlertDialog;
import androidx.appcompat.app.AppCompatActivity;
import androidx.lifecycle.MutableLiveData;
import androidx.lifecycle.ViewModel;
import com.ziploan.dsaapp.MyApplication;
import com.ziploan.dsaapp.R;
import com.ziploan.dsaapp.base.extras.network.APIExecutor;
import com.ziploan.dsaapp.fragments.home.HomeFragment;
import com.ziploan.dsaapp.model.response.form_config.FormConfigResponse;
import com.ziploan.dsaapp.utils.CommonUtils;
import com.ziploan.dsaapp.utils.Constant;
import com.ziploan.dsaapp.utils.NavController;
import com.ziploan.dsaapp.utils.NetworkUtils;
import com.ziploan.dsaapp.utils.permissons.PermissionUtils;
import retrofit2.Call;
import retrofit2.Callback;
import retrofit2.Response;

public class BaseViewModel extends ViewModel {
    protected final MutableLiveData<Boolean> refresh;
    private ProgressDialog mProgressDialog;


    protected BaseViewModel(){
        refresh = new MutableLiveData<>();
    }

    protected boolean isNetworkConnected(Context context) {
        return NetworkUtils.isNetworkConnected(context);
    }

    public static void hideSoftKeyboard(Context context) {
        InputMethodManager inputMethodManager =
                (InputMethodManager)  (context).getSystemService(AppCompatActivity.INPUT_METHOD_SERVICE);
        inputMethodManager.hideSoftInputFromWindow(((AppCompatActivity)context).getCurrentFocus().getWindowToken(), 0);
    }

    public void refresh(){
        refresh.setValue(true);
    }

    protected void showToast(Context context,String message){
        Toast.makeText(context,message,Toast.LENGTH_SHORT).show();
    }

    protected void showDialogue(Context context, String message, String title) {
        AlertDialog.Builder builder;
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.LOLLIPOP) {
            builder = new AlertDialog.Builder(context, android.R.style.Theme_Material_Light_Dialog_NoActionBar);
        } else {
            builder = new AlertDialog.Builder(context);
        }
        builder.setTitle(title)
                .setMessage(message)
                .setPositiveButton(android.R.string.yes, new DialogInterface.OnClickListener() {
                    public void onClick(DialogInterface dialog, int which) {
                        dialog.dismiss();
                        yesClicked();
                    }
                })
                .setNegativeButton("",null).setIcon(null)
                .show();
    }

    protected void yesClicked(){

    }

    protected void loading(boolean isLoading, Context context) {
        if(isLoading)
            showLoading(context);
        else
            hideLoading();
    }

    protected void hideLoading() {
        if (mProgressDialog != null && mProgressDialog.isShowing()) {
            mProgressDialog.cancel();
        }
    }

    protected void showLoading(Context context) {
        hideLoading();
        mProgressDialog = CommonUtils.showLoadingDialog(context);
    }

    protected void reqFormConfig(String loan_req_id) {
        Call<FormConfigResponse> pincodeResponseCall = APIExecutor.getAPIService().formConfig(loan_req_id);
        pincodeResponseCall.enqueue(new Callback<FormConfigResponse>() {
            @Override
            public void onResponse(Call<FormConfigResponse> call, Response<FormConfigResponse> response) {
                if (response.isSuccessful() && response.body() != null) {
                    if (response.body().getStatus().equalsIgnoreCase(Constant.SUCCESS)) {
                        MyApplication.BusinessDetailsField = response.body().getResponse().getBusinessInfoFilled();
                        MyApplication.formResponse = response.body().getResponse();
                        if(response.body().getResponse().getApplicationType().equalsIgnoreCase("uneditable")){
                            showToast(MyApplication.getInstance(),MyApplication.getInstance().getString(R.string.app_uneditable));
                            NavController.getInstance().clearBack();
                            NavController.getInstance().addFragment(HomeFragment.newInstance(),false);
                        } else {
                            getFormConfigResponse(response.body().getResponse());
                        }

                    } else {
                        getFormConfigResponse(null);
                    }
                } else {
                    getFormConfigResponse(null);
                }
            }

            @Override
            public void onFailure(Call<FormConfigResponse> call, Throwable t) {
                getFormConfigResponse(null);
            }
        });
    }

    protected void reqFormConfigForNavigation(String loan_req_id) {
        Call<FormConfigResponse> pincodeResponseCall = APIExecutor.getAPIService().formConfig(loan_req_id);
        pincodeResponseCall.enqueue(new Callback<FormConfigResponse>() {
            @Override
            public void onResponse(Call<FormConfigResponse> call, Response<FormConfigResponse> response) {
                if (response.isSuccessful() && response.body() != null) {
                    if (response.body().getStatus().equalsIgnoreCase(Constant.SUCCESS)) {
                        MyApplication.BusinessDetailsField = response.body().getResponse().getBusinessInfoFilled();
                        MyApplication.formResponse = response.body().getResponse();
                        getFormConfigResponseForNav(response.body().getResponse());
                    } else {
                        getFormConfigResponseForNav(null);
                    }
                } else {
                    getFormConfigResponseForNav(null);
                }
                hideLoading();
            }

            @Override
            public void onFailure(Call<FormConfigResponse> call, Throwable t) {
                getFormConfigResponseForNav(null);
                hideLoading();
            }
        });
    }

    protected void getFormConfigResponse(com.ziploan.dsaapp.model.response.form_config.Response response) {

    }

    protected void getFormConfigResponseForNav(com.ziploan.dsaapp.model.response.form_config.Response response) {

    }


}
