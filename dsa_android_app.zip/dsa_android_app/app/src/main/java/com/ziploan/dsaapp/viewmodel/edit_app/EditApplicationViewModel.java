package com.ziploan.dsaapp.viewmodel.edit_app;

import android.content.Context;
import android.text.TextUtils;
import android.view.View;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import androidx.annotation.NonNull;
import androidx.databinding.ObservableBoolean;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;
import androidx.swiperefreshlayout.widget.SwipeRefreshLayout;

import com.ziploan.dsaapp.BuildConfig;
import com.ziploan.dsaapp.MyApplication;
import com.ziploan.dsaapp.R;
import com.ziploan.dsaapp.base.BaseViewModel;
import com.ziploan.dsaapp.base.BindingAppAdapter;
import com.ziploan.dsaapp.base.extras.network.APIExecutor;
import com.ziploan.dsaapp.fragments.details.BusinessDetailsFragment;
import com.ziploan.dsaapp.fragments.details.CoApplicantFragment;
import com.ziploan.dsaapp.fragments.details.DocumentUploadDetailsFragment;
import com.ziploan.dsaapp.fragments.details.PersonalDetailsFragment;
import com.ziploan.dsaapp.model.response.loan_list.LoanListResponse;
import com.ziploan.dsaapp.model.response.loan_list.PartnerIncompleteLoanRequestDatum;
import com.ziploan.dsaapp.utils.Constant;
import com.ziploan.dsaapp.utils.EndlessRecyclerViewScrollListener;
import com.ziploan.dsaapp.utils.NavController;
import com.ziploan.dsaapp.utils.PreferencesManager;
import retrofit2.Call;
import retrofit2.Callback;
import retrofit2.Response;

public class EditApplicationViewModel extends BaseViewModel{

    private static final int RECORD_PER_PAGE = 10;
    private static final int PAGE_NUMBER = 1;
    private List<PartnerIncompleteLoanRequestDatum> partnerIncompleteLoanRequestData;
    private BindingAppAdapter<PartnerIncompleteLoanRequestDatum> bindingAppAdapter;
    private LoanListResponse loanListResponse;
    private EndlessRecyclerViewScrollListener scrollListener;
    private String queryText = "";
    private PartnerIncompleteLoanRequestDatum partnerIncompleteLoanRequestDatum;
    public ObservableBoolean NoResultFound = new ObservableBoolean();
    private Context context;


    private BindingAppAdapter<PartnerIncompleteLoanRequestDatum> getLoanListAdapter(){
        bindingAppAdapter = new BindingAppAdapter<PartnerIncompleteLoanRequestDatum>(this::selected){
            @Override
            public int getLayout() {
                return R.layout.loan_item_layout;
            }
        };
        return bindingAppAdapter;
    }


    private void selected(View view, int i, PartnerIncompleteLoanRequestDatum partnerIncompleteLoanRequestDatum) {
        this.partnerIncompleteLoanRequestDatum = partnerIncompleteLoanRequestDatum;
        showLoading(view.getContext());
        MyApplication.LOAN_REQ_ID = partnerIncompleteLoanRequestDatum.getLoanRequestId();
        reqFormConfig(partnerIncompleteLoanRequestDatum.getLoanRequestId());
    }

    @Override
    protected void getFormConfigResponse(com.ziploan.dsaapp.model.response.form_config.Response response) {
        hideLoading();
        MyApplication.FromMobile = false;
        if (response != null) {
            MyApplication.formResponse  = response;
            if(response.getShowPages().size() == 1){
                if(response.getShowPages().get(0).equalsIgnoreCase("personal_info")){
                    MyApplication.ShowOnePage = "personal_info";
                } else if(response.getShowPages().get(0).equalsIgnoreCase("business_info")){
                    MyApplication.ShowOnePage = "business_info";
                } else if(response.getShowPages().get(0).equalsIgnoreCase("documents")){
                    MyApplication.ShowOnePage = "documents";
                    NavController.getInstance().addFragment(DocumentUploadDetailsFragment.newInstance(response.getLoanRequestId()
                            ,1), true);
                }
            } else {
                if (response.getLandsOn().equalsIgnoreCase("personal_info")) {
                    //TODO
                     //change  mobile number to get pan number
                    NavController.getInstance().addFragment(PersonalDetailsFragment.newInstance(response.getCustomerMobile(), response.getLoanRequestId(),
                            response.getShowPages() != null ? response.getShowPages().size() : 3), true);

                } else if (response.getLandsOn().equalsIgnoreCase("business_info")) {
                    NavController.getInstance().addFragment(BusinessDetailsFragment.newInstance(response.getLoanRequestId()
                            , response.getShowPages() != null ? response.getShowPages().size() : 3), true);

                } else if (response.getLandsOn().equalsIgnoreCase("documents")) {
                    NavController.getInstance().addFragment(DocumentUploadDetailsFragment.newInstance(response.getLoanRequestId()
                            , response.getShowPages() != null ? response.getShowPages().size() : 3), true);
                } else if (response.getLandsOn().equalsIgnoreCase("coapplicant")) {
                    NavController.getInstance().addFragment(CoApplicantFragment.newInstance(response.getLoanRequestId()), true);
                }
            }
        } else {
            if(partnerIncompleteLoanRequestDatum != null){
                if(Integer.parseInt(partnerIncompleteLoanRequestDatum.getLoanRequestStatus()) == 1){
                    NavController.getInstance().addFragment(BusinessDetailsFragment.newInstance(partnerIncompleteLoanRequestDatum.getLoanRequestId()), true);
                } else if(Integer.parseInt(partnerIncompleteLoanRequestDatum.getLoanRequestStatus()) == 2){
                    NavController.getInstance().addFragment(DocumentUploadDetailsFragment.newInstance(partnerIncompleteLoanRequestDatum.getLoanRequestId()), true);
                }
            }
        }
    }

    public void setLoanRecycler(RecyclerView loanRecycler){
        loanRecycler.setAdapter(getLoanListAdapter());
        showLoading(loanRecycler.getContext());
        partnerIncompleteLoanRequestData = null;
        getLoanList(PAGE_NUMBER);
        scrollListener = new EndlessRecyclerViewScrollListener((LinearLayoutManager) loanRecycler.getLayoutManager()) {
            @Override
            public void onLoadMore(int page, int totalItemsCount, RecyclerView view) {
                if(loanListResponse != null
                        && loanListResponse.getNumPages() >= page)
                    getLoanList(page);
            }
        };
        loanRecycler.addOnScrollListener(scrollListener);
    }

    public void setSearchText(String seatch, Context context,boolean pulledToRefresh){
        NoResultFound.set(true);
        if(scrollListener != null)
            scrollListener.resetState();
        this.context = context;
        if (!pulledToRefresh){
            showLoading(context);
        }
        this.queryText = seatch;
        if (!TextUtils.isEmpty(queryText)){
            hideSoftKeyboard(context);
        }
        getLoanListSearch(PAGE_NUMBER);
    }

    public void resetText(){
        queryText = "";
    }

    private void getLoanList(int pageNumber) {

        Map<String, String> query = new HashMap<>();
        String partner_id = PreferencesManager.getInstance().getString(PreferencesManager.AUTH_ID);
        query.put("partner_id", partner_id);
        query.put("page_no", String.valueOf(pageNumber));
        query.put("records_per_page", String.valueOf(RECORD_PER_PAGE));
        if(!TextUtils.isEmpty(queryText))
            query.put("query", queryText);

        Call<LoanListResponse> call = APIExecutor.getAPIService().loanList(query);
        call.enqueue(new Callback<LoanListResponse>() {
            @Override
            public void onResponse(Call<LoanListResponse> call, Response<LoanListResponse> response) {
                if (response.isSuccessful()
                        && response.body() != null
                        && response.body().getPartnerIncompleteLoanRequestData() != null
                        && response.body().getPartnerIncompleteLoanRequestData().size() > 0) {
                    loanListResponse = response.body();

                    if (partnerIncompleteLoanRequestData == null) {
                        partnerIncompleteLoanRequestData = response.body().getPartnerIncompleteLoanRequestData();
                        bindingAppAdapter.setItems(response.body().getPartnerIncompleteLoanRequestData());
                    } else {
                        partnerIncompleteLoanRequestData.clear();
                        partnerIncompleteLoanRequestData.addAll(response.body().getPartnerIncompleteLoanRequestData());
                        bindingAppAdapter.addItems(response.body().getPartnerIncompleteLoanRequestData());
                    }

                    NoResultFound.set(false);

                } else {
                    loanListResponse = null;
                    partnerIncompleteLoanRequestData = null;
                    bindingAppAdapter.clear();
                    NoResultFound.set(false);
                }
                layout.setRefreshing(false);
                hideLoading();
            }

            @Override
            public void onFailure(Call<LoanListResponse> call, Throwable t) {
                hideLoading();
                layout.setRefreshing(false);
            }
        });
    }

    private void getLoanListSearch(int pageNumber) {
        NoResultFound.set(true);
        Map<String, String> query = new HashMap<>();
        String partner_id = PreferencesManager.getInstance().getString(PreferencesManager.AUTH_ID);
        query.put("partner_id", partner_id);
        query.put("page_no", String.valueOf(pageNumber));
        query.put("records_per_page", String.valueOf(RECORD_PER_PAGE));
        query.put("query", queryText);

        Call<LoanListResponse> call;

        if (BuildConfig.BUILD_TYPE.equalsIgnoreCase("prep") || BuildConfig.BUILD_TYPE.equalsIgnoreCase("qa")){
            call = APIExecutor.getAPIService_LS().loanList(query);
        }else{
            call = APIExecutor.getAPIService().loanList(query);
        }


        call.enqueue(new Callback<LoanListResponse>() {
            @Override
            public void onResponse(Call<LoanListResponse> call, Response<LoanListResponse> response) {
                if (response.isSuccessful()
                        && response.body() != null
                        && response.body().getPartnerIncompleteLoanRequestData() != null
                        && response.body().getPartnerIncompleteLoanRequestData().size() > 0) {
                    loanListResponse = response.body();
                    partnerIncompleteLoanRequestData = response.body().getPartnerIncompleteLoanRequestData();
                    bindingAppAdapter.setItems(response.body().getPartnerIncompleteLoanRequestData());
                    NoResultFound.set(false);

                } else {
                    loanListResponse = null;
                    partnerIncompleteLoanRequestData = null;
                    bindingAppAdapter.clear();
                    NoResultFound.set(false);
                }
                layout.setRefreshing(false);
                hideLoading();
            }

            @Override
            public void onFailure(Call<LoanListResponse> call, Throwable t) {
                hideLoading();
                layout.setRefreshing(false);
            }
        });
    }

    public void resetSearch() {
        if(scrollListener != null)
            scrollListener.resetState();
        this.queryText = "";
        this.partnerIncompleteLoanRequestData = null;
        getLoanList(PAGE_NUMBER);
    }

    private SwipeRefreshLayout layout;
    public void setSwipObject(SwipeRefreshLayout layout){
        this.layout = layout;
        layout.setOnRefreshListener(this::onRefresh);
    }

    private void onRefresh() {
        this.partnerIncompleteLoanRequestData = null;
        //getLoanList(PAGE_NUMBER);


           setSearchText("",context,true);
    }

}
