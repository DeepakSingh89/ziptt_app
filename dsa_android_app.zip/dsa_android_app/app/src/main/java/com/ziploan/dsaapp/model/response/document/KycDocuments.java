
package com.ziploan.dsaapp.model.response.document;


import com.google.gson.annotations.Expose;
import com.google.gson.annotations.SerializedName;

import java.util.List;

public class KycDocuments {

    @SerializedName("kyc")
    @Expose
    private List<Kyc> kyc = null;

    public List<Kyc> getKyc() {
        return kyc;
    }

    public void setKyc(List<Kyc> kyc) {
        this.kyc = kyc;
    }
}
