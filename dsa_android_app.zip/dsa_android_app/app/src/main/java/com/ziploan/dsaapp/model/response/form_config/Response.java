
package com.ziploan.dsaapp.model.response.form_config;

import java.util.List;
import com.google.gson.annotations.Expose;
import com.google.gson.annotations.SerializedName;

public class Response {

    @SerializedName("loan_request_id")
    @Expose
    private String loanRequestId;
    @SerializedName("form_type")
    @Expose
    private String formType;
    @SerializedName("personal_info_filled")
    @Expose
    private Boolean personalInfoFilled;
    @SerializedName("get_personal_info")
    @Expose
    private Boolean getPersonalInfo;
    @SerializedName("business_info_filled")
    @Expose
    private Boolean businessInfoFilled;
    @SerializedName("get_business_info")
    @Expose
    private Boolean getBusinessInfo;
    @SerializedName("coapplicant_filled")
    @Expose
    private Boolean coapplicantFilled;
    @SerializedName("get_coapplicant_info")
    @Expose
    private Boolean getCoapplicantInfo;
    @SerializedName("documents_filled")
    @Expose
    private Boolean documentsFilled;
    @SerializedName("lands_on")
    @Expose
    private String landsOn;
    @SerializedName("show_pages")
    @Expose
    private List<String> showPages = null;
    @SerializedName("application_type")
    @Expose
    private String applicationType;
    @SerializedName("customer_mobile")
    @Expose
    private String customerMobile;

    public String getCustomerPan() {
        return customerPan;
    }

    public void setCustomerPan(String customerPan) {
        this.customerPan = customerPan;
    }

    @SerializedName("customer_pan")
    @Expose
    private String customerPan;

    public String getLoanRequestId() {
        return loanRequestId;
    }

    public void setLoanRequestId(String loanRequestId) {
        this.loanRequestId = loanRequestId;
    }


    public String getFormType() {
        return formType;
    }

    public void setFormType(String formType) {
        this.formType = formType;
    }

    public Boolean getPersonalInfoFilled() {
        return personalInfoFilled;
    }

    public void setPersonalInfoFilled(Boolean personalInfoFilled) {
        this.personalInfoFilled = personalInfoFilled;
    }

    public Boolean getGetPersonalInfo() {
        return getPersonalInfo;
    }

    public void setGetPersonalInfo(Boolean getPersonalInfo) {
        this.getPersonalInfo = getPersonalInfo;
    }

    public Boolean getBusinessInfoFilled() {
        return businessInfoFilled;
    }

    public void setBusinessInfoFilled(Boolean businessInfoFilled) {
        this.businessInfoFilled = businessInfoFilled;
    }

    public Boolean getGetBusinessInfo() {
        return getBusinessInfo;
    }

    public void setGetBusinessInfo(Boolean getBusinessInfo) {
        this.getBusinessInfo = getBusinessInfo;
    }

    public Boolean getCoapplicantFilled() {
        return coapplicantFilled;
    }

    public void setCoapplicantFilled(Boolean coapplicantFilled) {
        this.coapplicantFilled = coapplicantFilled;
    }

    public Boolean getGetCoapplicantInfo() {
        return getCoapplicantInfo;
    }

    public void setGetCoapplicantInfo(Boolean getCoapplicantInfo) {
        this.getCoapplicantInfo = getCoapplicantInfo;
    }

    public Boolean getDocumentsFilled() {
        return documentsFilled;
    }

    public void setDocumentsFilled(Boolean documentsFilled) {
        this.documentsFilled = documentsFilled;
    }

    public String getLandsOn() {
        return landsOn;
    }

    public void setLandsOn(String landsOn) {
        this.landsOn = landsOn;
    }

    public List<String> getShowPages() {
        return showPages;
    }

    public void setShowPages(List<String> showPages) {
        this.showPages = showPages;
    }

    public String getApplicationType() {
        return applicationType;
    }

    public void setApplicationType(String applicationType) {
        this.applicationType = applicationType;
    }

    public String getCustomerMobile() {
        return customerMobile;
    }

    public void setCustomerMobile(String customerMobile) {
        this.customerMobile = customerMobile;
    }
}
