package com.ziploan.dsaapp;

public interface IBaseFragment {
}
