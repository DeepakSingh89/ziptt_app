package com.ziploan.dsaapp.utils;

import android.content.Context;
import android.content.SharedPreferences;

import com.ziploan.dsaapp.BuildConfig;
import com.ziploan.dsaapp.MyApplication;

public class PreferencesManager {
    private static final String PREF_NAME = BuildConfig.APPLICATION_ID;
    private static final String IS_USER_LOGGED_IN = "isUserLoggedin";
    public static final String AUTH_TOKEN = "authToken";
    public static final String EXPIRE_TIME = "expire_time";
    public static final String PARTNER_ACCOUNT_NAME = "partner_account_name";
    public static final String AUTH_ID = "authid";

    private static PreferencesManager sInstance;
    private final SharedPreferences mPref;

    private PreferencesManager(Context context) {
        mPref = context.getSharedPreferences(PREF_NAME, Context.MODE_PRIVATE);
    }

    public static synchronized void initializeInstance(Context context) {
        if (sInstance == null) {
            sInstance = new PreferencesManager(context);
        }
    }

    public static synchronized PreferencesManager getInstance() {
        if (sInstance == null) {
            initializeInstance(MyApplication.getInstance().getAppContext());
        }
        return sInstance;
    }

    public void setString(String key, String value) {
        mPref.edit().putString(key, value).apply();
    }

    public String getString(String key) {
        return mPref.getString(key, "");
    }

    public void setBoolean(String key, boolean value) {
        mPref.edit().putBoolean(key, value).apply();
    }

    public boolean getBoolean(String key) {
        return mPref.getBoolean(key, false);
    }

    public void setLong(String key, long value) {
        mPref.edit().putLong(key, value).apply();
    }

    public long getLong(String key) {
        return mPref.getLong(key, 0);
    }

    public void setUserLoggedIn(boolean isLoggedIn) {
        setBoolean(IS_USER_LOGGED_IN, isLoggedIn);
    }

    public boolean isUserLoggedIn() {
        return getBoolean(IS_USER_LOGGED_IN);
    }

}
