package com.ziploan.dsaapp.viewmodel.details;

import android.content.Context;
import android.content.Intent;
import android.graphics.Point;
import android.net.Uri;
import android.os.Bundle;
import android.os.Environment;
import android.provider.Browser;
import android.provider.MediaStore;
import android.text.TextUtils;
import android.util.Log;
import android.view.View;
import android.view.ViewGroup;
import android.view.ViewParent;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.AutoCompleteTextView;
import android.widget.ScrollView;

import androidx.appcompat.app.AlertDialog;
import androidx.core.content.FileProvider;
import androidx.databinding.ObservableBoolean;
import androidx.databinding.ObservableField;
import androidx.recyclerview.widget.RecyclerView;

import com.jaiselrahman.filepicker.activity.FilePickerActivity;
import com.jaiselrahman.filepicker.config.Configurations;
import com.ziploan.dsaapp.BuildConfig;
import com.ziploan.dsaapp.MyApplication;
import com.ziploan.dsaapp.R;
import com.ziploan.dsaapp.base.BaseViewModel;
import com.ziploan.dsaapp.base.BindingAppAdapter;
import com.ziploan.dsaapp.base.extras.network.APIExecutor;
import com.ziploan.dsaapp.fragments.details.DocumentUploadDetailsFragment;
import com.ziploan.dsaapp.fragments.home.HomeFragment;
import com.ziploan.dsaapp.fragments.home.SuccessFragment;
import com.ziploan.dsaapp.model.ZiploanPhoto;
import com.ziploan.dsaapp.model.bank_list.BankListResponse;
import com.ziploan.dsaapp.model.header.HeaderModel;
import com.ziploan.dsaapp.model.request.document.PostDocumentRequest;
import com.ziploan.dsaapp.model.request.document.Primary;
import com.ziploan.dsaapp.model.request.document.Secondary;
import com.ziploan.dsaapp.model.response.MobileVerificationResponse;
import com.ziploan.dsaapp.model.response.document.GetDocumentResponse;
import com.ziploan.dsaapp.utils.CommonUtils;
import com.ziploan.dsaapp.utils.Constant;
import com.ziploan.dsaapp.utils.FileUploader;
import com.ziploan.dsaapp.utils.NavController;
import com.ziploan.dsaapp.utils.NetworkUtils;
import com.ziploan.dsaapp.utils.PhotoUploadListener;
import com.ziploan.dsaapp.utils.PreferencesManager;
import com.ziploan.dsaapp.utils.ViewerActivity;

import java.io.File;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Calendar;
import java.util.Date;
import java.util.GregorianCalendar;
import java.util.HashMap;
import java.util.List;
import java.util.Locale;
import java.util.Map;

import retrofit2.Call;
import retrofit2.Callback;
import retrofit2.Response;

public class DocumentUploadViewModel extends BaseViewModel {

    private final Context context;
    private String accountType;
    private String SecondaryaccountType;
    private String loan_req_id;
    public ObservableField<String> PrimeryBankPassword = new ObservableField<>();

    public ObservableField<String> PrimaryBankStartDate = new ObservableField<>();
    public ObservableField<String> PrimaryBankEndDate = new ObservableField<>();
    public ObservableField<String> SecondaryBankStartDate = new ObservableField<>();
    public ObservableField<String> SecondaryBankEndDate = new ObservableField<>();
    public ObservableField<String> SecondaryBankPassword = new ObservableField<>();
    public ObservableField<HeaderModel> headerModelObservableField = new ObservableField<>();
    private DocumentUploadDetailsFragment documentUploadDetailsFragment;
    private AlertDialog itemListDialog;
    private Uri capturedImageUri;
    private String mCurrentPhotoPath;
    private com.ziploan.dsaapp.model.response.document.Response DocumentResponse;

    public ObservableBoolean ShowFirstYearITRUploaded = new ObservableBoolean(true);
    public ObservableBoolean ShowFirstYearITRUploadeded = new ObservableBoolean();
    public ObservableBoolean ShowFirstYearITRUploadeding = new ObservableBoolean();

    public ObservableBoolean ShowSecondYearITRUploaded = new ObservableBoolean();
    public ObservableBoolean ShowSecondYearITRUploading = new ObservableBoolean();
    public ObservableBoolean ShowSecondYearITRUpload = new ObservableBoolean(true);

    public ObservableBoolean ShowAnotherYearITRUploaded = new ObservableBoolean();
    public ObservableBoolean ShowAnotherYearITRUploading = new ObservableBoolean();
    public ObservableBoolean ShowAnotherYearITRUpload = new ObservableBoolean(true);

    public ObservableBoolean SavingAccountTypeSelected = new ObservableBoolean();
    public ObservableBoolean CurrentAccountTypeSelected = new ObservableBoolean();
    public ObservableBoolean OverdraftAccountTypeSelected = new ObservableBoolean();
    public ObservableBoolean CCAccountTypeSelected = new ObservableBoolean();

    public ObservableBoolean SecSavingAccountTypeSelected = new ObservableBoolean();
    public ObservableBoolean SecCurrentAccountTypeSelected = new ObservableBoolean();
    public ObservableBoolean SecOverdraftAccountTypeSelected = new ObservableBoolean();
    public ObservableBoolean SecCCAccountTypeSelected = new ObservableBoolean();

    public ObservableBoolean BankStatementUpload = new ObservableBoolean(true);
    public ObservableBoolean BankStatementUploading = new ObservableBoolean();

    public ObservableBoolean SecBankStatementText = new ObservableBoolean(true);
    public ObservableBoolean SecBankStatementLayout = new ObservableBoolean(false);
    public ObservableBoolean SecBankStatementUpload = new ObservableBoolean(true);
    public ObservableBoolean SecBankStatementUploading = new ObservableBoolean();

    public ObservableBoolean KYCStatementUpload = new ObservableBoolean(true);
    public ObservableBoolean KYCBankStatementUploading = new ObservableBoolean();

    private int currentSelectedDoc;

    private static final int FIRST_YEAR_ITR = 852;
    private static final int SECOND_YEAR_ITR = 767;
    private static final int ANOTHER_YEAR_ITR = 768;
    private static final int BANK_STATEMENT_UPLOAD = 456;
    private static final int SEC_BANK_STATEMENT_UPLOAD = 458;
    private static final int KYC_UPLOAD = 459;

    private ArrayList<ZiploanPhoto> arrPrimeryBankItems = new ArrayList<>();
    private BindingAppAdapter<ZiploanPhoto> adapterPrimeryBank;

    private ArrayList<ZiploanPhoto> arrSecBankItems = new ArrayList<>();
    private BindingAppAdapter<ZiploanPhoto> adapterSecBank;

    private ArrayList<ZiploanPhoto> arrKycBankItems = new ArrayList<>();
    private BindingAppAdapter<ZiploanPhoto> adapterKycBank;

    private ArrayList<ZiploanPhoto> arrFirstItrBankItems = new ArrayList<>();
    private BindingAppAdapter<ZiploanPhoto> adapterFirstItrBank;

    private ArrayList<ZiploanPhoto> arrLastItrBankItems = new ArrayList<>();
    private BindingAppAdapter<ZiploanPhoto> adapterLastItrBank;

    private ArrayList<ZiploanPhoto> arrAnotherItrBankItems = new ArrayList<>();
    private BindingAppAdapter<ZiploanPhoto> adapterAnotherItrBank;

    private ArrayAdapter<com.ziploan.dsaapp.model.bank_list.Response> bankadapter;
    private ArrayAdapter<com.ziploan.dsaapp.model.bank_list.Response> secBankadapter;
    private String selectedBankName;
    private String selectedSecondarBankName;
    private List<com.ziploan.dsaapp.model.bank_list.Response> bankList = new ArrayList<>();
    private List<com.ziploan.dsaapp.model.bank_list.Response> SecBankList = new ArrayList<>();
    private AutoCompleteTextView completeTextView;
    private AutoCompleteTextView seccompleteTextView;
    private com.ziploan.dsaapp.model.response.form_config.Response formResponse;


    public DocumentUploadViewModel(String loan_req_id, DocumentUploadDetailsFragment documentUploadDetailsFragment, int pages, Context context
    ) {
        this.documentUploadDetailsFragment = documentUploadDetailsFragment;
        this.loan_req_id = loan_req_id;
        this.context=context;
        if (pages == 1) {
            headerModelObservableField.set(HeaderModel.setForOnlyDocument());
        } else {
            if (MyApplication.formResponse != null)
                getFormConfigResponse(MyApplication.formResponse);
            else
                headerModelObservableField.set(HeaderModel.setForDocument());
        }
        getLoanList();
        getDocuments();
    }


    public void seNumOfPages(int numOfPages) {
//        if (numOfPages > 3) {
//            headerModelObservableField.set(HeaderModel.setForDocumentWithCoapplicent());
//        } else {
//            headerModelObservableField.set(HeaderModel.setForDocument());
//        }
//        reqFormConfig(loan_req_id);
    }

    public void onClick(View view, DocumentUploadDetailsFragment personalDetailsFragment) {
        switch (view.getId()) {
            case R.id.upload_first_itr:
                currentSelectedDoc = FIRST_YEAR_ITR;
                openCameraGalleryOptions(false);
                break;
            case R.id.upload_second_itr:
                currentSelectedDoc = SECOND_YEAR_ITR;
                openCameraGalleryOptions(false);
                break;
            case R.id.upload_another_itr:
                currentSelectedDoc = ANOTHER_YEAR_ITR;
                openCameraGalleryOptions(false);
                break;
            case R.id.saving:
                accountType = "saving";
                SavingAccountTypeSelected.set(true);
                CurrentAccountTypeSelected.set(false);
                OverdraftAccountTypeSelected.set(false);
                CCAccountTypeSelected.set(false);
                break;
            case R.id.current:
                accountType = "current";
                SavingAccountTypeSelected.set(false);
                CurrentAccountTypeSelected.set(true);
                OverdraftAccountTypeSelected.set(false);
                CCAccountTypeSelected.set(false);
                break;
            case R.id.overdraft:
                accountType = "overdraft";
                SavingAccountTypeSelected.set(false);
                CurrentAccountTypeSelected.set(false);
                OverdraftAccountTypeSelected.set(true);
                CCAccountTypeSelected.set(false);
                break;
            case R.id.cc:
                accountType = "cc";
                SavingAccountTypeSelected.set(false);
                CurrentAccountTypeSelected.set(false);
                OverdraftAccountTypeSelected.set(false);
                CCAccountTypeSelected.set(true);
                break;
            case R.id.sec_saving:
                SecondaryaccountType = "saving";
                SecSavingAccountTypeSelected.set(true);
                SecCurrentAccountTypeSelected.set(false);
                SecOverdraftAccountTypeSelected.set(false);
                SecCCAccountTypeSelected.set(false);
                break;
            case R.id.sec_current:
                SecondaryaccountType = "current";
                SecSavingAccountTypeSelected.set(false);
                SecCurrentAccountTypeSelected.set(true);
                SecOverdraftAccountTypeSelected.set(false);
                SecCCAccountTypeSelected.set(false);
                break;
            case R.id.sec_overdraft:
                SecondaryaccountType = "overdraft";
                SecSavingAccountTypeSelected.set(false);
                SecCurrentAccountTypeSelected.set(false);
                SecOverdraftAccountTypeSelected.set(true);
                SecCCAccountTypeSelected.set(false);
                break;
            case R.id.sec_cc:
                SecondaryaccountType = "cc";
                SecSavingAccountTypeSelected.set(false);
                SecCurrentAccountTypeSelected.set(false);
                SecOverdraftAccountTypeSelected.set(false);
                SecCCAccountTypeSelected.set(true);
                break;
            case R.id.bank_upload:
                currentSelectedDoc = BANK_STATEMENT_UPLOAD;
                openCameraGalleryOptions(false);
                break;
            case R.id.sec_bank_upload:
                currentSelectedDoc = SEC_BANK_STATEMENT_UPLOAD;
                openCameraGalleryOptions(false);
                break;
            case R.id.kyc_upload:
                currentSelectedDoc = KYC_UPLOAD;
                openCameraGalleryOptions(false);
                break;
            case R.id.submit:
                if (cansubmit() && statementDateSelected())
                    submitLoanRequest(personalDetailsFragment);
                break;
            case R.id.sec_bank_upload_text:
                SecBankStatementLayout.set(true);
//                documentUploadDetailsFragment.slideDown();
                SecBankStatementText.set(false);

                break;

            case R.id.primaryStart:
                documentUploadDetailsFragment.selecPrimaryBankStmtStarttDate(1);
                break;

            case R.id.primaryEnd:
                documentUploadDetailsFragment.selecPrimaryBankStmtStarttDate(2);
                break;

            case R.id.secondaryStart:
                documentUploadDetailsFragment.selecPrimaryBankStmtStarttDate(3);
                break;

            case R.id.secondaryEnd:
                documentUploadDetailsFragment.selecPrimaryBankStmtStarttDate(4);
                break;
        }
    }

    private boolean statementDateSelected() {

        if (!TextUtils.isEmpty(PrimaryBankStartDate.get())) {
            if (!TextUtils.isEmpty(PrimaryBankEndDate.get())) {


                if (isValidStateentDateRange(PrimaryBankStartDate.get(), PrimaryBankEndDate.get())) {

                    if (!TextUtils.isEmpty(seccompleteTextView.getText())
                            && !TextUtils.isEmpty(selectedSecondarBankName)) {
                        if (!TextUtils.isEmpty(SecondaryBankStartDate.get())) {
                            if (!TextUtils.isEmpty(SecondaryBankStartDate.get())) {
                                if (isValidStateentDateRange(SecondaryBankStartDate.get(), SecondaryBankEndDate.get())) {
                                    return true;
                                } else {
                                    scrollToView(documentUploadDetailsFragment.getParentView().mainScroll, documentUploadDetailsFragment.getParentView().secondaryEnd);
                                    showToast(documentUploadDetailsFragment.getContext(), documentUploadDetailsFragment.getString(R.string.diff_in_months_for_sec_bank));
                                }


                            } else {
                                scrollToView(documentUploadDetailsFragment.getParentView().mainScroll, documentUploadDetailsFragment.getParentView().secondaryEnd);
                                showToast(documentUploadDetailsFragment.getContext(), documentUploadDetailsFragment.getString(R.string.sec_end_date));
                            }


                        } else {
                            scrollToView(documentUploadDetailsFragment.getParentView().mainScroll, documentUploadDetailsFragment.getParentView().secondaryStart);
                            showToast(documentUploadDetailsFragment.getContext(), documentUploadDetailsFragment.getString(R.string.sec_start_date));
                        }
                    } else {
                        return true;
                    }
                } else {
                    scrollToView(documentUploadDetailsFragment.getParentView().mainScroll, documentUploadDetailsFragment.getParentView().primaryEnd);
                    showToast(documentUploadDetailsFragment.getContext(), documentUploadDetailsFragment.getString(R.string.diff_in_months_for_pri_bank));

                }


            } else {
                scrollToView(documentUploadDetailsFragment.getParentView().mainScroll, documentUploadDetailsFragment.getParentView().primaryEnd);
                showToast(documentUploadDetailsFragment.getContext(), documentUploadDetailsFragment.getString(R.string.primary_end_date));
            }
        } else {
            scrollToView(documentUploadDetailsFragment.getParentView().mainScroll, documentUploadDetailsFragment.getParentView().primaryStart);
            showToast(documentUploadDetailsFragment.getContext(), documentUploadDetailsFragment.getString(R.string.primary_start_date));
        }

        return false;
    }

    private boolean isValidStateentDateRange(String start, String end) {
        String startDate[] = start.trim().split("-");
        String endDate[] = end.trim().split("-");

        Calendar startCalendar = new GregorianCalendar();
        startCalendar.setTime(new Date(Integer.parseInt(startDate[0]), Integer.parseInt(startDate[1]), Integer.parseInt(startDate[2])));
        Calendar endCalendar = new GregorianCalendar();
        endCalendar.setTime(new Date(Integer.parseInt(endDate[0]), Integer.parseInt(endDate[1]), Integer.parseInt(endDate[2])));
        int diffYear = endCalendar.get(Calendar.YEAR) - startCalendar.get(Calendar.YEAR);
        int diffMonth = diffYear * 12 + endCalendar.get(Calendar.MONTH) - startCalendar.get(Calendar.MONTH);

        if (diffMonth >= 9) {
            return true;
        } else {
            return false;
        }

    }

    private boolean cansubmit() {
        if (!ShowFirstYearITRUploaded.get()) {
            if (!ShowSecondYearITRUpload.get()) {
                if (!TextUtils.isEmpty(completeTextView.getText())
                        && !TextUtils.isEmpty(selectedBankName)) {
                    if (!TextUtils.isEmpty(accountType)) {

                        if (documentUploadDetailsFragment.getParentView().secBankLayout.getVisibility() == View.VISIBLE) {
                            if (!TextUtils.isEmpty(selectedSecondarBankName) || (arrSecBankItems != null && arrSecBankItems.size() > 0) || !TextUtils.isEmpty(SecondaryaccountType)) {
                                if (!TextUtils.isEmpty(seccompleteTextView.getText())
                                        && !TextUtils.isEmpty(selectedSecondarBankName)) {
                                    if (!TextUtils.isEmpty(SecondaryaccountType)) {
                                        if (arrSecBankItems != null && arrSecBankItems.size() > 0) {
                                            return true;
                                        } else {
                                            scrollToView(documentUploadDetailsFragment.getParentView().mainScroll, documentUploadDetailsFragment.getParentView().secBankLayout);
                                            showToast(documentUploadDetailsFragment.getContext(), documentUploadDetailsFragment.getString(R.string.upload_secbankfile));
                                        }
                                    } else {

                                        scrollToView(documentUploadDetailsFragment.getParentView().mainScroll, documentUploadDetailsFragment.getParentView().secAccountTypeText);
                                        showToast(documentUploadDetailsFragment.getContext(), documentUploadDetailsFragment.getString(R.string.select_sec_accounttype));
                                    }
                                } else {
                                    scrollToView(documentUploadDetailsFragment.getParentView().mainScroll, documentUploadDetailsFragment.getParentView().secBankListBox);
                                    showToast(documentUploadDetailsFragment.getContext(), documentUploadDetailsFragment.getString(R.string.slect_sec_primary_bank));
                                    documentUploadDetailsFragment.getParentView().secBankListBox.requestFocus();
                                }
                            } else {
                                scrollToView(documentUploadDetailsFragment.getParentView().mainScroll, documentUploadDetailsFragment.getParentView().secBankListBox);
                                showToast(documentUploadDetailsFragment.getContext(), documentUploadDetailsFragment.getString(R.string.slect_sec_primary_bank));
                                documentUploadDetailsFragment.getParentView().secBankListBox.requestFocus();
                            }
                        } else {
                            return true;
                        }

                    } else {
                        scrollToView(documentUploadDetailsFragment.getParentView().mainScroll, documentUploadDetailsFragment.getParentView().accountTypeText);
                        showToast(documentUploadDetailsFragment.getContext(), documentUploadDetailsFragment.getString(R.string.select_accounttype));
                    }
                } else {
                    scrollToView(documentUploadDetailsFragment.getParentView().mainScroll, documentUploadDetailsFragment.getParentView().bankListBox);
                    showToast(documentUploadDetailsFragment.getContext(), documentUploadDetailsFragment.getString(R.string.slect_primary_bank));
                    documentUploadDetailsFragment.getParentView().bankListBox.requestFocus();
                }
            } else {
                scrollToView(documentUploadDetailsFragment.getParentView().mainScroll, documentUploadDetailsFragment.getParentView().lasToLastItrLayout);
                showToast(documentUploadDetailsFragment.getContext(), documentUploadDetailsFragment.getString(R.string.give__last_to_last_itr));
            }
        } else {
            scrollToView(documentUploadDetailsFragment.getParentView().mainScroll, documentUploadDetailsFragment.getParentView().lastYearItrLayout);
            showToast(documentUploadDetailsFragment.getContext(), documentUploadDetailsFragment.getString(R.string.give_itr));
        }
        return false;
    }

    private void scrollToView(final ScrollView scrollViewParent, final View view) {
        Point childOffset = new Point();
        getDeepChildOffset(scrollViewParent, view.getParent(), view, childOffset);
        scrollViewParent.smoothScrollTo(0, childOffset.y);
    }

    private void getDeepChildOffset(final ViewGroup mainParent, final ViewParent parent, final View child, final Point accumulatedOffset) {
        ViewGroup parentGroup = (ViewGroup) parent;
        accumulatedOffset.x += child.getLeft();
        accumulatedOffset.y += child.getTop();
        if (parentGroup.equals(mainParent)) {
            return;
        }
        getDeepChildOffset(mainParent, parentGroup.getParent(), parentGroup, accumulatedOffset);
    }

    private void openCameraGalleryOptions(final boolean multi_selection) {
        openFile();
    }

    private void openGallery(boolean multi_selection) {
        Intent intent = new Intent();
        intent.setType("image/*");
        intent.setAction(Intent.ACTION_GET_CONTENT);
        documentUploadDetailsFragment.startActivityForResult(Intent.createChooser(intent, "Select Picture"), Constant.GALLERY_REQUEST);
    }

    private void openFile() {
        String[] suffix = new String[]{"txt", "pdf", "zip"};
        Intent intents = new Intent(documentUploadDetailsFragment.getContext(), FilePickerActivity.class);
        intents.putExtra(FilePickerActivity.CONFIGS, new Configurations.Builder()
                .setCheckPermission(true)
                .setShowFiles(true)
                .setShowImages(true)
                .enableImageCapture(true)
                .setMaxSelection(1)
                .setSkipZeroSizeFiles(true)
                .setShowImages(true)
                .setShowFiles(true)
                .setShowVideos(false)
                .setShowAudios(false)
                .setSingleClickSelection(true)
                .build());
        documentUploadDetailsFragment.startActivityForResult(intents, Constant.FILE_REQUEST);
    }

    private void launchFilePicker() {
        // Launch intent to pick file for upload
        Intent intent = new Intent(Intent.ACTION_GET_CONTENT);
        intent.addCategory(Intent.CATEGORY_OPENABLE);
        intent.setType("*/*");
        documentUploadDetailsFragment.startActivityForResult(intent, Constant.FILE_REQUEST);
    }

    private void openCamera() {
        capturedImageUri = FileProvider.getUriForFile(documentUploadDetailsFragment.getContext(),
                documentUploadDetailsFragment.getContext().getPackageName() + ".provider", createImageFile());
        Intent cameraIntent = new Intent(MediaStore.ACTION_IMAGE_CAPTURE);
        cameraIntent.setFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION);
        cameraIntent.putExtra(MediaStore.EXTRA_OUTPUT, capturedImageUri);
        documentUploadDetailsFragment.startActivityForResult(cameraIntent, Constant.CAMERA_REQUEST);
    }

    public Uri getCapturedImageUri() {
        return capturedImageUri;
    }

    private File createImageFile() {
        try {
            String timeStamp = new SimpleDateFormat("yyyyMMdd_HHmmss", Locale.ENGLISH).format(new Date());
            String imageFileName = "JPEG_" + timeStamp + "_";
            File storageDir = Environment.getExternalStoragePublicDirectory(
                    Environment.DIRECTORY_PICTURES);
            File image = File.createTempFile(
                    imageFileName,  // prefix
                    ".jpg",         // suffix
                    storageDir      // directory
            );
            mCurrentPhotoPath = "file://" + image.getAbsolutePath();
            return image;
        } catch (Exception e) {
        }
        return null;
    }

    private void uploadFiles(ZiploanPhoto arrImages) {
        int bucket_id;
        String file_type;
        String bank_type = "";
        if (currentSelectedDoc == FIRST_YEAR_ITR || currentSelectedDoc == SECOND_YEAR_ITR || currentSelectedDoc == ANOTHER_YEAR_ITR) {
            file_type = Constant.FileType.PD_BUSINESS_PLACE_PHOTO;
            bucket_id = Constant.FileUploadBucketId.ITR;
        } else if (currentSelectedDoc == BANK_STATEMENT_UPLOAD || currentSelectedDoc == SEC_BANK_STATEMENT_UPLOAD) {
            if (currentSelectedDoc == BANK_STATEMENT_UPLOAD)
                bank_type = Constant.BankType.PRIMERY;
            else
                bank_type = Constant.BankType.SECONDARY;

            file_type = Constant.FileType.PD_BUSINESS_PLACE_PHOTO;
            bucket_id = Constant.FileUploadBucketId.BANKSTATEMENT;
        } else {
            file_type = Constant.FileType.KYC_BUSINESS_DOCUMENTS;
            bucket_id = Constant.FileUploadBucketId.BUSINESS_PLACE_PHOTO;
        }

        FileUploader.getInstance(documentUploadDetailsFragment.getContext())
                .upload(file_type, arrImages,
                        bucket_id,
                        loan_req_id, bank_type, new PhotoUploadListener() {
                            @Override
                            public void onUploadSuccess(ZiploanPhoto photo) {
                                photo.setUpload_status(Constant.UploadStatus.UPLOADING_SUCCESS);
                                if (currentSelectedDoc == FIRST_YEAR_ITR) {
                                    ShowFirstYearITRUploaded.set(false);
                                    ShowFirstYearITRUploadeding.set(false);
                                    setFirstItrBankData(photo);
                                } else if (currentSelectedDoc == SECOND_YEAR_ITR) {
                                    ShowSecondYearITRUploading.set(false);
                                    ShowSecondYearITRUpload.set(false);
                                    setLastItrBankData(photo);
                                } else if (currentSelectedDoc == ANOTHER_YEAR_ITR) {
                                    ShowAnotherYearITRUpload.set(false);
                                    ShowAnotherYearITRUploading.set(false);
                                    setAnotherItrBankData(photo);
                                } else if (currentSelectedDoc == BANK_STATEMENT_UPLOAD) {
                                    BankStatementUpload.set(true);
                                    BankStatementUploading.set(false);
                                    setPrimeryBankData(photo);
                                } else if (currentSelectedDoc == SEC_BANK_STATEMENT_UPLOAD) {
                                    SecBankStatementUpload.set(true);
                                    SecBankStatementUploading.set(false);
                                    setSecBankData(photo);
                                } else if (currentSelectedDoc == KYC_UPLOAD) {
                                    KYCStatementUpload.set(true);
                                    KYCBankStatementUploading.set(false);
                                    setKycBankData(photo);
                                }
                            }

                            @Override
                            public void onUploadFailed(ZiploanPhoto photo) {
                                photo.setUpload_status(Constant.UploadStatus.UPLOADING_FAILED);

                                if (!TextUtils.isEmpty(photo.getError_message()))
                                    showToast(documentUploadDetailsFragment.getContext(), photo.getError_message());

                                if (currentSelectedDoc == FIRST_YEAR_ITR) {
                                    ShowFirstYearITRUploaded.set(true);
                                    ShowFirstYearITRUploadeding.set(false);
                                } else if (currentSelectedDoc == SECOND_YEAR_ITR) {
                                    ShowSecondYearITRUploading.set(false);
                                    ShowSecondYearITRUpload.set(true);
                                } else if (currentSelectedDoc == BANK_STATEMENT_UPLOAD) {
                                    BankStatementUpload.set(true);
                                    BankStatementUploading.set(false);
                                } else if (currentSelectedDoc == SEC_BANK_STATEMENT_UPLOAD) {
                                    SecBankStatementUpload.set(true);
                                    SecBankStatementUploading.set(false);
                                } else if (currentSelectedDoc == KYC_UPLOAD) {
                                    KYCStatementUpload.set(true);
                                    KYCBankStatementUploading.set(false);
                                } else if (currentSelectedDoc == ANOTHER_YEAR_ITR) {
                                    ShowAnotherYearITRUpload.set(true);
                                    ShowAnotherYearITRUploading.set(false);
                                }
                            }

                            @Override
                            public void onUploadStarted(ZiploanPhoto photo) {
                                photo.setUpload_status(Constant.UploadStatus.UPLOADING_STARTED);
                                if (currentSelectedDoc == FIRST_YEAR_ITR) {
                                    ShowFirstYearITRUploaded.set(false);
                                    ShowFirstYearITRUploadeding.set(true);
                                } else if (currentSelectedDoc == SECOND_YEAR_ITR) {
                                    ShowSecondYearITRUploading.set(true);
                                    ShowSecondYearITRUpload.set(false);
                                } else if (currentSelectedDoc == BANK_STATEMENT_UPLOAD) {
                                    BankStatementUpload.set(false);
                                    BankStatementUploading.set(true);
                                } else if (currentSelectedDoc == SEC_BANK_STATEMENT_UPLOAD) {
                                    SecBankStatementUpload.set(false);
                                    SecBankStatementUploading.set(true);
                                } else if (currentSelectedDoc == KYC_UPLOAD) {
                                    KYCStatementUpload.set(false);
                                    KYCBankStatementUploading.set(true);
                                } else if (currentSelectedDoc == ANOTHER_YEAR_ITR) {
                                    ShowAnotherYearITRUpload.set(false);
                                    ShowAnotherYearITRUploading.set(true);
                                }
                            }
                        });
    }


    public void getImages(ZiploanPhoto arrImages, int sourceType) {
        uploadFiles(arrImages);
    }

    private void submitLoanRequest(DocumentUploadDetailsFragment personalDetailsFragment) {
//        if(!TextUtils.isEmpty(selectedBankName)){
//            if(!TextUtils.isEmpty(accountType)){
//
//            } else {
//                showToast(personalDetailsFragment.getContext(),personalDetailsFragment.getString(R.string.select_account_type_primary));
//            }
//        } else {
//            showToast(personalDetailsFragment.getContext(),personalDetailsFragment.getString(R.string.select_primary_bank));
//        }
        showLoading(documentUploadDetailsFragment.getContext());
        PostDocumentRequest postDocumentRequest = new PostDocumentRequest();
        postDocumentRequest.setLoanRequestId(loan_req_id);

        Primary primary = new Primary();
        primary.setAccountType(accountType);
        primary.setBankName(selectedBankName);
        primary.setPassword(PrimeryBankPassword.get());


        Log.d("pDate", PrimaryBankStartDate.get());
        Log.d("pDate", PrimaryBankEndDate.get());

        primary.setStartDate(PrimaryBankStartDate.get());
        primary.setEndDate(PrimaryBankEndDate.get());
        //primary.setEndDate(getDate(0));


        postDocumentRequest.setPrimary(primary);

        Secondary secondary = new Secondary();
        secondary.setAccountType(SecondaryaccountType);
        secondary.setBankName(selectedSecondarBankName);
        secondary.setPassword(SecondaryBankPassword.get());


        Log.d("sDate", PrimaryBankStartDate.get());
        Log.d("sDate", PrimaryBankEndDate.get());

        secondary.setStartDate(SecondaryBankStartDate.get());
        secondary.setEndDate(SecondaryBankEndDate.get());
//        secondary.setStartDate(getDate(1));
//        secondary.setEndDate(getDate(0));
        postDocumentRequest.setSecondary(secondary);


        Call<MobileVerificationResponse> mobileVerificationResponseCall;
//        if(formResponse != null && formResponse.getDocumentsFilled())
//         mobileVerificationResponseCall = APIExecutor.getAPIService().patchLoanReq(postDocumentRequest);
//        else
        mobileVerificationResponseCall = APIExecutor.getAPIService().postLoanReq(postDocumentRequest);

        mobileVerificationResponseCall.enqueue(new Callback<MobileVerificationResponse>() {
            @Override
            public void onResponse(Call<MobileVerificationResponse> call, Response<MobileVerificationResponse> response) {
                if (response.isSuccessful()
                        && response.body() != null) {
                    if (response.body().getStatus().equalsIgnoreCase(Constant.SUCCESS)) {
                        NavController.getInstance().addFragment(SuccessFragment.newInstance(true), true);
                    } else {
                        NavController.getInstance().addFragment(SuccessFragment.newInstance(false, response.body().getStatusMessage()), true);
                    }
                } else {
                    if (response.body() != null)
                        showToast(personalDetailsFragment.getContext(), response.body().getStatusMessage());
                }
                hideLoading();
            }

            @Override
            public void onFailure(Call<MobileVerificationResponse> call, Throwable t) {
                hideLoading();
            }
        });
    }

    private String getDate(int year) {
        Calendar cal = Calendar.getInstance();
        Date today = cal.getTime();
        cal.add(Calendar.YEAR, -year); // to get previous year add -1
        Date date = cal.getTime();


        SimpleDateFormat sdf = new SimpleDateFormat("EEE,MMMM d,yyyy h:mm,a", Locale.ENGLISH);

        return sdf.format(date);
    }

    public void setBankRecycler(RecyclerView bankRecycler) {
        bankRecycler.setAdapter(getPrimeryBankAdapter());
    }

    public void setSecBankRecycler(RecyclerView bankRecycler) {
        bankRecycler.setAdapter(getSecBankAdapter());
    }

    public void setKycBankRecycler(RecyclerView bankRecycler) {
        bankRecycler.setAdapter(getKycBankAdapter());
    }

    public void setFirstItrBankRecycler(RecyclerView bankRecycler) {
        bankRecycler.setAdapter(getFirstItrBankAdapter());
    }

    public void setLastItrBankRecycler(RecyclerView bankRecycler) {
        bankRecycler.setAdapter(getLastItrBankAdapter());
    }

    public void setAnotherItrBankRecycler(RecyclerView bankRecycler) {
        bankRecycler.setAdapter(getAnotherItrBankAdapter());
    }

    @Override
    protected void yesClicked() {
        NavController.getInstance().clearBack();
        NavController
                .getInstance()
                .addFragment(HomeFragment.newInstance(), false);
    }

    private void setPrimeryBankData(ZiploanPhoto photo) {
        photo.setDocument_number("Uploaded File " + (arrPrimeryBankItems.size() + 1));
        arrPrimeryBankItems.add(photo);
        adapterPrimeryBank.clear();
        adapterPrimeryBank.setItems(arrPrimeryBankItems);
    }

    private void setSecBankData(ZiploanPhoto photo) {
        photo.setDocument_number("Uploaded File " + (arrSecBankItems.size() + 1));
        arrSecBankItems.add(photo);
        adapterSecBank.clear();
        adapterSecBank.setItems(arrSecBankItems);
    }

    private void setKycBankData(ZiploanPhoto photo) {
        photo.setDocument_number("Uploaded File " + (arrKycBankItems.size() + 1));
        arrKycBankItems.add(photo);
        adapterKycBank.clear();
        adapterKycBank.setItems(arrKycBankItems);
    }

    private void setLastItrBankData(ZiploanPhoto photo) {
        arrLastItrBankItems.add(photo);
        adapterLastItrBank.clear();
        adapterLastItrBank.setItems(arrLastItrBankItems);
    }

    private void setAnotherItrBankData(ZiploanPhoto photo) {
        arrAnotherItrBankItems.add(photo);
        adapterAnotherItrBank.clear();
        adapterAnotherItrBank.setItems(arrAnotherItrBankItems);
    }

    private void setFirstItrBankData(ZiploanPhoto photo) {
        arrFirstItrBankItems.add(photo);
        adapterFirstItrBank.clear();
        adapterFirstItrBank.setItems(arrFirstItrBankItems);
    }

    private BindingAppAdapter<ZiploanPhoto> getPrimeryBankAdapter() {
        adapterPrimeryBank = new BindingAppAdapter<ZiploanPhoto>(new BindingAppAdapter.OnViewHolderClick<ZiploanPhoto>() {
            @Override
            public void onClick(View view, int position, ZiploanPhoto item) {
                switch (view.getId()) {
                    case R.id.view:
                        if (item.getPhotoPath().contains("http")) {
                            showImage(item.getPhotoPath());
                        } else {
                            Intent intent = new Intent();
                            intent.setAction(Intent.ACTION_VIEW);
                            File file = new File(item.getPhotoPath());
                            intent.setDataAndType(Uri.fromFile(file), item.getMedia_type());
                            intent.setFlags(Intent.FLAG_ACTIVITY_NEW_TASK);
                            documentUploadDetailsFragment.startActivity(intent);
                        }
                        break;

                    case R.id.delete:
                        int bucket_id;
                        bucket_id = Constant.FileUploadBucketId.BANKSTATEMENT;
                        String bank_type = "0";

                        adapterPrimeryBank.removeItem(position);
                        arrPrimeryBankItems.remove(position);
                        bank_type = Constant.BankType.PRIMERY;
                        BankStatementUpload.set(true);
                        FileUploader.getInstance(documentUploadDetailsFragment.getContext()).deleteFile(item, bucket_id, loan_req_id, bank_type);

                        List<ZiploanPhoto> ziploanPhotos = new ArrayList<>();
                        for (int i = 0; i < arrPrimeryBankItems.size(); i++) {
                            ZiploanPhoto ziploanPhoto = new ZiploanPhoto(item.getPhotoPath().contains("http") ? arrPrimeryBankItems.get(i).getPhotoPath() : Constant.MEDIA_URL + arrPrimeryBankItems.get(i).getPhotoPath());
                            ziploanPhoto.setRemote_path(arrPrimeryBankItems.get(i).getRemote_path());
                            ziploanPhoto.setDocument_number("Uploaded File " + (i + 1));
                            ziploanPhotos.add(ziploanPhoto);
                        }
                        arrPrimeryBankItems.clear();
                        arrPrimeryBankItems.addAll(ziploanPhotos);
                        adapterPrimeryBank.clear();
                        adapterPrimeryBank.setItems(arrPrimeryBankItems);

                        break;


                }
            }
        }) {
            @Override
            public int getLayout() {
                return R.layout.view_delete_layout;
            }
        };
        return adapterPrimeryBank;
    }

    private BindingAppAdapter<ZiploanPhoto> getSecBankAdapter() {
        adapterSecBank = new BindingAppAdapter<ZiploanPhoto>(new BindingAppAdapter.OnViewHolderClick<ZiploanPhoto>() {
            @Override
            public void onClick(View view, int position, ZiploanPhoto item) {
                switch (view.getId()) {
                    case R.id.view:
                        if (item.getPhotoPath().contains("http")) {
                            showImage(item.getPhotoPath());
                        } else {
                            Intent intent = new Intent();
                            intent.setAction(Intent.ACTION_VIEW);
                            File file = new File(item.getPhotoPath());
                            intent.setDataAndType(Uri.fromFile(file), item.getMedia_type());
                            intent.setFlags(Intent.FLAG_ACTIVITY_NEW_TASK);
                            documentUploadDetailsFragment.startActivity(intent);
                        }
                        break;

                    case R.id.delete:
                        int bucket_id;

                        bucket_id = Constant.FileUploadBucketId.BANKSTATEMENT;

                        String bank_type = "0";

                        bank_type = Constant.BankType.SECONDARY;
                        adapterSecBank.removeItem(position);
                        arrSecBankItems.remove(item);
                        SecBankStatementUpload.set(true);
                        FileUploader.getInstance(documentUploadDetailsFragment.getContext()).deleteFile(item, bucket_id, loan_req_id, bank_type);


                        List<ZiploanPhoto> ziploanPhotos = new ArrayList<>();
                        for (int i = 0; i < arrSecBankItems.size(); i++) {
                            ZiploanPhoto ziploanPhoto = new ZiploanPhoto(item.getPhotoPath().contains("http") ? arrSecBankItems.get(i).getPhotoPath() : Constant.MEDIA_URL + arrSecBankItems.get(i).getPhotoPath());
                            ziploanPhoto.setDocument_number("Uploaded File " + (i + 1));
                            ziploanPhoto.setRemote_path(arrSecBankItems.get(i).getRemote_path());
                            ziploanPhotos.add(ziploanPhoto);
                        }
                        arrSecBankItems.clear();
                        arrSecBankItems.addAll(ziploanPhotos);
                        adapterSecBank.clear();
                        adapterSecBank.setItems(arrSecBankItems);

                        break;
                }
            }
        }) {
            @Override
            public int getLayout() {
                return R.layout.view_delete_layout;
            }
        };
        return adapterSecBank;
    }

    private BindingAppAdapter<ZiploanPhoto> getKycBankAdapter() {
        adapterKycBank = new BindingAppAdapter<ZiploanPhoto>(new BindingAppAdapter.OnViewHolderClick<ZiploanPhoto>() {
            @Override
            public void onClick(View view, int position, ZiploanPhoto item) {
                switch (view.getId()) {
                    case R.id.view:
                        if (item.getPhotoPath().contains("http")) {
                            showImage(item.getPhotoPath());
                        } else {
                            Intent intent = new Intent();
                            intent.setAction(Intent.ACTION_VIEW);
                            File file = new File(item.getPhotoPath());
                            intent.setDataAndType(Uri.fromFile(file), item.getMedia_type());
                            intent.setFlags(Intent.FLAG_ACTIVITY_NEW_TASK);
                            documentUploadDetailsFragment.startActivity(intent);
                        }
                        break;

                    case R.id.delete:
                        int bucket_id = 0;
                        bucket_id = Constant.FileUploadBucketId.BUSINESS_PLACE_PHOTO;
                        adapterKycBank.removeItem(position);
                        arrKycBankItems.remove(position);
                        KYCStatementUpload.set(true);
                        FileUploader.getInstance(documentUploadDetailsFragment.getContext()).deleteFile(item, bucket_id, loan_req_id, "");

                        List<ZiploanPhoto> ziploanPhotos = new ArrayList<>();
                        for (int i = 0; i < arrKycBankItems.size(); i++) {
//                            ZiploanPhoto ziploanPhoto = new ZiploanPhoto(Constant.MEDIA_URL + arrKycBankItems.get(i).getPhotoPath());
                            ZiploanPhoto ziploanPhoto = new ZiploanPhoto(item.getPhotoPath().contains("http") ? arrKycBankItems.get(i).getPhotoPath() : Constant.MEDIA_URL + arrKycBankItems.get(i).getPhotoPath());
                            ziploanPhoto.setRemote_path(arrKycBankItems.get(i).getRemote_path());
                            ziploanPhoto.setDocument_number("Uploaded File " + (i + 1));
                            ziploanPhotos.add(ziploanPhoto);
                        }
                        arrKycBankItems.clear();
                        arrKycBankItems.addAll(ziploanPhotos);
                        adapterKycBank.clear();
                        adapterKycBank.setItems(arrKycBankItems);
                        break;
                }
            }
        }) {
            @Override
            public int getLayout() {
                return R.layout.view_delete_layout;
            }
        };
        return adapterKycBank;
    }

    private BindingAppAdapter<ZiploanPhoto> getFirstItrBankAdapter() {
        adapterFirstItrBank = new BindingAppAdapter<ZiploanPhoto>(this::firstItrselected) {
            @Override
            public int getLayout() {
                return R.layout.view_delete_without_text;
            }
        };
        return adapterFirstItrBank;
    }

    private void firstItrselected(View view, int position, ZiploanPhoto item) {
        switch (view.getId()) {
            case R.id.view:
                Intent intent = new Intent();
                intent.setAction(Intent.ACTION_VIEW);
                if (item.getPhotoPath().contains("http")) {
                    showImage(item.getPhotoPath());
                } else {
                    File file = new File(item.getPhotoPath());
                    intent.setDataAndType(Uri.fromFile(file), item.getMedia_type());
                    intent.setFlags(Intent.FLAG_ACTIVITY_NEW_TASK);
                    documentUploadDetailsFragment.startActivity(intent);
                }
                break;

            case R.id.delete:
                int bucket_id;
                adapterFirstItrBank.removeItem(position);
                arrFirstItrBankItems.remove(item);
                ShowFirstYearITRUploaded.set(true);
                bucket_id = Constant.FileUploadBucketId.ITR;
                FileUploader.getInstance(documentUploadDetailsFragment.getContext()).deleteFile(item, bucket_id, loan_req_id, "");
                break;
        }
    }

    private BindingAppAdapter<ZiploanPhoto> getLastItrBankAdapter() {
        adapterLastItrBank = new BindingAppAdapter<ZiploanPhoto>(new BindingAppAdapter.OnViewHolderClick<ZiploanPhoto>() {
            @Override
            public void onClick(View view, int position, ZiploanPhoto item) {
                switch (view.getId()) {
                    case R.id.view:
                        Intent intent = new Intent();
                        intent.setAction(Intent.ACTION_VIEW);
                        File file = null;
                        if (item.getPhotoPath().contains("http")) {
                            showImage(item.getPhotoPath());
                        } else {
                            file = new File(item.getPhotoPath());
                            intent.setDataAndType(Uri.fromFile(file), item.getMedia_type());
                            intent.setFlags(Intent.FLAG_ACTIVITY_NEW_TASK);
                            documentUploadDetailsFragment.startActivity(intent);
                        }

                        break;

                    case R.id.delete:
                        int bucket_id;

                        adapterLastItrBank.removeItem(position);
                        arrLastItrBankItems.remove(item);
                        ShowSecondYearITRUpload.set(true);
                        bucket_id = Constant.FileUploadBucketId.ITR;

                        String bank_type = "0";

                        FileUploader.getInstance(documentUploadDetailsFragment.getContext()).deleteFile(item, bucket_id, loan_req_id, bank_type);
                        break;
                }
            }
        }) {
            @Override
            public int getLayout() {
                return R.layout.view_delete_without_text;
            }
        };
        return adapterLastItrBank;
    }

    private BindingAppAdapter<ZiploanPhoto> getAnotherItrBankAdapter() {
        adapterAnotherItrBank = new BindingAppAdapter<ZiploanPhoto>(new BindingAppAdapter.OnViewHolderClick<ZiploanPhoto>() {
            @Override
            public void onClick(View view, int position, ZiploanPhoto item) {
                switch (view.getId()) {
                    case R.id.view:
                        Intent intent = new Intent();
                        intent.setAction(Intent.ACTION_VIEW);
                        if (item.getPhotoPath().contains("http")) {
                            showImage(item.getPhotoPath());
                        } else {
                            File file = new File(item.getPhotoPath());
                            intent.setDataAndType(Uri.fromFile(file), item.getMedia_type());
                            intent.setFlags(Intent.FLAG_ACTIVITY_NEW_TASK);
                            documentUploadDetailsFragment.startActivity(intent);
                        }

                        break;

                    case R.id.delete:
                        int bucket_id;

                        adapterAnotherItrBank.removeItem(position);
                        arrAnotherItrBankItems.remove(item);
                        ShowAnotherYearITRUpload.set(true);
                        bucket_id = Constant.FileUploadBucketId.ITR;

                        String bank_type = "0";

                        FileUploader.getInstance(documentUploadDetailsFragment.getContext()).deleteFile(item, bucket_id, loan_req_id, bank_type);
                        break;
                }
            }
        }) {
            @Override
            public int getLayout() {
                return R.layout.view_delete_without_text;
            }
        };
        return adapterAnotherItrBank;
    }

    private void selected(View view, int position, ZiploanPhoto item) {
        switch (view.getId()) {
            case R.id.view:
                Intent intent = new Intent();
                intent.setAction(Intent.ACTION_VIEW);
                File file = new File(item.getPhotoPath());
                intent.setDataAndType(Uri.fromFile(file), item.getMedia_type());
                intent.setFlags(Intent.FLAG_ACTIVITY_NEW_TASK);
                documentUploadDetailsFragment.startActivity(intent);
                break;

            case R.id.delete:
                int bucket_id;
                if (currentSelectedDoc == FIRST_YEAR_ITR || currentSelectedDoc == SECOND_YEAR_ITR) {
                    if (currentSelectedDoc == FIRST_YEAR_ITR) {
                        adapterFirstItrBank.removeItem(position);
                        arrFirstItrBankItems.remove(item);
                    } else {
                        adapterLastItrBank.removeItem(position);
                        arrLastItrBankItems.remove(item);
                    }
                    bucket_id = Constant.FileUploadBucketId.ITR;
                } else if (currentSelectedDoc == BANK_STATEMENT_UPLOAD || currentSelectedDoc == SEC_BANK_STATEMENT_UPLOAD) {
                    bucket_id = Constant.FileUploadBucketId.BANKSTATEMENT;
                } else {
                    bucket_id = Constant.FileUploadBucketId.BUSINESS_PLACE_PHOTO;
                }

                String bank_type = "0";
                if (currentSelectedDoc == BANK_STATEMENT_UPLOAD || currentSelectedDoc == SEC_BANK_STATEMENT_UPLOAD) {
                    if (currentSelectedDoc == BANK_STATEMENT_UPLOAD) {
                        adapterPrimeryBank.removeItem(position);
                        arrPrimeryBankItems.remove(item);
                        bank_type = Constant.BankType.PRIMERY;
                    } else {
                        bank_type = Constant.BankType.SECONDARY;
                        adapterSecBank.removeItem(position);
                        arrSecBankItems.remove(item);
                    }
                }

                if (currentSelectedDoc == KYC_UPLOAD) {
                    adapterKycBank.removeItem(position);
                    arrKycBankItems.remove(item);
                }

                FileUploader.getInstance(documentUploadDetailsFragment.getContext()).deleteFile(item, bucket_id, loan_req_id, bank_type);
                break;
        }
    }

    private void getLoanList() {
        Map<String, String> query = new HashMap<>();
        Call<BankListResponse> call = APIExecutor.getAPIService().bankList(query);
        call.enqueue(new Callback<BankListResponse>() {
            @Override
            public void onResponse(Call<BankListResponse> call, Response<BankListResponse> response) {
                if (response.isSuccessful()
                        && response.body() != null
                        && response.body().getResponse() != null) {
                    bankList.addAll(response.body().getResponse());
                    SecBankList.addAll(response.body().getResponse());
                    if (bankadapter != null)
                        bankadapter.addAll(response.body().getResponse());
                    if (secBankadapter != null)
                        secBankadapter.addAll(response.body().getResponse());

                    try {
                        if (DocumentResponse != null) {
                            if (DocumentResponse.getScanned() != null && DocumentResponse.getScanned().get1() != null) {
                                for (int i = 0; i < bankList.size(); i++) {
                                    if (bankList.get(i).getBankName().equalsIgnoreCase(DocumentResponse.getScanned().get1().getBankName())
                                            || bankList.get(i).getBankDisplayName().equalsIgnoreCase(DocumentResponse.getScanned().get1().getBankName())) {
                                        completeTextView.setListSelection(i);
                                        completeTextView.setText(bankList.get(i).getBankName());
                                        selectedBankName = bankList.get(i).getBankName();
                                        break;
                                    }
                                }
                            }

                            if (DocumentResponse.getScanned() != null && DocumentResponse.getScanned().get2() != null) {
                                for (int i = 0; i < bankList.size(); i++) {
                                    if (bankList.get(i).getBankName().equalsIgnoreCase(DocumentResponse.getScanned().get2().getBankName())
                                            || bankList.get(i).getBankDisplayName().equalsIgnoreCase(DocumentResponse.getScanned().get2().getBankName())) {
                                        seccompleteTextView.setListSelection(i);
                                        seccompleteTextView.setText(bankList.get(i).getBankName());
                                        selectedSecondarBankName = bankList.get(i).getBankName();
                                        break;
                                    }
                                }
                            }
                        }
                    } catch (Exception r) {
                        r.printStackTrace();
                    }
                }
                hideLoading();
            }

            @Override
            public void onFailure(Call<BankListResponse> call, Throwable t) {
                hideLoading();
            }
        });
    }


    private ArrayAdapter<com.ziploan.dsaapp.model.bank_list.Response> getBanksAdapter() {
        bankadapter = new ArrayAdapter<com.ziploan.dsaapp.model.bank_list.Response>(documentUploadDetailsFragment.getContext(), android.R.layout.simple_dropdown_item_1line);
        return bankadapter;
    }

    private ArrayAdapter<com.ziploan.dsaapp.model.bank_list.Response> getSecBanksAdapter() {
        secBankadapter = new ArrayAdapter<com.ziploan.dsaapp.model.bank_list.Response>(documentUploadDetailsFragment.getContext(), android.R.layout.simple_dropdown_item_1line);
        return secBankadapter;
    }

    public void setBankListBox(AutoCompleteTextView completeTextView) {
        this.completeTextView = completeTextView;
        this.completeTextView.setAdapter(getBanksAdapter());
        this.completeTextView.setOnItemClickListener(new AdapterView.OnItemClickListener() {
            @Override
            public void onItemClick(AdapterView<?> adapterView, View view, int i, long l) {
                if (bankList != null && bankList.size() > 0)
                    if (i != -1) {
                        selectedBankName = ((com.ziploan.dsaapp.model.bank_list.Response) adapterView.getItemAtPosition(i)).getBankName();
                        hideSoftKeyboard(documentUploadDetailsFragment.getContext());
                    }
            }
        });

    }

    public void setSecBankListBox(AutoCompleteTextView completeTextView) {
        this.seccompleteTextView = completeTextView;
        this.seccompleteTextView.setAdapter(getSecBanksAdapter());
        this.seccompleteTextView.setOnItemClickListener(new AdapterView.OnItemClickListener() {
            @Override
            public void onItemClick(AdapterView<?> adapterView, View view, int i, long l) {
                if (SecBankList != null && SecBankList.size() > 0) {
                    if (i != -1)
                        selectedSecondarBankName = ((com.ziploan.dsaapp.model.bank_list.Response) adapterView.getItemAtPosition(i)).getBankName();
                }
            }
        });
    }


    private void getDocuments() {
        showLoading(documentUploadDetailsFragment.getContext());
        Map<String, String> query = new HashMap<>();
        query.put("loan_request_id", loan_req_id);
        Call<GetDocumentResponse> call = APIExecutor.getAPIService().getDocuments(query);
        call.enqueue(new Callback<GetDocumentResponse>() {
            @Override
            public void onResponse(Call<GetDocumentResponse> call, Response<GetDocumentResponse> response) {
                if (response.isSuccessful()
                        && response.body() != null
                        && response.body().getResponse() != null) {
                    filldata(response.body().getResponse());
                }
                hideLoading();
            }

            @Override
            public void onFailure(Call<GetDocumentResponse> call, Throwable t) {
                hideLoading();
            }
        });
    }

    private void filldata(com.ziploan.dsaapp.model.response.document.Response response) {
        DocumentResponse = response;
        if (response.getItrData() != null) {
            for (int i = 0; i < response.getItrData().size(); i++) {
                if (i == 0) {
                    ShowFirstYearITRUploaded.set(false);
                    ShowFirstYearITRUploadeding.set(false);
                    List<ZiploanPhoto> ziploanPhotos = new ArrayList<>();
                    ZiploanPhoto ziploanPhoto=null;
                    if (BuildConfig.BUILD_TYPE.equalsIgnoreCase("qa")||BuildConfig.BUILD_TYPE.equalsIgnoreCase("prep")) {
                        ziploanPhoto = new ZiploanPhoto(Constant.MEDIA_URL +"/media/"+ response.getItrData().get(i).getItrUrl());

                    }else{
                        ziploanPhoto = new ZiploanPhoto(Constant.MEDIA_URL +"media/"+ response.getItrData().get(i).getItrUrl());

                    }

                    ziploanPhoto.setRemote_path(response.getItrData().get(i).getItrUrl());
                    ziploanPhotos.add(ziploanPhoto);
                    arrFirstItrBankItems.addAll(ziploanPhotos);
                    adapterFirstItrBank.setItems(ziploanPhotos);
                } else if (i == 1) {
                    ShowSecondYearITRUploading.set(false);
                    ShowSecondYearITRUpload.set(false);
                    List<ZiploanPhoto> ziploanPhotos = new ArrayList<>();
                    ZiploanPhoto ziploanPhoto;
                    if (BuildConfig.BUILD_TYPE.equalsIgnoreCase("qa")||BuildConfig.BUILD_TYPE.equalsIgnoreCase("prep")) {
                        ziploanPhoto = new ZiploanPhoto(Constant.MEDIA_URL+"media/" + response.getItrData().get(i).getItrUrl());

                    }else{
                        ziploanPhoto = new ZiploanPhoto(Constant.MEDIA_URL+"media/"+ response.getItrData().get(i).getItrUrl());

                    }
                    ziploanPhoto.setRemote_path(response.getItrData().get(i).getItrUrl());
                    ziploanPhotos.add(ziploanPhoto);
                    arrLastItrBankItems.addAll(ziploanPhotos);
                    adapterLastItrBank.setItems(ziploanPhotos);
                } else if (i == 2) {
                    ShowAnotherYearITRUpload.set(false);
                    ShowAnotherYearITRUploading.set(false);
                    List<ZiploanPhoto> ziploanPhotos = new ArrayList<>();
                    ZiploanPhoto ziploanPhoto;
                    if (BuildConfig.BUILD_TYPE.equalsIgnoreCase("qa")||BuildConfig.BUILD_TYPE.equalsIgnoreCase("prep")) {
                        ziploanPhoto = new ZiploanPhoto(Constant.MEDIA_URL +"media/"+ response.getItrData().get(i).getItrUrl());

                    }else{
                        ziploanPhoto = new ZiploanPhoto(Constant.MEDIA_URL +"media/"+ response.getItrData().get(i).getItrUrl());

                    }
                    ziploanPhoto.setRemote_path(response.getItrData().get(i).getItrUrl());
                    ziploanPhotos.add(ziploanPhoto);
                    arrAnotherItrBankItems.addAll(ziploanPhotos);
                    adapterAnotherItrBank.setItems(ziploanPhotos);
                }
            }
        }

        if (response.getScanned() != null) {

            if (response.getScanned().get1() != null) {
                PrimeryBankPassword.set(response.getScanned().get1().getPassword());
                if (response.getScanned().get1().getAccountType() != null) {
                    if (response.getScanned().get1().getAccountType().equalsIgnoreCase("overdraft")) {
                        accountType = "overdraft";
                        SavingAccountTypeSelected.set(false);
                        CurrentAccountTypeSelected.set(false);
                        OverdraftAccountTypeSelected.set(true);
                        CCAccountTypeSelected.set(false);
                    } else if (response.getScanned().get1().getAccountType().equalsIgnoreCase("saving")) {
                        accountType = "saving";
                        SavingAccountTypeSelected.set(true);
                        CurrentAccountTypeSelected.set(false);
                        OverdraftAccountTypeSelected.set(false);
                        CCAccountTypeSelected.set(false);
                    } else if (response.getScanned().get1().getAccountType().equalsIgnoreCase("current")) {
                        accountType = "current";
                        SavingAccountTypeSelected.set(false);
                        CurrentAccountTypeSelected.set(true);
                        OverdraftAccountTypeSelected.set(false);
                        CCAccountTypeSelected.set(false);
                    } else if (response.getScanned().get1().getAccountType().equalsIgnoreCase("cc")) {
                        accountType = "cc";
                        SavingAccountTypeSelected.set(false);
                        CurrentAccountTypeSelected.set(false);
                        OverdraftAccountTypeSelected.set(false);
                        CCAccountTypeSelected.set(true);
                    }
                }
                try {
                    for (int i = 0; i < bankList.size(); i++) {
                        if (bankList.get(i).getBankName().equalsIgnoreCase(response.getScanned().get1().getBankName())
                                || bankList.get(i).getBankDisplayName().equalsIgnoreCase(response.getScanned().get1().getBankName())) {
                            completeTextView.setText(bankList.get(i).getBankName());
                            completeTextView.setListSelection(i);
                            selectedBankName = bankList.get(i).getBankName();
                            break;
                        }
                    }
                } catch (Exception r) {
                    r.printStackTrace();
                }

                List<ZiploanPhoto> ziploanPhotos = new ArrayList<>();
                for (int i = 0; i < response.getScanned().get1().getUrl().size(); i++) {
                    ZiploanPhoto ziploanPhoto=null;
                    if (BuildConfig.BUILD_TYPE.equalsIgnoreCase("qa")||BuildConfig.BUILD_TYPE.equalsIgnoreCase("prep")){
                        ziploanPhoto = new ZiploanPhoto(Constant.MEDIA_URL +"/media/"+ response.getScanned().get1().getUrl().get(i));
                    }else{
                        ziploanPhoto = new ZiploanPhoto(Constant.MEDIA_URL +"media/"+response.getScanned().get1().getUrl().get(i));
                    }

                    ziploanPhoto.setDocument_number("Uploaded File " + (i + 1));
                    ziploanPhoto.setRemote_path(response.getScanned().get1().getUrl().get(i));
                    ziploanPhotos.add(ziploanPhoto);
                }
                arrPrimeryBankItems.addAll(ziploanPhotos);
                adapterPrimeryBank.clear();
                adapterPrimeryBank.setItems(arrPrimeryBankItems);
            }

            if (response.getScanned().get2() != null) {
                SecBankStatementLayout.set(true);
                SecBankStatementText.set(false);

                SecondaryBankPassword.set(response.getScanned().get2().getPassword());
                if (response.getScanned().get2().getAccountType() != null) {
                    if (response.getScanned().get2().getAccountType().equalsIgnoreCase("overdraft")) {
                        SecondaryaccountType = "overdraft";
                        SecSavingAccountTypeSelected.set(false);
                        SecCurrentAccountTypeSelected.set(false);
                        SecOverdraftAccountTypeSelected.set(true);
                        SecCCAccountTypeSelected.set(false);
                    } else if (response.getScanned().get2().getAccountType().equalsIgnoreCase("saving")) {
                        SecondaryaccountType = "saving";
                        SecSavingAccountTypeSelected.set(true);
                        SecCurrentAccountTypeSelected.set(false);
                        SecOverdraftAccountTypeSelected.set(false);
                        SecCCAccountTypeSelected.set(false);
                    } else if (response.getScanned().get2().getAccountType().equalsIgnoreCase("current")) {
                        SecondaryaccountType = "current";
                        SecSavingAccountTypeSelected.set(false);
                        SecCurrentAccountTypeSelected.set(true);
                        SecOverdraftAccountTypeSelected.set(false);
                        SecCCAccountTypeSelected.set(false);
                    } else if (response.getScanned().get2().getAccountType().equalsIgnoreCase("cc")) {
                        SecondaryaccountType = "cc";
                        SecSavingAccountTypeSelected.set(false);
                        SecCurrentAccountTypeSelected.set(false);
                        SecOverdraftAccountTypeSelected.set(false);
                        SecCCAccountTypeSelected.set(true);
                    }
                }


                try {
                    for (int i = 0; i < bankList.size(); i++) {
                        if (bankList.get(i).getBankName().equalsIgnoreCase(response.getScanned().get2().getBankName())
                                || bankList.get(i).getBankDisplayName().equalsIgnoreCase(response.getScanned().get2().getBankName())) {
                            seccompleteTextView.setListSelection(i);
                            seccompleteTextView.setText(bankList.get(i).getBankDisplayName());
                            selectedSecondarBankName = bankList.get(i).getBankName();
                            break;
                        }
                    }
                } catch (Exception e) {
                    e.printStackTrace();
                }


                List<ZiploanPhoto> ziploanPhotos = new ArrayList<>();
                for (int i = 0; i < response.getScanned().get2().getUrl().size(); i++) {
                    ZiploanPhoto ziploanPhoto;
                    if (BuildConfig.BUILD_TYPE.equalsIgnoreCase("qa")||BuildConfig.BUILD_TYPE.equalsIgnoreCase("prep")) {
                        ziploanPhoto = new ZiploanPhoto(Constant.MEDIA_URL +"/media/"+ response.getScanned().get2().getUrl().get(i));

                    }else{
                        ziploanPhoto = new ZiploanPhoto(Constant.MEDIA_URL +"media/"+response.getScanned().get2().getUrl().get(i));

                    }
                    ziploanPhoto.setDocument_number("Uploaded File " + (i + 1));
                    ziploanPhoto.setRemote_path(response.getScanned().get2().getUrl().get(i));
                    ziploanPhotos.add(ziploanPhoto);
                }
                arrSecBankItems.addAll(ziploanPhotos);
                adapterSecBank.clear();
                adapterSecBank.setItems(arrSecBankItems);
                documentUploadDetailsFragment.requestfocus();
            }

        }

        if (response.getKycDocuments() != null && response.getKycDocuments().getKyc() != null && response.getKycDocuments().getKyc().size() > 0) {
            List<ZiploanPhoto> ziploanPhotos = new ArrayList<>();
            for (int i = 0; i < response.getKycDocuments().getKyc().size(); i++) {
                ZiploanPhoto ziploanPhoto;

                if (BuildConfig.BUILD_TYPE.equalsIgnoreCase("qa")||BuildConfig.BUILD_TYPE.equalsIgnoreCase("prep")) {
                    ziploanPhoto = new ZiploanPhoto(Constant.MEDIA_URL +"/media/"+ response.getKycDocuments().getKyc().get(i).getUrl());

                }else{
                    ziploanPhoto = new ZiploanPhoto(Constant.MEDIA_URL+"media/"+ response.getKycDocuments().getKyc().get(i).getUrl());

                }
                ziploanPhoto.setDocument_number("Uploaded File " + (i + 1));
                ziploanPhoto.setRemote_path(response.getKycDocuments().getKyc().get(i).getUrl());
                ziploanPhotos.add(ziploanPhoto);
            }
            arrKycBankItems.addAll(ziploanPhotos);
            adapterKycBank.clear();
            adapterKycBank.setItems(arrKycBankItems);
        }
    }

    @Override
    protected void getFormConfigResponse(com.ziploan.dsaapp.model.response.form_config.Response response) {
        this.formResponse = response;
        if (response != null) {
            MyApplication.formResponse = response;
            if (response.getShowPages().size() == 1) {
                if (response.getShowPages().get(0).equalsIgnoreCase("documents")) {
                    headerModelObservableField.set(HeaderModel.setForOnlyDocument());
                }
            } else {
                if (response.getDocumentsFilled()) {
                    if (response.getCoapplicantFilled()) {
                        headerModelObservableField.set(HeaderModel.setForDocumentFilledWithCoApplicant(Constant.DOCUMENT_INFO_TAG));
                    } else if (response.getShowPages().size() == 4) {
                        headerModelObservableField.set(HeaderModel.setForDocumentFilledWithCoApplicantunfilled(Constant.DOCUMENT_INFO_TAG));
                    } else {
                        headerModelObservableField.set(HeaderModel.setForDocumentFilled(Constant.DOCUMENT_INFO_TAG));
                    }
                } else if (response.getCoapplicantFilled()) {
                    headerModelObservableField.set(HeaderModel.setForCoapplicantFilled(Constant.DOCUMENT_INFO_TAG));
                } else if (response.getBusinessInfoFilled()) {
                    if (response.getShowPages().size() == 4) {
                        headerModelObservableField.set(HeaderModel.setForBusinessCoapplicantFilled(Constant.DOCUMENT_INFO_TAG));
                    } else {
                        headerModelObservableField.set(HeaderModel.setForBusinessFilled(Constant.DOCUMENT_INFO_TAG));
                    }
                } else if (response.getPersonalInfoFilled()) {
                    if (response.getCoapplicantFilled()) {
                        headerModelObservableField.set(HeaderModel.setForPersonalInfoFilledCo(Constant.DOCUMENT_INFO_TAG));
                    } else {
                        headerModelObservableField.set(HeaderModel.setForPersonalInfoFilled(Constant.DOCUMENT_INFO_TAG));
                    }
                } else
                    headerModelObservableField.set(HeaderModel.setForDocument());
            }
        } else
            headerModelObservableField.set(HeaderModel.setForDocument());
    }

    private void showImage(String url) {
//        Intent intent = new Intent();
//        intent.setAction(Intent.ACTION_VIEW);
//        intent.setFlags(Intent.FLAG_ACTIVITY_NEW_TASK | Intent.FLAG_ACTIVITY_CLEAR_TASK);
//        Bundle bundle = new Bundle();
//        bundle.putString(Constant.ACCESS_TOKEN, PreferencesManager.getInstance().getString(PreferencesManager.AUTH_TOKEN));
//        bundle.putString(Constant.ACCESS_ID, PreferencesManager.getInstance().getString(PreferencesManager.AUTH_ID));
//        intent.putExtra(Browser.EXTRA_HEADERS, bundle);
//        intent.setData(Uri.parse(url));
//        documentUploadDetailsFragment.startActivity(intent);


        if(NetworkUtils.isNetworkConnected(context)) {
            Bundle kycIntent = new Bundle();
//            kycIntent.putString("url", "https://webservices-qa.ziploan.in/restapis/media/5e3131ed217e2413a3a9f36c");
            kycIntent.putString("url",url);
            ViewerActivity.start(context, kycIntent);
        } else {
            showToast(context,context.getString(R.string.waiting_for_network));
        }
    }

    public void openPrimeryBankDialogue() {
        if (completeTextView != null)
            completeTextView.showDropDown();
    }

    public void openSecBankDialogue() {
        if (seccompleteTextView != null)
            seccompleteTextView.showDropDown();
    }
}