package com.ziploan.dsaapp.utils;

import android.content.Context;
import android.content.SharedPreferences;
import android.text.TextUtils;
import android.util.Patterns;

import java.util.regex.Pattern;

public class ZiploanDSAUtil {

    public static final String TAG = ZiploanDSAUtil.class.getName();
    public static final String SHARED_PREF_NAME = "ziploan_team_preference";
    public static final int PRIVATE_MODE = Context.MODE_PRIVATE;
    private static SharedPreferences _pref;
    private static ZiploanDSAUtil _instance;
    private static Context mContext;


    public ZiploanDSAUtil() {
    }

    public static ZiploanDSAUtil getInstance(Context context) {
        mContext = context;
        if (_pref == null) {
            _pref = context.getSharedPreferences(SHARED_PREF_NAME, PRIVATE_MODE);
        }
        if (_instance == null) {
            _instance = new ZiploanDSAUtil();
        }
        return _instance;
    }
    private void setString(String key, String value) {
        if (key != null && value != null) {
            try {
                if (_pref != null) {
                    SharedPreferences.Editor editor = _pref.edit();
                    editor.putString(key, value);
                    editor.apply();
                }
            } catch (Exception e) {
                //Logger.e(TAG, "Unable to set " + key + "= " + value + "in shared preference", e);
            }
        }
    }

    private void setLong(String key, long value) {
        if (key != null) {
            try {
                if (_pref != null) {
                    SharedPreferences.Editor editor = _pref.edit();
                    editor.putLong(key, value);
                    editor.apply();
                }
            } catch (Exception e) {
                // Logger.e(TAG, "Unable to set " + key + "= " + value + "in shared preference", e);
            }
        }
    }

    private void setInt(String key, int value) {
        if (key != null) {
            try {
                if (_pref != null) {
                    SharedPreferences.Editor editor = _pref.edit();
                    editor.putInt(key, value);
                    editor.apply();
                }
            } catch (Exception e) {
                // Logger.e(TAG, "Unable to set " + key + "= " + value + "in shared preference", e);
            }
        }
    }

    private void setDouble(String key, double value) {
        if (key != null) {
            try {
                if (_pref != null) {
                    SharedPreferences.Editor editor = _pref.edit();
                    editor.putFloat(key, (float) value);
                    editor.apply();
                }
            } catch (Exception e) {
                // Logger.e(TAG, "Unable to set " + key + "= " + value + "in shared preference", e);
            }
        }
    }

    private void setBoolean(String key, boolean value) {
        if (key != null) {
            try {
                if (_pref != null) {
                    SharedPreferences.Editor editor = _pref.edit();
                    editor.putBoolean(key, value);
                    editor.apply();
                }
            } catch (Exception e) {
                // Logger.e(TAG, "Unable to set " + key + "= " + value + "in shared preference", e);
            }
        }
    }

    private int getInt(String key, int defaultValue) {
        if (_pref != null && key != null && _pref.contains(key)) {
            return _pref.getInt(key, defaultValue);
        }
        return defaultValue;
    }

    private long getLong(String key, long defaultValue) {
        if (_pref != null && key != null && _pref.contains(key)) {
            return _pref.getLong(key, defaultValue);
        }
        return defaultValue;
    }

    private boolean getBoolean(String key, boolean defaultValue) {
        if (_pref != null && key != null && _pref.contains(key)) {
            return _pref.getBoolean(key, defaultValue);
        }
        return defaultValue;
    }

    private String getString(String key, String defaultValue) {
        if (_pref != null && key != null && _pref.contains(key)) {
            return _pref.getString(key, defaultValue);
        }
        return defaultValue;
    }

    private double getDouble(String key, double defaultValue) {
        if (_pref != null && key != null && _pref.contains(key)) {
            return _pref.getFloat(key, (float) defaultValue);
        }
        return defaultValue;
    }

    private void removeString(String key) {
        if (key != null) {
            try {
                if (_pref != null && _pref.contains(key)) {
                    SharedPreferences.Editor editor = _pref.edit();
                    editor.remove(key);
                    editor.apply();
                }
            } catch (Exception e) {
                // Logger.e(TAG, "Unable to remove key" + key, e);
            }
        }
    }

    public void setAccessToken(String accessToken) {
        setString(Constant.ACCESS_TOKEN, accessToken);
    }

    public String getAccessToken() {
        return getString(Constant.ACCESS_TOKEN, "");
    }

    public void setAccessId(String accessId) {
        setString(Constant.ACCESS_ID, accessId);
    }

    public String getAccessId() {
        return getString(Constant.ACCESS_ID, "");
    }

    public void setExpirationDate(String expirationDate) {
        setString(Constant.ACCESS_EXPIRATION_TIME, expirationDate);
    }

    public String getExpirationDate() {
        return getString(Constant.ACCESS_EXPIRATION_TIME, "");
    }

    public static boolean isValidMobile(String phone) {
        boolean check = false;
        final String regexStr = "^(?:(?:\\+|0{0,2})91(\\s*[\\-]\\s*)?|[0]?)?[6789]\\d{9}$";
        if(phone.matches(regexStr)){
            check =  true;
        }
        return check;
    }
}
