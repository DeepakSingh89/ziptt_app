package com.ziploan.dsaapp.base;

import android.content.Context;
import android.util.AttributeSet;
import android.view.View;

import java.util.HashMap;
import java.util.Map;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.recyclerview.widget.RecyclerView;

public class ZipRecyclerView extends RecyclerView {

    public enum Status {
        IDLE,
        LOADING,
        EMPTY,
        MORE
    }

    private Map<Status, View> views = new HashMap<>();

    private Status status = Status.LOADING;

    public ZipRecyclerView(Context context) {
        super(context);
    }

    public ZipRecyclerView(Context context, AttributeSet attrs) {
        super(context, attrs);
    }

    public ZipRecyclerView(Context context, AttributeSet attrs, int defStyle) {
        super(context, attrs, defStyle);
    }



    @NonNull
    final AdapterDataObserver observer = new AdapterDataObserver() {
        @Override
        public void onChanged() {
            super.onChanged();
            check();
        }

        @Override
        public void onItemRangeInserted(int positionStart, int itemCount) {
            super.onItemRangeInserted(positionStart, itemCount);
            check();
        }

        @Override
        public void onItemRangeRemoved(int positionStart, int itemCount) {
            super.onItemRangeRemoved(positionStart, itemCount);
            check();
        }
    };

    public void check() {
        for (Status status : Status.values()) {
            checkIf(status);
        }
    }

    private void checkIf(Status status) {
        View view = views.get(status);

        if (view != null) {
            view.setVisibility(GONE);

            if (this.status == status) {
                view.setVisibility(VISIBLE);
            }
        }
    }

    @Override
    public void setAdapter(@Nullable Adapter adapter) {
        replaceAdapter(adapter);
        super.setAdapter(adapter);
    }

    @Override
    public void swapAdapter(Adapter adapter, boolean removeAndRecycleExistingViews) {
        replaceAdapter(adapter);
        super.swapAdapter(adapter, removeAndRecycleExistingViews);
    }

    private void replaceAdapter(@Nullable Adapter adapter) {
        final Adapter oldAdapter = getAdapter();

        if (oldAdapter != null) {
            oldAdapter.unregisterAdapterDataObserver(observer);
        }

        if (adapter != null) {
            adapter.registerAdapterDataObserver(observer);
        }
    }

    public void setView(Status status, @Nullable View view) {
        this.views.put(status, view);
        check();
    }

    @Nullable
    public View getView(Status status) {
        return views.get(status);
    }

    public void setStatus(Status status) {
        this.status = status;
        check();
    }

    public void scrollTo(int pos){
        scrollToPosition(pos);
    }

    public Status getStatus() {
        return status;
    }

}
