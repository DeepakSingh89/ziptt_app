package com.ziploan.dsaapp.fragments.details;

import android.app.Activity;
import android.app.DatePickerDialog;
import android.content.Intent;
import android.graphics.Paint;
import android.os.Bundle;
import android.view.Gravity;
import android.view.MotionEvent;
import android.view.View;
import android.widget.AutoCompleteTextView;
import android.widget.DatePicker;
import android.widget.LinearLayout;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.appcompat.app.AppCompatActivity;
import androidx.appcompat.widget.AppCompatTextView;
import androidx.lifecycle.ViewModel;
import androidx.lifecycle.ViewModelProvider;
import androidx.lifecycle.ViewModelProviders;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import com.google.android.material.textfield.TextInputEditText;
import com.jaiselrahman.filepicker.activity.FilePickerActivity;
import com.jaiselrahman.filepicker.model.MediaFile;

import java.util.ArrayList;
import java.util.Calendar;

import com.ziploan.dsaapp.R;
import com.ziploan.dsaapp.base.BaseRepository;
import com.ziploan.dsaapp.base.BindingFragment;
import com.ziploan.dsaapp.databinding.DocumentDetailsLayoutBinding;
import com.ziploan.dsaapp.model.ZiploanPhoto;
import com.ziploan.dsaapp.utils.Constant;
import com.ziploan.dsaapp.utils.ImageUtils;
import com.ziploan.dsaapp.utils.KeyboardUtils;
import com.ziploan.dsaapp.utils.permissons.PermissionConstant;
import com.ziploan.dsaapp.viewmodel.details.DocumentUploadViewModel;

public class DocumentUploadDetailsFragment extends BindingFragment<DocumentDetailsLayoutBinding, DocumentUploadViewModel, BaseRepository> {


    private TextInputEditText primaryStatementStartDate;
    private TextInputEditText primaryStatementEndDate;
    private TextInputEditText secondaryStatementStartDate;
    private TextInputEditText secondaryStatementEndDate;
    private int year;
    private int month;
    private int day;

    private LinearLayout main_layout;
    private int whichDate;

    public static DocumentUploadDetailsFragment newInstance(String loan_req_id) {
        DocumentUploadDetailsFragment fragment = new DocumentUploadDetailsFragment();
        Bundle args = new Bundle();
        args.putString("loan_req_id", loan_req_id);
        fragment.setArguments(args);
        return fragment;
    }

    public static DocumentUploadDetailsFragment newInstance(String loan_req_id, int num_of_pages) {
        DocumentUploadDetailsFragment fragment = new DocumentUploadDetailsFragment();
        Bundle args = new Bundle();
        args.putInt("num_of_pages", num_of_pages);
        args.putString("loan_req_id", loan_req_id);
        fragment.setArguments(args);
        return fragment;
    }

    public DocumentDetailsLayoutBinding getParentView() {
        return getBinding();
    }

    @Override
    public DocumentUploadViewModel getViewModel(BaseRepository repository) {
        return ViewModelProviders.of(this, new ViewModelProvider.Factory() {
            @NonNull
            @Override
            public <T extends ViewModel> T create(@NonNull Class<T> modelClass) {
                return (T) new DocumentUploadViewModel(getArguments().getString("loan_req_id"),
                        DocumentUploadDetailsFragment.this, getArguments().getInt("num_of_pages"),getActivity());
            }
        }).get(DocumentUploadViewModel.class);
    }

    @Override
    public void onResume() {
        super.onResume();
        ((AppCompatActivity) getActivity()).getSupportActionBar().setTitle(getString(R.string.document_detail));
        if (mainActivity.get().getSupportActionBar() != null) {
            mainActivity.get().getSupportActionBar().show();
            mainActivity.get().enableViews(true);
        }
    }

    @Override
    public void onPause() {
        super.onPause();
        KeyboardUtils.hideKeyboard(mainActivity.get());
    }

    @Override
    public BaseRepository getRepository() {
        return null;
    }


    @Override
    protected void onPermission(int permissionRequest, String[] permissions, int[] grantResults) {
        super.onPermission(permissionRequest, permissions, grantResults);
    }

    @Override
    public int getLayoutId() {
        return R.layout.document_details_layout;
    }

    public void requesSinglePermission() {
        checkRequest(PermissionConstant.STORATE_WRITE);
    }

    @Override
    public void onViewCreated(@NonNull View view, @Nullable Bundle savedInstanceState) {
        super.onViewCreated(view, savedInstanceState);

        if (getArguments() != null) {
            if (getViewModel() != null)
                getViewModel().seNumOfPages(getArguments().getInt("num_of_pages"));
        }


        primaryStatementStartDate = getBinding().primaryStart;
        primaryStatementEndDate = getBinding().primaryEnd;
        secondaryStatementStartDate = getBinding().secondaryStart;
        secondaryStatementEndDate = getBinding().secondaryEnd;

        RecyclerView primeryrecyclerView = view.findViewById(R.id.recycler_view_primary_bank);
        primeryrecyclerView.setNestedScrollingEnabled(false);
        RecyclerView secrecyclerView = view.findViewById(R.id.recycler_view_sec_bank);
        secrecyclerView.setNestedScrollingEnabled(false);
        RecyclerView kycrecyclerView = view.findViewById(R.id.recycler_view_kyc);
        kycrecyclerView.setNestedScrollingEnabled(false);
        RecyclerView firstItrrecyclerView = view.findViewById(R.id.recycler_view_first_itr);
        firstItrrecyclerView.setNestedScrollingEnabled(false);
        RecyclerView lastItrrecyclerView = view.findViewById(R.id.recycler_view_last_itr);
        lastItrrecyclerView.setNestedScrollingEnabled(false);

        RecyclerView anotherItrrecyclerView = view.findViewById(R.id.recycler_view_another_itr);
        anotherItrrecyclerView.setNestedScrollingEnabled(false);

        AutoCompleteTextView bank_list_box = getBinding().bankListBox;//  view.findViewById(R.id.bank_list_box);
        AutoCompleteTextView sec_bank_list_box = getBinding().secBankListBox;//  view.findViewById(R.id.sec_bank_list_box);
        main_layout = view.findViewById(R.id.main_layout);
        if (getViewModel() != null) {
            getViewModel().setBankListBox(bank_list_box);
            getViewModel().setSecBankListBox(sec_bank_list_box);
        }

        primeryrecyclerView.setLayoutManager(new LinearLayoutManager(getContext()));
        secrecyclerView.setLayoutManager(new LinearLayoutManager(getContext()));
        kycrecyclerView.setLayoutManager(new LinearLayoutManager(getContext()));
        firstItrrecyclerView.setLayoutManager(new LinearLayoutManager(getContext()));
        lastItrrecyclerView.setLayoutManager(new LinearLayoutManager(getContext()));
        anotherItrrecyclerView.setLayoutManager(new LinearLayoutManager(getContext()));
        if (getViewModel() != null) {
            getViewModel().setBankRecycler(primeryrecyclerView);
            getViewModel().setSecBankRecycler(secrecyclerView);
            getViewModel().setKycBankRecycler(kycrecyclerView);
            getViewModel().setFirstItrBankRecycler(firstItrrecyclerView);
            getViewModel().setLastItrBankRecycler(lastItrrecyclerView);
            getViewModel().setAnotherItrBankRecycler(anotherItrrecyclerView);
        }

        bank_list_box.setOnTouchListener(new View.OnTouchListener() {
            @Override
            public boolean onTouch(View v, MotionEvent event) {
                final int DRAWABLE_LEFT = 0;
                final int DRAWABLE_TOP = 1;
                final int DRAWABLE_RIGHT = 2;
                final int DRAWABLE_BOTTOM = 3;

                if (event.getAction() == MotionEvent.ACTION_UP) {
                    if (event.getRawX() >= (bank_list_box.getRight() - bank_list_box.getCompoundDrawables()[DRAWABLE_RIGHT].getBounds().width())) {
                        getViewModel().openPrimeryBankDialogue();
                        return true;
                    }
                }
                return false;
            }
        });

        sec_bank_list_box.setOnTouchListener(new View.OnTouchListener() {
            @Override
            public boolean onTouch(View v, MotionEvent event) {
                final int DRAWABLE_LEFT = 0;
                final int DRAWABLE_TOP = 1;
                final int DRAWABLE_RIGHT = 2;
                final int DRAWABLE_BOTTOM = 3;

                if (event.getAction() == MotionEvent.ACTION_UP) {
                    if (event.getRawX() >= (sec_bank_list_box.getRight() - sec_bank_list_box.getCompoundDrawables()[DRAWABLE_RIGHT].getBounds().width())) {
                        getViewModel().openSecBankDialogue();
                        return true;
                    }
                }
                return false;
            }
        });
        getArguments().clear();
    }

    @Override
    public void onActivityResult(int requestCode, int resultCode, Intent data) {
        super.onActivityResult(requestCode, resultCode, data);
        if (resultCode == Activity.RESULT_OK) {
            switch (requestCode) {
                case Constant.CAMERA_REQUEST:
                    ZiploanPhoto ziploanPhoto = new ZiploanPhoto(ImageUtils.compressImage(getContext(), getViewModel().getCapturedImageUri(), null), Constant.MediaType.IMAGE);
                    getViewModel().getImages(ziploanPhoto, Constant.ImageSourceType.CAMREA);
                    break;
                case Constant.GALLERY_REQUEST:
                    if (data.getData() != null) {
                        ZiploanPhoto ziploangalary = new ZiploanPhoto(ImageUtils.compressImage(getContext(), data.getData(), null), Constant.MediaType.IMAGE);
                        getViewModel().getImages(ziploangalary, Constant.ImageSourceType.GALLERY);
                    }
                    break;
                case Constant.FILE_REQUEST:
                    ArrayList<MediaFile> files = data.getParcelableArrayListExtra(FilePickerActivity.MEDIA_FILES);
                    if (files != null
                            && files.size() > 0) {
                        ZiploanPhoto ziploangalary = null;
                        try {
                            ziploangalary = new ZiploanPhoto(files.get(0).getPath(), files.get(0).getMimeType());
                            getViewModel().getImages(ziploangalary, files.get(0).getMediaType());
                        } catch (Exception e) {
                            e.printStackTrace();
                        }
                    }
                    break;
            }
        }
    }


    public void selecPrimaryBankStmtStarttDate(int dateClick) {
        final Calendar c = Calendar.getInstance();
        year = c.get(Calendar.YEAR);
        month = c.get(Calendar.MONTH);
        day = c.get(Calendar.DAY_OF_MONTH);

        whichDate = dateClick;

        DatePickerDialog datePickerDialog = new DatePickerDialog(
                getContext(), R.style.DialogTheme, this::onPrimaryBankStmtDateSet, year, month, day) {
            @Override
            protected void onCreate(Bundle savedInstanceState) {
                super.onCreate(savedInstanceState);
                AppCompatTextView date = (AppCompatTextView) getDatePicker().findViewById(getResources().getIdentifier("date_picker_header_date", "id", "android"));
                AppCompatTextView year = (AppCompatTextView) getDatePicker().findViewById(getResources().getIdentifier("date_picker_header_year", "id", "android"));

                year.setTextColor(getResources().getColor(R.color.white));
                year.setTextSize(30);
                year.setLayoutParams(new LinearLayout.LayoutParams(LinearLayout.LayoutParams.MATCH_PARENT, LinearLayout.LayoutParams.MATCH_PARENT));
                year.setGravity(Gravity.CENTER_HORIZONTAL);
                date.setTextSize(15);
                year.setPaintFlags(year.getPaintFlags() | Paint.UNDERLINE_TEXT_FLAG);
            }
        };
        c.set(year, month, day);

        datePickerDialog.getDatePicker().setMaxDate(c.getTimeInMillis());
        datePickerDialog.show();
    }

    //android:id/date_picker_header_date

    private void onPrimaryBankStmtDateSet(DatePicker datePicker, int i, int i1, int i2) {
        year = i;
        month = i1+1;
        day = i2;

        StringBuilder dayStr =new StringBuilder();
        StringBuilder monthStr =new StringBuilder();
        String days=""+day;
        String months=""+month;

        if (days.length()<2){
            dayStr.append("0"+days);
        }else{
            dayStr.append(days);
        }

        if (months.length()<2){
            monthStr.append("0"+months);
        }else{
            monthStr.append(months);
        }



        switch (whichDate) {
            case 1:
                    primaryStatementStartDate.setText(new StringBuilder().append(year).append("-").append(monthStr.toString())
                            .append("-").append(dayStr));

                break;

            case 2:
                primaryStatementEndDate.setText(new StringBuilder().append(year).append("-").append(monthStr.toString())
                        .append("-").append(dayStr));
                break;

            case 3:
                secondaryStatementStartDate.setText(new StringBuilder().append(year).append("-").append(monthStr.toString())
                        .append("-").append(dayStr));
                break;

            case 4:
                secondaryStatementEndDate.setText(new StringBuilder().append(year).append("-").append(monthStr.toString())
                        .append("-").append(dayStr));
                break;
        }

    }


    public void requestfocus() {
        main_layout.requestFocus();
    }
}
