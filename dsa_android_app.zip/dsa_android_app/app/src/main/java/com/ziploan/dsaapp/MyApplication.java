package com.ziploan.dsaapp;

import android.app.Application;
import android.content.Context;
import android.os.StrictMode;

import androidx.appcompat.app.AppCompatDelegate;
import androidx.multidex.MultiDex;
import com.crashlytics.android.Crashlytics;
import com.jaiselrahman.filepicker.model.MediaFile;
import com.ziploan.dsaapp.base.DSAApplication;
import com.ziploan.dsaapp.base.extras.network.AppExecutors;
import com.ziploan.dsaapp.model.header.HeaderModel;
import com.ziploan.dsaapp.utils.FirebaseUtils;

import java.util.ArrayList;

import io.fabric.sdk.android.Fabric;

public class MyApplication extends Application {

    public static String ShowOnePage = "";
    public static boolean FromMobile = false;
    private static MyApplication _instance;
    public static MyApplication getInstance(){
        return _instance;
    }



    public ArrayList<MediaFile> getAllMedia() {
        return allMedia;
    }

    public void setAllMedia(ArrayList<MediaFile> allMedia) {
        this.allMedia = allMedia;
    }

    ArrayList<MediaFile> allMedia = new ArrayList<>();



    @Override
    public void onCreate() {
        super.onCreate();
        Fabric.with(this, new Crashlytics());
        _instance = this;
        StrictMode.VmPolicy.Builder builder = new StrictMode.VmPolicy.Builder();
        StrictMode.setVmPolicy(builder.build());
        AppCompatDelegate.setCompatVectorFromResourcesEnabled(true);
        FirebaseUtils.init(this);
        MultiDex.install(this);
    }

    @Override
    protected void attachBaseContext(Context base) {
        super.attachBaseContext(base);
        MultiDex.install(this);
    }
    public Context getAppContext(){
        return getApplicationContext();
    }

    public static String LOAN_REQ_ID;
    public static boolean BusinessDetailsField;
    public static com.ziploan.dsaapp.model.response.form_config.Response formResponse;

}
