package com.ziploan.dsaapp.base;

import android.content.Context;
import android.os.Bundle;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Toast;

import com.crashlytics.android.Crashlytics;
import com.crashlytics.android.answers.CustomEvent;

import java.lang.ref.WeakReference;
import java.lang.reflect.InvocationTargetException;
import java.lang.reflect.Method;
import java.lang.reflect.ParameterizedType;

import androidx.annotation.LayoutRes;
import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.databinding.DataBindingUtil;
import androidx.databinding.ViewDataBinding;
import com.ziploan.dsaapp.BR;
import com.ziploan.dsaapp.MainActivity;
import com.ziploan.dsaapp.utils.KeyboardUtils;
import com.ziploan.dsaapp.utils.permissons.PermissionConstant;

public abstract class BindingFragment<BindingT extends ViewDataBinding,T extends BaseViewModel, R extends BaseRepository> extends BaseFragment {
    private BindingT mBinding = null;
    private T mViewModel;
    private R mRepository;
    protected WeakReference<MainActivity> mainActivity;

    public abstract T getViewModel(R repository);
    public abstract R getRepository();
    public abstract
    @LayoutRes
    int getLayoutId();
    @Nullable
    @Override
    public final View onCreateView(@NonNull final LayoutInflater inflater, @Nullable final ViewGroup container, @Nullable final Bundle savedInstanceState) {
        try {
            mBinding = DataBindingUtil.inflate(inflater, getLayoutId(), container, false);
            return mBinding.getRoot();
        } catch (Exception c) {
            Crashlytics.logException(c.getCause());
        }
        return null;
    }

    @Override
    public void onViewCreated(@NonNull View view, @Nullable Bundle savedInstanceState) {
        super.onViewCreated(view, savedInstanceState);
        mRepository = getRepository();
        mViewModel = getViewModel(mRepository);
        getCurrentViewModel(mViewModel);
        mBinding.setVariable(BR.viewmodel, mViewModel);
        mBinding.setVariable(BR.fragment, this);
        mBinding.executePendingBindings();
    }

    protected BindingT getBinding(){
        return mBinding;
    }

    protected void getCurrentViewModel(T viewmodel){

    }

    protected T getViewModel(){
        return mViewModel;
    }

    @Override
    public void refreshData() {
        if(getViewModel() != null)
            getViewModel().refresh();
    }

    @Override
    public void onAttach(Context context) {
        mainActivity = new WeakReference<>((MainActivity)context);
        super.onAttach(context);

    }

    @Override
    public void onDetach() {
        super.onDetach();
        mainActivity = null;
    }

    @Override
    public void onDestroyView() {
        mBinding = null;
        mViewModel = null;
        mRepository = null;
        super.onDestroyView();
    }

    public void hideKeyBoard(){
        if(mainActivity != null)
            KeyboardUtils.hideKeyboard(mainActivity.get());
    }

}
