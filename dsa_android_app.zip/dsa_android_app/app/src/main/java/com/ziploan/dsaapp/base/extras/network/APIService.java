package com.ziploan.dsaapp.base.extras.network;

import java.util.Map;

import com.ziploan.dsaapp.model.bank_list.BankListResponse;
import com.ziploan.dsaapp.model.config.AppConfigModel;
import com.ziploan.dsaapp.model.request.*;
import com.ziploan.dsaapp.model.request.document.PostDocumentRequest;
import com.ziploan.dsaapp.model.response.*;
import com.ziploan.dsaapp.model.response.business_info.BusinessInfoResponse;
import com.ziploan.dsaapp.model.response.document.GetDocumentResponse;
import com.ziploan.dsaapp.model.response.form_config.FormConfigResponse;
import com.ziploan.dsaapp.model.response.loan_list.LoanListResponse;
import com.ziploan.dsaapp.model.response.personal.PersonalInfoResponse;
import com.ziploan.dsaapp.model.response.personal.get_personal.GetPersonalInfoResponse;
import com.ziploan.dsaapp.model.response.pincode.PincodeResponse;
import okhttp3.RequestBody;
import retrofit2.Call;
import retrofit2.http.Body;
import retrofit2.http.GET;
import retrofit2.http.Multipart;
import retrofit2.http.PATCH;
import retrofit2.http.POST;
import retrofit2.http.PartMap;
import retrofit2.http.Query;
import retrofit2.http.QueryMap;
import retrofit2.http.Url;

public interface APIService {

    @POST("Verify_Partner_Account/")
    Call<LoginResponse> login(@Body LoginRequest request);

    @POST("customerapis/v1/start_application/")
    Call<MobileBaseResponse> start_application(@Body StartApplicationRequest mobile);



    @GET("customerapis/v1/form_config/")
    Call<FormConfigResponse> formConfig(@Query("loan_request_id") String loan_request_id);

    @GET("customerapis/v1/state_city/")
    Call<PincodeResponse> checkPincode(@Query("pincode") String pincode);

    @POST("customerapis/v1/personal_info/")
    Call<PersonalInfoResponse> postPersonalInfo(@Body PersonalInfoRequest request);

    @PATCH("customerapis/v1/personal_info/")
    Call<PersonalInfoResponse> patchPersonalInfo(@Body PersonalInfoRequest request);

    @GET("customerapis/v1/personal_info/")
    Call<GetPersonalInfoResponse> getPersonalInfo(@Query("loan_request_id") String loan_request_id,
                                                  @Query("applicant_type") int applicant_type,
                                                  @Query("application_type") String application_type);

    @GET("customerapis/v1/business_info/")
    Call<BusinessInfoResponse> getBusinessInfo(@Query("loan_request_id") String loan_request_id,
                                                  @Query("applicant_type") int applicant_type,
                                                  @Query("application_type") String application_type);

    @POST("customerapis/v1/business_info/")
    Call<BusinessInfoResponse> postBusinessInfo(@Body BusinessInfoRequest request);

    @PATCH("customerapis/v1/business_info/")
    Call<BusinessInfoResponse> patchBusinessInfo(@Body BusinessInfoRequest request);

    @POST("customerapis/v1/loan_request_submission/")
    Call<MobileVerificationResponse> postLoanReq(@Body PostDocumentRequest request);

    @PATCH("customerapis/v1/loan_request_submission/")
    Call<MobileVerificationResponse> patchLoanReq(@Body PostDocumentRequest request);

    @Multipart
    @POST("upload_file/")
    Call<FileUploadResponse> uploadFile(@PartMap Map<String, RequestBody> params);

//    @GET("https://webservices-qa.ziploan.in/restapis/file_deletion/")
//    Call<FileUploadResponse> deleteFile(@QueryMap Map<String, String> queryMap);


    @GET("file_deletion/")
    Call<FileUploadResponse> deleteFile(@QueryMap Map<String, String> queryMap);

    @GET("Partner_Incomplete_Loan_Request_List/")
    Call<LoanListResponse> loanList(@QueryMap Map<String, String> queryMap);

    @GET("customerapis/v1/master_bank_names/")
    Call<BankListResponse> bankList(@QueryMap Map<String, String> queryMap);

    @GET("customerapis/v1/documents/")
    Call<GetDocumentResponse> getDocuments(@QueryMap Map<String, String> queryMap);

    @GET("get_dsa_app_configuration/")
    Call<AppConfigModel> getConfig();
}


