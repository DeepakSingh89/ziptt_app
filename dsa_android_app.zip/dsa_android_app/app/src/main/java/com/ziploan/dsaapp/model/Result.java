package com.ziploan.dsaapp.model;

public class Result {
}
