
package com.ziploan.dsaapp.model.response.loan_list;

import com.google.gson.annotations.Expose;
import com.google.gson.annotations.SerializedName;

public class PartnerIncompleteLoanRequestDatum {

    @SerializedName("loan_request_status_name")
    @Expose
    private String loanRequestStatusName;
    @SerializedName("loan_request_id")
    @Expose
    private String loanRequestId;
    @SerializedName("first_applicant_name")
    @Expose
    private String firstApplicantName;
    @SerializedName("business_address")
    @Expose
    private String businessAddress;
    @SerializedName("loan_application_number")
    @Expose
    private String loanApplicationNumber;
    @SerializedName("business_name")
    @Expose
    private String businessName;
    @SerializedName("loan_request_status")
    @Expose
    private String loanRequestStatus;

    public String getLoanRequestStatusName() {
        return loanRequestStatusName;
    }

    public void setLoanRequestStatusName(String loanRequestStatusName) {
        this.loanRequestStatusName = loanRequestStatusName;
    }

    public String getLoanRequestId() {
        return loanRequestId;
    }

    public void setLoanRequestId(String loanRequestId) {
        this.loanRequestId = loanRequestId;
    }

    public String getFirstApplicantName() {
        return firstApplicantName;
    }

    public void setFirstApplicantName(String firstApplicantName) {
        this.firstApplicantName = firstApplicantName;
    }

    public String getBusinessAddress() {
        return businessAddress;
    }

    public void setBusinessAddress(String businessAddress) {
        this.businessAddress = businessAddress;
    }

    public String getLoanApplicationNumber() {
        return loanApplicationNumber;
    }

    public void setLoanApplicationNumber(String loanApplicationNumber) {
        this.loanApplicationNumber = loanApplicationNumber;
    }

    public String getBusinessName() {
        return businessName;
    }

    public void setBusinessName(String businessName) {
        this.businessName = businessName;
    }

    public String getLoanRequestStatus() {
        String mainChapterNumber = loanRequestStatus.split("\\.", 2)[0];
        return mainChapterNumber;
    }

    public void setLoanRequestStatus(String loanRequestStatus) {
        this.loanRequestStatus = loanRequestStatus;
    }

}
