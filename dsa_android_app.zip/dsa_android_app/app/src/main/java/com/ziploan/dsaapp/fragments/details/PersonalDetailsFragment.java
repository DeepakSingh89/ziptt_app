package com.ziploan.dsaapp.fragments.details;

import android.app.DatePickerDialog;
import android.graphics.Paint;
import android.os.Bundle;
import android.text.Editable;
import android.text.Spannable;
import android.text.SpannableString;
import android.text.Spanned;
import android.text.TextWatcher;
import android.text.method.LinkMovementMethod;

import android.view.Gravity;
import android.view.View;

import android.widget.DatePicker;
import android.widget.ImageView;
import android.widget.LinearLayout;

import com.github.florent37.viewtooltip.ViewTooltip;
import com.google.android.material.textfield.TextInputEditText;

import java.util.Calendar;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.appcompat.app.AppCompatActivity;
import androidx.appcompat.widget.AppCompatTextView;
import androidx.lifecycle.ViewModel;
import androidx.lifecycle.ViewModelProvider;
import androidx.lifecycle.ViewModelProviders;
import com.ziploan.dsaapp.R;
import com.ziploan.dsaapp.base.BaseRepository;
import com.ziploan.dsaapp.base.BindingFragment;
import com.ziploan.dsaapp.databinding.PersonalDetailsFragmentLayoutBinding;
import com.ziploan.dsaapp.fragments.weview.ZipWebviewFragment;
import com.ziploan.dsaapp.utils.KeyboardUtils;
import com.ziploan.dsaapp.utils.NavController;
import com.ziploan.dsaapp.utils.ZipClickableSpan;
import com.ziploan.dsaapp.viewmodel.details.PersonalDetailsViewModel;

public class PersonalDetailsFragment extends BindingFragment<PersonalDetailsFragmentLayoutBinding, PersonalDetailsViewModel, BaseRepository> {

    private TextInputEditText  dob;
    private int year;
    private int month;
    private int day;

    public static PersonalDetailsFragment newInstance(String mobile, String loan_req_id, int num_of_pages) {
        PersonalDetailsFragment fragment = new PersonalDetailsFragment();
        Bundle args = new Bundle();
        args.putString("mobile",mobile);
        args.putInt("num_of_pages",num_of_pages);
        args.putString("loan_req_id",loan_req_id);
        fragment.setArguments(args);
        return fragment;
    }
    @Override
    public int getLayoutId() {
        return R.layout.personal_details_fragment_layout;
    }
    public static PersonalDetailsFragment newInstance(String loan_req_id) {
        PersonalDetailsFragment fragment = new PersonalDetailsFragment();
        Bundle args = new Bundle();
        args.putString("loan_req_id",loan_req_id);
        fragment.setArguments(args);
        return fragment;
    }

    @Override
    public PersonalDetailsViewModel getViewModel(BaseRepository repository) {
        return  ViewModelProviders.of(this, new ViewModelProvider.Factory() {
            @NonNull
            @Override
            public <T extends ViewModel> T create(@NonNull Class<T> modelClass) {
                return (T) new PersonalDetailsViewModel();
            }
        }).get(PersonalDetailsViewModel.class);
    }

    @Override
    public void onResume() {
        super.onResume();
        ((AppCompatActivity)getActivity()).getSupportActionBar().setTitle(getString(R.string.personal_detail));
        if(mainActivity.get().getSupportActionBar() != null) {
            mainActivity.get().getSupportActionBar().show();
            mainActivity.get().enableViews(true);
        }
    }

    @Override
    public void onPause() {
        super.onPause();
        KeyboardUtils.hideKeyboard(mainActivity.get());
    }

    @Override
    public BaseRepository getRepository() {
        return null;
    }

    @Override
    public void onViewCreated(@NonNull View view, @Nullable Bundle savedInstanceState) {
        super.onViewCreated(view, savedInstanceState);

        TextInputEditText  textInputEditTextPincode = getBinding().pincodePersonalInfo;

        dob = getBinding().dob;

        if(getViewModel() != null)
            getViewModel().setContext(getContext());
        ImageView info_icon = view.findViewById(R.id.info_icon);
        info_icon.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                View child = getLayoutInflater().inflate(R.layout.alert_pan, null);
                ViewTooltip
                        .on(mainActivity.get(),view)
                        .autoHide(true, 4000)
                        .withShadow(true)
                        .distanceWithView(-10)
                        .color(getResources().getColor(R.color.white))
                        .position(ViewTooltip.Position.BOTTOM)
                        .customView(child)
                        .arrowHeight(0)
                        .arrowWidth(0)
                        .show();
            }
        });

        AppCompatTextView TV = view.findViewById(R.id.t_and_c);
        TV.setMovementMethod(LinkMovementMethod.getInstance());
        Spannable wordtoSpan = new SpannableString(getString(R.string.tandc));
        wordtoSpan.setSpan(new ZipClickableSpan(getString(R.string.tandc),getContext()){
            @Override
            public void onClick(View tv) {
                NavController.getInstance().addFragment(ZipWebviewFragment.newInstance("https://ziploan.in/policies#privacy"),true);
            }
        }, 70, 84, Spanned.SPAN_EXCLUSIVE_EXCLUSIVE);

        wordtoSpan.setSpan(new ZipClickableSpan(getString(R.string.tandc),getContext()){
            @Override
            public void onClick(View tv) {
                NavController.getInstance().addFragment(ZipWebviewFragment.newInstance("https://ziploan.in/policies#terms"),true);
            }
        }, 49, 65, Spanned.SPAN_EXCLUSIVE_EXCLUSIVE);

        TV.setText(wordtoSpan);

        if(getArguments() != null){
            if(getViewModel() != null) {
             //   getViewModel().setMobile(getArguments().getString("mobile"));
                getViewModel().setPan(getArguments().getString("mobile"));
                getViewModel().seNumOfPages(getArguments().getInt("num_of_pages"));
                getViewModel().setLonReqId(getArguments().getString("loan_req_id"));
            }
        }

//        textInputEditTextPincode.setOnFocusChangeListener(new View.OnFocusChangeListener() {
//            @Override
//            public void onFocusChange(View view, boolean b) {
//                if(!b && !TextUtils.isEmpty(textInputEditTextPincode.getText())
//                        && textInputEditTextPincode.length() == 6){
//                    getViewModel().setPincode(textInputEditTextPincode.getText().toString());
//                }
//            }
//        });

        textInputEditTextPincode.addTextChangedListener(new TextWatcher() {
            @Override
            public void beforeTextChanged(CharSequence charSequence, int i, int i1, int i2) {

            }

            @Override
            public void onTextChanged(CharSequence charSequence, int i, int i1, int i2) {
                if(charSequence.length()>5) {
                    getViewModel().setPincode(charSequence.toString());
                }
            }

            @Override
            public void afterTextChanged(Editable editable) {

            }
        });
        getArguments().clear();
    }

    public void selectDate() {
        final Calendar c = Calendar.getInstance();
        year = c.get(Calendar.YEAR);
        month = c.get(Calendar.MONTH);
        day = c.get(Calendar.DAY_OF_MONTH);

        DatePickerDialog datePickerDialog = new DatePickerDialog(
                getContext(),R.style.DialogTheme, this::onDateSet, year - 21, month, day){
            @Override
            protected void onCreate(Bundle savedInstanceState) {
                super.onCreate(savedInstanceState);
                AppCompatTextView date = (AppCompatTextView)getDatePicker().findViewById(getResources().getIdentifier("date_picker_header_date","id","android"));
                AppCompatTextView year = (AppCompatTextView)getDatePicker().findViewById(getResources().getIdentifier("date_picker_header_year","id","android"));

                if (year!=null){
                    year.setTextColor(getResources().getColor(R.color.white));
                    year.setTextSize(30);
                    year.setLayoutParams(new LinearLayout.LayoutParams(LinearLayout.LayoutParams.MATCH_PARENT, LinearLayout.LayoutParams.MATCH_PARENT));
                    year.setGravity(Gravity.CENTER_HORIZONTAL);
                    date.setTextSize(15);
                    year.setPaintFlags(year.getPaintFlags() |   Paint.UNDERLINE_TEXT_FLAG);
                }

            }
        };
        c.set(year - 21, month, day);

        datePickerDialog.getDatePicker().setMaxDate(c.getTimeInMillis());
        datePickerDialog.show();
    }

    //android:id/date_picker_header_date

    private void onDateSet(DatePicker datePicker, int i, int i1, int i2) {
        year  = i;
        month = i1;
        day   = i2;

        dob.setText(new StringBuilder().append(day).append("/").append(month + 1)
                .append("/").append(year));
    }

    public PersonalDetailsFragmentLayoutBinding getParentView(){
        return getBinding();
    }
}
