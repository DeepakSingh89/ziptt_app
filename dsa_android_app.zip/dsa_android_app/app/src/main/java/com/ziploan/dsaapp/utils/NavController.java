package com.ziploan.dsaapp.utils;

import android.content.Context;
import android.text.TextUtils;
import android.widget.Toast;

import androidx.fragment.app.Fragment;
import androidx.fragment.app.FragmentManager;
import androidx.fragment.app.FragmentTransaction;
import com.ziploan.dsaapp.R;

public class NavController {

    private final int container;
    private final TransitionHelper transitionHelper;
    private final FragmentManager fm;
    private static NavController INSTANCE;
    public String CURRENT_TAG = "";

    public static void init(FragmentManager fragmentManager) {
        if (INSTANCE == null) {
            INSTANCE = new NavController(fragmentManager);
        }
    }

    public static void destroy(){
        INSTANCE = null;
    }

    public static NavController getInstance(){
        return INSTANCE;
    }

    private NavController(FragmentManager fm) {
        this.container = R.id.base_frame;
        this.transitionHelper = new TransitionHelper();
        this.fm = fm;
    }

    public FragmentManager getFragmentManager(){
        return fm;
    }


    public void addFragment(Fragment fragment, boolean addToBackStack) {
        FragmentTransaction fragmentTransaction = fm.beginTransaction();
        fragmentTransaction.replace(container, fragment, fragment.getClass().getName());
        if (addToBackStack)
            fragmentTransaction.addToBackStack(fragment.getClass().getName());
        fragmentTransaction.commitAllowingStateLoss();
    }

    public void addaFragment(Fragment fragment, boolean addToBackStack) {
        // transitionHelper.initTransitionN(fragment);
        FragmentTransaction fragmentTransaction = fm.beginTransaction();
        fragmentTransaction.add(container, fragment, fragment.getClass().getName());
        if (addToBackStack)
            fragmentTransaction.addToBackStack(fragment.getClass().getName());
        fragmentTransaction.commitAllowingStateLoss();
    }

    public void replaceFragment(Fragment fragment, boolean addToBackStack) {
        // transitionHelper.initTransitionN(fragment);
        FragmentTransaction fragmentTransaction = fm.beginTransaction();
        if (addToBackStack) {
            fragmentTransaction.addToBackStack(fragment.getClass().getName());
        }
        fragmentTransaction.replace(container, fragment, fragment.getClass().getName())
                .commitAllowingStateLoss();
    }

    public void removeCurrent(){
        FragmentTransaction fragmentTransaction = fm.beginTransaction();
        fragmentTransaction.remove(getCurrentFragment()).commitNow();
    }

    public void clearBack(){
        for(int i = 0; i < fm.getBackStackEntryCount(); ++i) {
            fm.popBackStack();
        }
    }

    public void clearBackTo(String name) {
        for (int i = fm.getBackStackEntryCount() - 1; i >= 0; i--) {
            FragmentManager.BackStackEntry backStackEntry = fm.getBackStackEntryAt(i);
            if (!TextUtils.isEmpty(backStackEntry.getName())) {
                if (!backStackEntry.getName().equalsIgnoreCase(name)) {
                    fm.popBackStack();
                } else {
                    break;
                }
            }
        }
    }

    public Fragment getCurrentFragment(){
        return fm.findFragmentByTag(CURRENT_TAG);
    }

    public Fragment getCurrentFragment(String tag){
        return fm.findFragmentByTag(tag);
    }
}
