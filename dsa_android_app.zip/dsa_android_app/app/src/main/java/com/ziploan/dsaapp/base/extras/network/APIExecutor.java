package com.ziploan.dsaapp.base.extras.network;

import android.util.Log;

import com.google.gson.Gson;
import com.google.gson.GsonBuilder;

import java.io.IOException;
import java.util.concurrent.TimeUnit;

import com.ziploan.dsaapp.BuildConfig;
import com.ziploan.dsaapp.fragments.login.LoginFragment;
import com.ziploan.dsaapp.utils.Constant;
import com.ziploan.dsaapp.utils.NavController;
import com.ziploan.dsaapp.utils.PreferencesManager;
import okhttp3.HttpUrl;
import okhttp3.Interceptor;
import okhttp3.OkHttpClient;
import okhttp3.Request;
import okhttp3.Response;
import okhttp3.logging.HttpLoggingInterceptor;
import retrofit2.Retrofit;
import retrofit2.converter.gson.GsonConverterFactory;

import static com.ziploan.dsaapp.BuildConfig.IMAGE_BASE_URL;


public class APIExecutor {
    private final static String BASE_URL = BuildConfig.BASE_URL;

    public static APIService getAPIService() {
        HttpLoggingInterceptor logging = new HttpLoggingInterceptor();
        logging.setLevel(HttpLoggingInterceptor.Level.BODY);


        Gson gson = new GsonBuilder()
                .setLenient()
                .create();
        OkHttpClient defaultHttpClient = new OkHttpClient.Builder()
                .readTimeout(60, TimeUnit.SECONDS)
                .connectTimeout(60, TimeUnit.SECONDS)
                .writeTimeout(60, TimeUnit.SECONDS)
                .addInterceptor(
                        new Interceptor() {
                            @Override
                            public Response intercept(Interceptor.Chain chain) throws IOException {
                                Request original = chain.request();
                                HttpUrl originalHttpUrl = original.url();
                                HttpUrl.Builder urlBuilder = originalHttpUrl.newBuilder();

                                Request.Builder requestBuilder = original.newBuilder()
                                        .url(urlBuilder.build());
                                if(!originalHttpUrl.toString().contains("media")){
                                    requestBuilder.addHeader(Constant.CONTENT_TYPE, Constant.CONTENT_TYPE_VALUE);
                                }
                                if(PreferencesManager.getInstance().isUserLoggedIn()){
                                    requestBuilder.addHeader(Constant.ACCESS_TOKEN, PreferencesManager.getInstance().getString(PreferencesManager.AUTH_TOKEN));
                                    requestBuilder.addHeader(Constant.ACCESS_ID, PreferencesManager.getInstance().getString(PreferencesManager.AUTH_ID));
                                }
                                Request request = requestBuilder.build();
                                Response response = chain.proceed(request);
                                if (response.code() == 401) {
                                    handleUnauthorisedResponse();
                                }


                                //Log.d("Response:",""+new Gson().toJson(response));
                                return response;
//                                return chain.proceed(request);
                            }
                        }).build();

        Retrofit retrofit = new Retrofit.Builder()
                .baseUrl(BASE_URL)
                .client(defaultHttpClient)
                .addConverterFactory(GsonConverterFactory.create(gson))
                .build();
        return retrofit.create(APIService.class);
    }


    public static APIService getAPIService_Media() {
        Gson gson = new GsonBuilder()
                .setLenient()
                .create();
        OkHttpClient defaultHttpClient = new OkHttpClient.Builder()
                .readTimeout(60, TimeUnit.SECONDS)
                .connectTimeout(60, TimeUnit.SECONDS)
                .writeTimeout(60, TimeUnit.SECONDS)
                .addInterceptor(
                        new Interceptor() {
                            @Override
                            public Response intercept(Interceptor.Chain chain) throws IOException {
                                Request original = chain.request();
                                HttpUrl originalHttpUrl = original.url();
                                HttpUrl.Builder urlBuilder = originalHttpUrl.newBuilder();

                                Request.Builder requestBuilder = original.newBuilder()
                                        .url(urlBuilder.build());
                                if(!originalHttpUrl.toString().contains("media")){
                                    requestBuilder.addHeader(Constant.CONTENT_TYPE, Constant.CONTENT_TYPE_VALUE);
                                }
                                if(PreferencesManager.getInstance().isUserLoggedIn()){
                                    requestBuilder.addHeader(Constant.ACCESS_TOKEN, PreferencesManager.getInstance().getString(PreferencesManager.AUTH_TOKEN));
                                    requestBuilder.addHeader(Constant.ACCESS_ID, PreferencesManager.getInstance().getString(PreferencesManager.AUTH_ID));
                                }
                                Request request = requestBuilder.build();
                                Response response = chain.proceed(request);
                                if (response.code() == 401) {
                                    handleUnauthorisedResponse();
                                }

                                Log.d("Response:",new Gson().toJson(response));

                                return response;
//                                return chain.proceed(request);
                            }
                        }).build();

        Retrofit retrofit = new Retrofit.Builder()
                .baseUrl(IMAGE_BASE_URL)
                .client(defaultHttpClient)
                .addConverterFactory(GsonConverterFactory.create(gson))
                .build();
        return retrofit.create(APIService.class);
    }


    public static APIService getAPIService_LS() {
        Gson gson = new GsonBuilder()
                .setLenient()
                .create();
        OkHttpClient defaultHttpClient = new OkHttpClient.Builder()
                .readTimeout(60, TimeUnit.SECONDS)
                .connectTimeout(60, TimeUnit.SECONDS)
                .writeTimeout(60, TimeUnit.SECONDS)
                .addInterceptor(
                        new Interceptor() {
                            @Override
                            public Response intercept(Interceptor.Chain chain) throws IOException {
                                Request original = chain.request();
                                HttpUrl originalHttpUrl = original.url();
                                HttpUrl.Builder urlBuilder = originalHttpUrl.newBuilder();

                                Request.Builder requestBuilder = original.newBuilder()
                                        .url(urlBuilder.build());
                                if(!originalHttpUrl.toString().contains("media")){
                                    requestBuilder.addHeader(Constant.CONTENT_TYPE, Constant.CONTENT_TYPE_VALUE);
                                }
                                if(PreferencesManager.getInstance().isUserLoggedIn()){
                                    requestBuilder.addHeader(Constant.ACCESS_TOKEN, PreferencesManager.getInstance().getString(PreferencesManager.AUTH_TOKEN));
                                    requestBuilder.addHeader(Constant.ACCESS_ID, PreferencesManager.getInstance().getString(PreferencesManager.AUTH_ID));
                                }
                                Request request = requestBuilder.build();
                                Response response = chain.proceed(request);
                                if (response.code() == 401) {
                                    handleUnauthorisedResponse();
                                }

                                Log.d("Response:",new Gson().toJson(response));

                                return response;
//                                return chain.proceed(request);
                            }
                        }).build();

        Retrofit retrofit = new Retrofit.Builder()
                .baseUrl( BuildConfig.BASE_URL_LS)
                .client(defaultHttpClient)
                .addConverterFactory(GsonConverterFactory.create(gson))
                .build();
        return retrofit.create(APIService.class);
    }

    private static void handleUnauthorisedResponse() {
        if (NavController.getInstance()!=null){
            NavController.getInstance().clearBack();
            NavController.getInstance().addFragment(LoginFragment.newInstance(),false);
        }

    }
}
