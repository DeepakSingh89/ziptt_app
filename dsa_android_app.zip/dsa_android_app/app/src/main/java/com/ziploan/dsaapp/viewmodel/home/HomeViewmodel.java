package com.ziploan.dsaapp.viewmodel.home;

import android.view.View;

import com.ziploan.dsaapp.MainActivity;
import com.ziploan.dsaapp.R;
import com.ziploan.dsaapp.base.BaseViewModel;
import com.ziploan.dsaapp.fragments.edit_app.EditApplicationFragment;
import com.ziploan.dsaapp.fragments.home.MobileNumberFramgnet;
import com.ziploan.dsaapp.utils.NavController;

public class HomeViewmodel extends BaseViewModel implements View.OnClickListener {

    private MainActivity mainActivity;
    public void setMainActivity(MainActivity mainActivity){
        this.mainActivity = mainActivity;
    }

    @Override
    public void onClick(View view) {
        switch (view.getId()){
            case R.id.create_application:
                mainActivity.enableViews(true);
                NavController.getInstance().addFragment(MobileNumberFramgnet.newInstance(),true);
                break;
            case R.id.edit_application:
                mainActivity.enableViews(true);
                NavController.getInstance().addFragment(EditApplicationFragment.newInstance(),true);
                break;
        }
    }
}
