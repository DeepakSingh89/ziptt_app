
package com.ziploan.dsaapp.model.response.document;

import java.util.List;
import com.google.gson.annotations.Expose;
import com.google.gson.annotations.SerializedName;

public class _1 {

    @SerializedName("url")
    @Expose
    private List<String> url = null;
    @SerializedName("bank_name")
    @Expose
    private String bankName;
    @SerializedName("password")
    @Expose
    private String password;
    @SerializedName("account_type")
    @Expose
    private String accountType;

    public List<String> getUrl() {
        return url;
    }

    public void setUrl(List<String> url) {
        this.url = url;
    }

    public String getBankName() {
        return bankName;
    }

    public void setBankName(String bankName) {
        this.bankName = bankName;
    }

    public String getPassword() {
        return password;
    }

    public void setPassword(String password) {
        this.password = password;
    }

    public String getAccountType() {
        return accountType;
    }

    public void setAccountType(String accountType) {
        this.accountType = accountType;
    }

}
