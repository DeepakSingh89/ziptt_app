package com.ziploan.dsaapp.model.header;

import android.os.Parcel;
import android.os.Parcelable;
import android.text.TextUtils;
import android.view.View;

import com.google.gson.annotations.SerializedName;

import com.ziploan.dsaapp.MyApplication;
import com.ziploan.dsaapp.R;
import com.ziploan.dsaapp.fragments.details.BusinessDetailsFragment;
import com.ziploan.dsaapp.fragments.details.CoApplicantFragment;
import com.ziploan.dsaapp.fragments.details.DocumentUploadDetailsFragment;
import com.ziploan.dsaapp.fragments.details.PersonalDetailsFragment;
import com.ziploan.dsaapp.utils.NavController;

public class HeaderModel implements View.OnClickListener {

    @SerializedName("personalActiveIcon")
    private boolean personalActiveIcon;

    @SerializedName("personalDoneIcon")
    private boolean personalDoneIcon;

    @SerializedName("personalSmallText")
    private boolean personalSmallText;

    @SerializedName("personalLargeText")
    private boolean personalLargeText;

    @SerializedName("businessActiveIcon")
    private boolean businessActiveIcon;

    @SerializedName("businessDoneIcon")
    private boolean businessDoneIcon;

    @SerializedName("businessInActiveIcon")
    private boolean businessInActiveIcon;

    @SerializedName("businessSmallText")
    private boolean businessSmallText;

    @SerializedName("businessLargeText")
    private boolean businessLargeText;

    @SerializedName("coApplicantWholeLayout")
    private boolean coApplicantWholeLayout;

    @SerializedName("coApplicantActiveIcon")
    private boolean coApplicantActiveIcon;

    @SerializedName("coApplicantDoneIcon")
    private boolean coApplicantDoneIcon;

    @SerializedName("coApplicantInActiveIcon")
    private boolean coApplicantInActiveIcon;

    @SerializedName("coApplicantSmallText")
    private boolean coApplicantSmallText;

    @SerializedName("coApplicantLargeText")
    private boolean coApplicantLargeText;

    @SerializedName("documentsActiveIcon")
    private boolean documentsActiveIcon;

    @SerializedName("documentsDoneIcon")
    private boolean documentsDoneIcon;

    @SerializedName("documentsInActiveIcon")
    private boolean documentsInActiveIcon;

    @SerializedName("documentsSmallText")
    private boolean documentsSmallText;

    @SerializedName("documentsLargeText")
    private boolean documentsLargeText;

    @SerializedName("showPeronalLayout")
    private boolean showPeronalLayout = true;

    @SerializedName("showBusinessLayout")
    private boolean showBusinessLayout = true;

    public boolean isShowPeronalLayout() {
        return showPeronalLayout;
    }

    public void setShowPeronalLayout(boolean showPeronalLayout) {
        this.showPeronalLayout = showPeronalLayout;
    }

    public boolean isShowBusinessLayout() {
        return showBusinessLayout;
    }

    public void setShowBusinessLayout(boolean showBusinessLayout) {
        this.showBusinessLayout = showBusinessLayout;
    }

    public boolean isShowDocumentLayout() {
        return showDocumentLayout;
    }

    public void setShowDocumentLayout(boolean showDocumentLayout) {
        this.showDocumentLayout = showDocumentLayout;
    }

    private boolean showDocumentLayout;

    public HeaderModel(){}

    public boolean isPersonalDoneIcon() {
        return personalDoneIcon;
    }

    public void setPersonalDoneIcon(boolean personalDoneIcon) {
        this.personalDoneIcon = personalDoneIcon;
    }

    public boolean isPersonalSmallText() {
        return personalSmallText;
    }

    public void setPersonalSmallText(boolean personalSmallText) {
        this.personalSmallText = personalSmallText;
    }

    public boolean isPersonalLargeText() {
        return personalLargeText;
    }

    public void setPersonalLargeText(boolean personalLargeText) {
        this.personalLargeText = personalLargeText;
    }

    public boolean isBusinessActiveIcon() {
        return businessActiveIcon;
    }

    public void setBusinessActiveIcon(boolean businessActiveIcon) {
        this.businessActiveIcon = businessActiveIcon;
    }

    public boolean isBusinessDoneIcon() {
        return businessDoneIcon;
    }

    public void setBusinessDoneIcon(boolean businessDoneIcon) {
        this.businessDoneIcon = businessDoneIcon;
    }

    public boolean isBusinessInActiveIcon() {
        return businessInActiveIcon;
    }

    public void setBusinessInActiveIcon(boolean businessInActiveIcon) {
        this.businessInActiveIcon = businessInActiveIcon;
    }

    public boolean isBusinessSmallText() {
        return businessSmallText;
    }

    public void setBusinessSmallText(boolean businessSmallText) {
        this.businessSmallText = businessSmallText;
    }

    public boolean isBusinessLargeText() {
        return businessLargeText;
    }

    public void setBusinessLargeText(boolean businessLargeText) {
        this.businessLargeText = businessLargeText;
    }

    public boolean isCoApplicantActiveIcon() {
        return coApplicantActiveIcon;
    }

    public void setCoApplicantActiveIcon(boolean coApplicantActiveIcon) {
        this.coApplicantActiveIcon = coApplicantActiveIcon;
    }

    public boolean isCoApplicantDoneIcon() {
        return coApplicantDoneIcon;
    }

    public void setCoApplicantDoneIcon(boolean coApplicantDoneIcon) {
        this.coApplicantDoneIcon = coApplicantDoneIcon;
    }

    public boolean isCoApplicantInActiveIcon() {
        return coApplicantInActiveIcon;
    }

    public void setCoApplicantInActiveIcon(boolean coApplicantInActiveIcon) {
        this.coApplicantInActiveIcon = coApplicantInActiveIcon;
    }

    public boolean isCoApplicantSmallText() {
        return coApplicantSmallText;
    }

    public void setCoApplicantSmallText(boolean coApplicantSmallText) {
        this.coApplicantSmallText = coApplicantSmallText;
    }

    public boolean isCoApplicantLargeText() {
        return coApplicantLargeText;
    }

    public void setCoApplicantLargeText(boolean coApplicantLargeText) {
        this.coApplicantLargeText = coApplicantLargeText;
    }

    public boolean isDocumentsActiveIcon() {
        return documentsActiveIcon;
    }

    public void setDocumentsActiveIcon(boolean documentsActiveIcon) {
        this.documentsActiveIcon = documentsActiveIcon;
    }

    public boolean isDocumentsDoneIcon() {
        return documentsDoneIcon;
    }

    public void setDocumentsDoneIcon(boolean documentsDoneIcon) {
        this.documentsDoneIcon = documentsDoneIcon;
    }

    public boolean isDocumentsInActiveIcon() {
        return documentsInActiveIcon;
    }

    public void setDocumentsInActiveIcon(boolean documentsInActiveIcon) {
        this.documentsInActiveIcon = documentsInActiveIcon;
    }

    public boolean isDocumentsSmallText() {
        return documentsSmallText;
    }

    public void setDocumentsSmallText(boolean documentsSmallText) {
        this.documentsSmallText = documentsSmallText;
    }

    public boolean isDocumentsLargeText() {
        return documentsLargeText;
    }

    public void setDocumentsLargeText(boolean documentsLargeText) {
        this.documentsLargeText = documentsLargeText;
    }

    public boolean isPersonalActiveIcon() {
        return personalActiveIcon;
    }

    public void setPersonalActiveIcon(boolean personalActiveIcon) {
        this.personalActiveIcon = personalActiveIcon;
    }

    public void setCoApplicantWholeLayout(boolean coApplicantWholeLayout) {
        this.coApplicantWholeLayout = coApplicantWholeLayout;
    }

    public boolean isCoApplicantWholeLayout() {
        return coApplicantWholeLayout;
    }


    public static HeaderModel setForPersonal(){
        HeaderModel headerModel = new HeaderModel();
        headerModel.setPersonalLargeText(true);
        headerModel.setPersonalActiveIcon(true);
        headerModel.setPersonalDoneIcon(false);
        headerModel.setPersonalSmallText(false);

        headerModel.setBusinessActiveIcon(false);
        headerModel.setBusinessDoneIcon(false);
        headerModel.setBusinessInActiveIcon(true);
        headerModel.setBusinessLargeText(false);
        headerModel.setBusinessSmallText(true);

        headerModel.setDocumentsActiveIcon(false);
        headerModel.setDocumentsDoneIcon(false);
        headerModel.setDocumentsInActiveIcon(true);
        headerModel.setBusinessLargeText(false);
        headerModel.setDocumentsSmallText(true);

        headerModel.setCoApplicantWholeLayout(false);
        return headerModel;
    }

    public static HeaderModel setForPersonalWtihCoApplicent(){
        HeaderModel headerModel = new HeaderModel();
        headerModel.setPersonalLargeText(true);
        headerModel.setPersonalActiveIcon(true);
        headerModel.setPersonalDoneIcon(false);
        headerModel.setPersonalSmallText(false);

        headerModel.setBusinessActiveIcon(false);
        headerModel.setBusinessDoneIcon(false);
        headerModel.setBusinessInActiveIcon(true);
        headerModel.setBusinessLargeText(false);
        headerModel.setBusinessSmallText(true);

        headerModel.setDocumentsActiveIcon(false);
        headerModel.setDocumentsDoneIcon(false);
        headerModel.setDocumentsInActiveIcon(true);
        headerModel.setBusinessLargeText(false);
        headerModel.setDocumentsSmallText(true);

        headerModel.setCoApplicantWholeLayout(true);
        headerModel.setCoApplicantActiveIcon(false);
        headerModel.setCoApplicantDoneIcon(false);
        headerModel.setCoApplicantInActiveIcon(true);
        headerModel.setCoApplicantLargeText(false);
        headerModel.setCoApplicantSmallText(true);
        return headerModel;
    }

    public static HeaderModel setForBusiness(){
        HeaderModel headerModel = new HeaderModel();
        headerModel.setPersonalLargeText(false);
        headerModel.setPersonalActiveIcon(false);
        headerModel.setPersonalDoneIcon(true);
        headerModel.setPersonalSmallText(true);

        headerModel.setBusinessActiveIcon(true);
        headerModel.setBusinessDoneIcon(false);
        headerModel.setBusinessInActiveIcon(false);
        headerModel.setBusinessLargeText(true);
        headerModel.setBusinessSmallText(false);

        headerModel.setDocumentsActiveIcon(false);
        headerModel.setDocumentsDoneIcon(false);
        headerModel.setDocumentsInActiveIcon(true);
        headerModel.setDocumentsLargeText(false);
        headerModel.setDocumentsSmallText(true);

        headerModel.setCoApplicantWholeLayout(false);
        return headerModel;
    }

    public static HeaderModel setForBusinessWithCoApplicant(){
        HeaderModel headerModel = new HeaderModel();
        headerModel.setPersonalLargeText(false);
        headerModel.setPersonalActiveIcon(false);
        headerModel.setPersonalDoneIcon(true);
        headerModel.setPersonalSmallText(true);

        headerModel.setBusinessActiveIcon(true);
        headerModel.setBusinessDoneIcon(false);
        headerModel.setBusinessInActiveIcon(false);
        headerModel.setBusinessLargeText(true);
        headerModel.setBusinessSmallText(false);

        headerModel.setDocumentsActiveIcon(false);
        headerModel.setDocumentsDoneIcon(false);
        headerModel.setDocumentsInActiveIcon(true);
        headerModel.setDocumentsLargeText(false);
        headerModel.setDocumentsSmallText(true);

        headerModel.setCoApplicantWholeLayout(true);
        headerModel.setCoApplicantActiveIcon(false);
        headerModel.setCoApplicantDoneIcon(false);
        headerModel.setCoApplicantInActiveIcon(true);
        headerModel.setCoApplicantLargeText(false);
        headerModel.setCoApplicantSmallText(true);
        return headerModel;
    }

    public static HeaderModel setForDocument(){
        HeaderModel headerModel = new HeaderModel();
        headerModel.setPersonalLargeText(false);
        headerModel.setPersonalActiveIcon(false);
        headerModel.setPersonalDoneIcon(true);
        headerModel.setPersonalSmallText(true);

        headerModel.setBusinessActiveIcon(false);
        headerModel.setBusinessDoneIcon(true);
        headerModel.setBusinessInActiveIcon(false);
        headerModel.setBusinessLargeText(false);
        headerModel.setBusinessSmallText(true);

        headerModel.setDocumentsActiveIcon(true);
        headerModel.setDocumentsDoneIcon(false);
        headerModel.setDocumentsInActiveIcon(false);
        headerModel.setDocumentsLargeText(true);
        headerModel.setDocumentsSmallText(false);

        headerModel.setCoApplicantWholeLayout(false);
        return headerModel;
    }

    public static HeaderModel setForOnlyDocument(){
        HeaderModel headerModel = new HeaderModel();
        headerModel.setShowPeronalLayout(false);
        headerModel.setShowBusinessLayout(false);
        headerModel.setPersonalLargeText(false);
        headerModel.setPersonalActiveIcon(false);
        headerModel.setPersonalDoneIcon(false);
        headerModel.setPersonalSmallText(false);

        headerModel.setBusinessActiveIcon(false);
        headerModel.setBusinessDoneIcon(false);
        headerModel.setBusinessInActiveIcon(false);
        headerModel.setBusinessLargeText(false);
        headerModel.setBusinessSmallText(false);

        headerModel.setDocumentsActiveIcon(false);
        headerModel.setDocumentsDoneIcon(true);
        headerModel.setDocumentsInActiveIcon(false);
        headerModel.setDocumentsLargeText(true);
        headerModel.setDocumentsSmallText(false);

        headerModel.setCoApplicantWholeLayout(false);
        return headerModel;
    }

    public static HeaderModel setForDocumentWithCoapplicent(){
        HeaderModel headerModel = new HeaderModel();
        headerModel.setPersonalLargeText(false);
        headerModel.setPersonalActiveIcon(false);
        headerModel.setPersonalDoneIcon(true);
        headerModel.setPersonalSmallText(true);

        headerModel.setBusinessActiveIcon(false);
        headerModel.setBusinessDoneIcon(true);
        headerModel.setBusinessInActiveIcon(false);
        headerModel.setBusinessLargeText(false);
        headerModel.setBusinessSmallText(true);

        headerModel.setDocumentsActiveIcon(true);
        headerModel.setDocumentsDoneIcon(false);
        headerModel.setDocumentsInActiveIcon(false);
        headerModel.setDocumentsLargeText(true);
        headerModel.setDocumentsSmallText(false);

        headerModel.setCoApplicantWholeLayout(true);
        headerModel.setCoApplicantActiveIcon(false);
        headerModel.setCoApplicantDoneIcon(false);
        headerModel.setCoApplicantInActiveIcon(true);
        headerModel.setCoApplicantLargeText(false);
        headerModel.setCoApplicantSmallText(true);
        return headerModel;
    }

    public static HeaderModel setForCoApplicant(){
        HeaderModel headerModel = new HeaderModel();
        headerModel.setPersonalLargeText(false);
        headerModel.setPersonalActiveIcon(false);
        headerModel.setPersonalDoneIcon(true);
        headerModel.setPersonalSmallText(true);

        headerModel.setBusinessActiveIcon(false);
        headerModel.setBusinessDoneIcon(true);
        headerModel.setBusinessInActiveIcon(false);
        headerModel.setBusinessLargeText(false);
        headerModel.setBusinessSmallText(true);

        headerModel.setCoApplicantWholeLayout(true);
        headerModel.setCoApplicantActiveIcon(true);
        headerModel.setCoApplicantDoneIcon(false);
        headerModel.setCoApplicantInActiveIcon(false);
        headerModel.setCoApplicantLargeText(true);
        headerModel.setCoApplicantSmallText(false);

        headerModel.setDocumentsActiveIcon(false);
        headerModel.setDocumentsDoneIcon(false);
        headerModel.setDocumentsInActiveIcon(true);
        headerModel.setDocumentsLargeText(false);
        headerModel.setDocumentsSmallText(true);

        return headerModel;
    }

    public static HeaderModel setForCoApplicantDesabled(){
        HeaderModel headerModel = new HeaderModel();
        headerModel.setPersonalLargeText(false);
        headerModel.setPersonalActiveIcon(false);
        headerModel.setPersonalDoneIcon(true);
        headerModel.setPersonalSmallText(true);

        headerModel.setBusinessActiveIcon(true);
        headerModel.setBusinessDoneIcon(false);
        headerModel.setBusinessInActiveIcon(false);
        headerModel.setBusinessLargeText(true);
        headerModel.setBusinessSmallText(false);

        headerModel.setCoApplicantWholeLayout(true);
        headerModel.setCoApplicantActiveIcon(false);
        headerModel.setCoApplicantDoneIcon(false);
        headerModel.setCoApplicantInActiveIcon(true);
        headerModel.setCoApplicantLargeText(false);
        headerModel.setCoApplicantSmallText(true);

        headerModel.setDocumentsActiveIcon(false);
        headerModel.setDocumentsDoneIcon(false);
        headerModel.setDocumentsInActiveIcon(true);
        headerModel.setDocumentsLargeText(false);
        headerModel.setDocumentsSmallText(true);

        return headerModel;
    }

    public static HeaderModel setForDocumentFilled(String type){
        HeaderModel headerModel = new HeaderModel();
        headerModel.setPersonalLargeText(false);
        headerModel.setPersonalActiveIcon(false);
        headerModel.setPersonalDoneIcon(true);
        headerModel.setPersonalSmallText(true);

        headerModel.setBusinessActiveIcon(false);
        headerModel.setBusinessDoneIcon(true);
        headerModel.setBusinessInActiveIcon(false);
        headerModel.setBusinessLargeText(false);
        headerModel.setBusinessSmallText(true);

        headerModel.setDocumentsActiveIcon(false);
        headerModel.setDocumentsDoneIcon(true);
        headerModel.setDocumentsInActiveIcon(false);
        headerModel.setDocumentsLargeText(false);
        headerModel.setDocumentsSmallText(true);

        headerModel.setCoApplicantWholeLayout(false);

        if(type.equalsIgnoreCase("p")){
            headerModel.setPersonalSmallText(false);
            headerModel.setPersonalLargeText(true);

        } else if(type.equalsIgnoreCase("b")){
            headerModel.setBusinessLargeText(true);
            headerModel.setBusinessSmallText(false);

        } else if(type.equalsIgnoreCase("c")){
            headerModel.setCoApplicantLargeText(true);
            headerModel.setCoApplicantSmallText(false);
        } else if(type.equalsIgnoreCase("d")){
            headerModel.setDocumentsLargeText(true);
            headerModel.setDocumentsSmallText(false);
        }
        return headerModel;
    }

    public static HeaderModel setForBusinessFilled(String type){
        HeaderModel headerModel = new HeaderModel();
        headerModel.setPersonalLargeText(false);
        headerModel.setPersonalActiveIcon(false);
        headerModel.setPersonalDoneIcon(true);
        headerModel.setPersonalSmallText(true);

        headerModel.setBusinessActiveIcon(false);
        headerModel.setBusinessDoneIcon(true);
        headerModel.setBusinessInActiveIcon(false);
        headerModel.setBusinessLargeText(false);
        headerModel.setBusinessSmallText(true);

        headerModel.setDocumentsActiveIcon(false);
        headerModel.setDocumentsDoneIcon(false);
        headerModel.setDocumentsInActiveIcon(true);
        headerModel.setDocumentsLargeText(false);
        headerModel.setDocumentsSmallText(true);

        headerModel.setCoApplicantWholeLayout(false);

        if(type.equalsIgnoreCase("p")){
            headerModel.setPersonalSmallText(false);
            headerModel.setPersonalLargeText(true);

        } else if(type.equalsIgnoreCase("b")){
            headerModel.setBusinessLargeText(true);
            headerModel.setBusinessSmallText(false);

        } else if(type.equalsIgnoreCase("c")){
            headerModel.setCoApplicantLargeText(true);
            headerModel.setCoApplicantSmallText(false);
        } else if(type.equalsIgnoreCase("d")){
            headerModel.setDocumentsLargeText(true);
            headerModel.setDocumentsSmallText(false);
            headerModel.setDocumentsInActiveIcon(false);
            headerModel.setDocumentsActiveIcon(true);
        }
        return headerModel;
    }

    public static HeaderModel setForPersonalInfoFilled(String type){
        HeaderModel headerModel = new HeaderModel();
        headerModel.setPersonalLargeText(false);
        headerModel.setPersonalActiveIcon(false);
        headerModel.setPersonalDoneIcon(true);
        headerModel.setPersonalSmallText(true);

        headerModel.setBusinessActiveIcon(false);
        headerModel.setBusinessDoneIcon(false);
        headerModel.setBusinessInActiveIcon(true);
        headerModel.setBusinessLargeText(false);
        headerModel.setBusinessSmallText(true);

        headerModel.setDocumentsActiveIcon(false);
        headerModel.setDocumentsDoneIcon(false);
        headerModel.setDocumentsInActiveIcon(true);
        headerModel.setDocumentsLargeText(false);
        headerModel.setDocumentsSmallText(true);

        headerModel.setCoApplicantWholeLayout(false);

        if(type.equalsIgnoreCase("p")){
            headerModel.setPersonalSmallText(false);
            headerModel.setPersonalLargeText(true);

        } else if(type.equalsIgnoreCase("b")){
            headerModel.setBusinessLargeText(true);
            headerModel.setBusinessSmallText(false);
            headerModel.setBusinessInActiveIcon(false);
            headerModel.setBusinessActiveIcon(true);

        } else if(type.equalsIgnoreCase("c")){
            headerModel.setCoApplicantLargeText(true);
            headerModel.setCoApplicantSmallText(false);
        } else if(type.equalsIgnoreCase("d")){
            headerModel.setDocumentsLargeText(true);
            headerModel.setDocumentsSmallText(false);
        }
        return headerModel;
    }

    public static HeaderModel setForPersonalInfoFilledCo(String type){
        HeaderModel headerModel = new HeaderModel();
        headerModel.setPersonalLargeText(false);
        headerModel.setPersonalActiveIcon(false);
        headerModel.setPersonalDoneIcon(true);
        headerModel.setPersonalSmallText(true);

        headerModel.setBusinessActiveIcon(true);
        headerModel.setBusinessDoneIcon(false);
        headerModel.setBusinessInActiveIcon(false);
        headerModel.setBusinessLargeText(false);
        headerModel.setBusinessSmallText(true);

        headerModel.setDocumentsActiveIcon(false);
        headerModel.setDocumentsDoneIcon(false);
        headerModel.setDocumentsInActiveIcon(true);
        headerModel.setDocumentsLargeText(false);
        headerModel.setDocumentsSmallText(true);

        headerModel.setCoApplicantWholeLayout(false);
        headerModel.setCoApplicantWholeLayout(true);
        headerModel.setCoApplicantActiveIcon(false);
        headerModel.setCoApplicantDoneIcon(true);
        headerModel.setCoApplicantInActiveIcon(false);
        headerModel.setCoApplicantLargeText(false);
        headerModel.setCoApplicantSmallText(true);

        if(type.equalsIgnoreCase("p")){
            headerModel.setPersonalSmallText(false);
            headerModel.setPersonalLargeText(true);

        } else if(type.equalsIgnoreCase("b")){
            headerModel.setBusinessLargeText(true);
            headerModel.setBusinessSmallText(false);

        } else if(type.equalsIgnoreCase("c")){
            headerModel.setCoApplicantLargeText(true);
            headerModel.setCoApplicantSmallText(false);
        } else if(type.equalsIgnoreCase("d")){
            headerModel.setDocumentsLargeText(true);
            headerModel.setDocumentsSmallText(false);
        }
        return headerModel;
    }

    public static HeaderModel setForBusinessCoapplicantFilled(String type){
        HeaderModel headerModel = new HeaderModel();
        headerModel.setPersonalLargeText(false);
        headerModel.setPersonalActiveIcon(false);
        headerModel.setPersonalDoneIcon(true);
        headerModel.setPersonalSmallText(true);

        headerModel.setBusinessActiveIcon(false);
        headerModel.setBusinessDoneIcon(true);
        headerModel.setBusinessInActiveIcon(false);
        headerModel.setBusinessLargeText(false);
        headerModel.setBusinessSmallText(true);

        headerModel.setDocumentsActiveIcon(false);
        headerModel.setDocumentsDoneIcon(false);
        headerModel.setDocumentsInActiveIcon(true);
        headerModel.setDocumentsLargeText(false);
        headerModel.setDocumentsSmallText(true);

        headerModel.setCoApplicantWholeLayout(true);
        headerModel.setCoApplicantActiveIcon(false);
        headerModel.setCoApplicantDoneIcon(false);
        headerModel.setCoApplicantInActiveIcon(true);
        headerModel.setCoApplicantLargeText(false);
        headerModel.setCoApplicantSmallText(true);

        if(type.equalsIgnoreCase("p")){
            headerModel.setPersonalSmallText(false);
            headerModel.setPersonalLargeText(true);

        } else if(type.equalsIgnoreCase("b")){
            headerModel.setBusinessLargeText(true);
            headerModel.setBusinessSmallText(false);

        } else if(type.equalsIgnoreCase("c")){
            headerModel.setCoApplicantLargeText(true);
            headerModel.setCoApplicantSmallText(false);
            headerModel.setCoApplicantActiveIcon(true);
        } else if(type.equalsIgnoreCase("d")){
            headerModel.setDocumentsLargeText(true);
            headerModel.setDocumentsSmallText(false);
        }
        return headerModel;
    }

    public static HeaderModel setForDocumentFilledWithCoApplicant(String type){
        HeaderModel headerModel = new HeaderModel();

        headerModel.setPersonalActiveIcon(false);
        headerModel.setPersonalDoneIcon(true);
        headerModel.setPersonalSmallText(true);
        headerModel.setPersonalLargeText(false);

        headerModel.setBusinessActiveIcon(false);
        headerModel.setBusinessDoneIcon(true);
        headerModel.setBusinessInActiveIcon(false);
        headerModel.setBusinessLargeText(false);
        headerModel.setBusinessSmallText(true);

        headerModel.setDocumentsActiveIcon(false);
        headerModel.setDocumentsDoneIcon(true);
        headerModel.setDocumentsInActiveIcon(false);
        headerModel.setDocumentsLargeText(false);
        headerModel.setDocumentsSmallText(true);

        headerModel.setCoApplicantWholeLayout(true);
        headerModel.setCoApplicantActiveIcon(false);
        headerModel.setCoApplicantDoneIcon(true);
        headerModel.setCoApplicantInActiveIcon(false);
        headerModel.setCoApplicantLargeText(false);
        headerModel.setCoApplicantSmallText(true);

        if(type.equalsIgnoreCase("p")){
            headerModel.setPersonalSmallText(false);
            headerModel.setPersonalLargeText(true);

        } else if(type.equalsIgnoreCase("b")){
            headerModel.setBusinessLargeText(true);
            headerModel.setBusinessSmallText(false);

        } else if(type.equalsIgnoreCase("c")){
            headerModel.setCoApplicantLargeText(true);
            headerModel.setCoApplicantSmallText(false);
        } else if(type.equalsIgnoreCase("d")){
            headerModel.setDocumentsLargeText(true);
            headerModel.setDocumentsSmallText(false);
        }

        return headerModel;
    }

    public static HeaderModel setForDocumentFilledWithCoApplicantunfilled(String type){
        HeaderModel headerModel = new HeaderModel();

        headerModel.setPersonalActiveIcon(false);
        headerModel.setPersonalDoneIcon(true);
        headerModel.setPersonalSmallText(true);
        headerModel.setPersonalLargeText(false);

        headerModel.setBusinessActiveIcon(false);
        headerModel.setBusinessDoneIcon(true);
        headerModel.setBusinessInActiveIcon(false);
        headerModel.setBusinessLargeText(false);
        headerModel.setBusinessSmallText(true);

        headerModel.setDocumentsActiveIcon(false);
        headerModel.setDocumentsDoneIcon(true);
        headerModel.setDocumentsInActiveIcon(false);
        headerModel.setDocumentsLargeText(false);
        headerModel.setDocumentsSmallText(true);

        headerModel.setCoApplicantWholeLayout(true);
        headerModel.setCoApplicantActiveIcon(false);
        headerModel.setCoApplicantDoneIcon(false);
        headerModel.setCoApplicantInActiveIcon(false);
        headerModel.setCoApplicantLargeText(false);
        headerModel.setCoApplicantSmallText(false);

        if(type.equalsIgnoreCase("p")){
            headerModel.setPersonalSmallText(false);
            headerModel.setPersonalLargeText(true);
            headerModel.setCoApplicantInActiveIcon(true);
            headerModel.setCoApplicantSmallText(true);
        } else if(type.equalsIgnoreCase("b")){
            headerModel.setBusinessLargeText(true);
            headerModel.setBusinessSmallText(false);
            headerModel.setCoApplicantInActiveIcon(true);
            headerModel.setCoApplicantSmallText(true);
        } else if(type.equalsIgnoreCase("c")){
            headerModel.setCoApplicantLargeText(true);
            headerModel.setCoApplicantSmallText(false);
            headerModel.setCoApplicantActiveIcon(true);
        } else if(type.equalsIgnoreCase("d")){
            headerModel.setDocumentsLargeText(true);
            headerModel.setDocumentsSmallText(false);
            headerModel.setCoApplicantInActiveIcon(true);
            headerModel.setCoApplicantSmallText(true);
        }

        return headerModel;
    }

    public static HeaderModel setForCoapplicantFilled(String type){
        HeaderModel headerModel = new HeaderModel();
        headerModel.setPersonalLargeText(false);
        headerModel.setPersonalActiveIcon(false);
        headerModel.setPersonalDoneIcon(true);
        headerModel.setPersonalSmallText(true);

        headerModel.setBusinessActiveIcon(false);
        headerModel.setBusinessDoneIcon(true);
        headerModel.setBusinessInActiveIcon(false);
        headerModel.setBusinessLargeText(false);
        headerModel.setBusinessSmallText(true);

        headerModel.setDocumentsDoneIcon(false);
        headerModel.setDocumentsLargeText(false);
        headerModel.setDocumentsSmallText(true);

        headerModel.setCoApplicantWholeLayout(true);
        headerModel.setCoApplicantActiveIcon(false);
        headerModel.setCoApplicantDoneIcon(true);
        headerModel.setCoApplicantInActiveIcon(false);
        headerModel.setCoApplicantLargeText(false);
        headerModel.setCoApplicantSmallText(true);

        if(type.equalsIgnoreCase("p")){
            headerModel.setPersonalSmallText(false);
            headerModel.setPersonalLargeText(true);
            headerModel.setDocumentsInActiveIcon(true);
            headerModel.setDocumentsActiveIcon(false);
        } else if(type.equalsIgnoreCase("b")){
            headerModel.setBusinessLargeText(true);
            headerModel.setBusinessSmallText(false);
            headerModel.setDocumentsInActiveIcon(true);
            headerModel.setDocumentsActiveIcon(false);
        } else if(type.equalsIgnoreCase("c")){
            headerModel.setCoApplicantLargeText(true);
            headerModel.setCoApplicantSmallText(false);
            headerModel.setDocumentsInActiveIcon(true);
            headerModel.setDocumentsActiveIcon(false);
        } else if(type.equalsIgnoreCase("d")){
            headerModel.setDocumentsLargeText(true);
            headerModel.setDocumentsSmallText(false);
            headerModel.setDocumentsInActiveIcon(false);
            headerModel.setDocumentsActiveIcon(true);

        }
        return headerModel;
    }

    @Override
    public void onClick(View view) {
        switch (view.getId()){
            case R.id.personal_info_layut:
                if(!personalActiveIcon)
                    NavController.getInstance().addFragment(PersonalDetailsFragment.newInstance("", MyApplication.LOAN_REQ_ID,
                        coApplicantWholeLayout ? 4 : 3), true);
                break;
            case R.id.business_info_layout:
                if(MyApplication.formResponse != null && MyApplication.formResponse.getPersonalInfoFilled())
                    NavController.getInstance().addFragment(BusinessDetailsFragment.newInstance(MyApplication.LOAN_REQ_ID
                        , coApplicantWholeLayout ? 4 : 3), true);
                break;
            case R.id.co_applicant_info_layout:
                if(MyApplication.formResponse != null && MyApplication.formResponse.getBusinessInfoFilled())
                    NavController.getInstance().addFragment(CoApplicantFragment.newInstance(MyApplication.LOAN_REQ_ID), true);
                break;
            case R.id.document_info_layout:
//                if(!documentsInActiveIcon && !TextUtils.isEmpty(MyApplication.LOAN_REQ_ID)
//                        && MyApplication.BusinessDetailsField)
                if((MyApplication.formResponse != null && MyApplication.formResponse.getShowPages().size() == 4)){
                    if(MyApplication.formResponse.getCoapplicantFilled()){
                        NavController.getInstance().addFragment(DocumentUploadDetailsFragment.newInstance(MyApplication.LOAN_REQ_ID
                                , coApplicantWholeLayout ? 4 : 3), true);
                    }
                }
                else if(MyApplication.formResponse != null && MyApplication.formResponse.getBusinessInfoFilled()){
                    NavController.getInstance().addFragment(DocumentUploadDetailsFragment.newInstance(MyApplication.LOAN_REQ_ID
                            ,  3), true);
                }

                break;
        }
    }
}
