package com.ziploan.dsaapp.utils;

import com.ziploan.dsaapp.BuildConfig;

public class Constant {
    public static final String MEDIA_URL = BuildConfig.IMAGE_BASE_URL;
    public static final String CONTENT_TYPE_VALUE = "application/json";
    public static final String CONTENT_TYPE = "Content-Type";
    public static final String LOCAL_ENV = "local";
    public static final String ENV = "prod";
    public static final String ACCESS_ID = "access-id";
    public static final String ACCESS_TOKEN = "access-token";
    public static final String AUTHORIZATION = "Authorization";
    public final static String MANUFACTURER = "manufacturer";
    public final static String DEVICE_ID = "device-id";
    public final static String MODEL = "model";
    public final static String VERSION_RELEASE = "versionRelease";
    public final static String APP_VERSION_CODE = "manufacturer";

    public static final int SUCCESS_RESULT = 0;
    public static final int FAILURE_RESULT = 1;
    public static final String PACKAGE_NAME = BuildConfig.APPLICATION_ID;
    public static final String RECEIVER = PACKAGE_NAME + ".RECEIVER";
    public static final String RESULT_DATA_KEY = PACKAGE_NAME +
            ".RESULT_DATA_KEY";
    public static final String LOCATION_DATA_EXTRA = PACKAGE_NAME +
            ".LOCATION_DATA_EXTRA";
    public static final String ADDRESS_INFO = PACKAGE_NAME +
            ".ADDRESS";

    public static final String LOAN_PRODUCT_ID = "57638be176d30015c99ea0ad";
    public static final int PERSONAL_INFO_APPLICANT_TYPE = 1;
    public static final int CO_APPLICANT_APPLICANT_TYPE = 2;
    public static final String NEW_APPLICATION_TYPE = "new";
    public static final String EDIT_APPLICATION_TYPE = "edit";
    public static final String ACCESS_EXPIRATION_TIME = "acces_expiration_time";
    public static final String SUCCESS = "success";
    public static final String REJECTED = "rejected";
    public static final String LOCAL = "local";
    public static final int CAMERA_REQUEST = 100;
    public static final int GALLERY_REQUEST = 101;
    public static final int FILE_REQUEST = 102;
    public static final String PERSONAL_INFO_TAG = "p";
    public static final String BUSINESS_INFO_TAG = "b";
    public static final String CO_APPLICANT_INFO_TAG = "c";
    public static final String DOCUMENT_INFO_TAG = "d";

    public class FileUploadBucketId{
        public static final int BUSINESS_PLACE_PHOTO = 1;
        public static final int ITR = 2;
        public static final int BANKSTATEMENT = 3;
    }

    public class MediaType {
        public static final String IMAGE = "image/jpeg";
        public static final String PDF = "application/pdf";
    }

    public class FileType {
        public static final String ASSET_BUSINESS_PLACE_PHOTO = "asset_verification_business_photos";
        public static final String PD_BUSINESS_PLACE_PHOTO = "BusinessPlacePhotos";
        public static final String KYC_BUSINESS_DOCUMENTS = "kyc";
    }

    public class FileUploadEnvironment{
        public static final String PRODUCTION = "prod";
        public static final String UAT = "uat";
    }


    public class FileUploadBankType{
        public static final int PRIMARY = 1;
        public static final int SECONDARY = 2;
    }

    public class MimeType {
        public static final int IMAGE = 1;
        public static final int PDF = 2;
        public static final int OTHER = -1;
    }

    public class BankType {
        public static final String PRIMERY = "1";
        public static final String SECONDARY = "2";
    }

    public class ImageSourceType{
        public static final int GALLERY = 1;
        public static final int CAMREA = 0;
        public static final int PDF = 2;
    }

    public class UploadStatus {
        public static final int UPLOADING_STARTED = 0;
        public static final int UPLOADING_SUCCESS = 1;
        public static final int UPLOADING_FAILED = 2;
    }
    public class LocalBroadcastType {
        public static final String APPLICATION_POST_STATUS = "application_post_status";
        public static final int APPLICATION_SUBMITTED_LOCALLY = 1;
        public static final int FILE_UPLOADING_STARTED = 2;
        public static final int FILE_UPLOADING_COMPLETED = 3;
        public static final int FILE_UPLOADING_FAILED = 4;
    }
}
