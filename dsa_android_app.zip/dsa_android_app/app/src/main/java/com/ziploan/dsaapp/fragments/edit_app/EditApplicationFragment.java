package com.ziploan.dsaapp.fragments.edit_app;

import android.content.Context;
import android.os.Bundle;
import android.text.Editable;
import android.text.TextUtils;
import android.text.TextWatcher;
import android.view.KeyEvent;
import android.view.MotionEvent;
import android.view.View;
import android.view.inputmethod.EditorInfo;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.appcompat.app.AppCompatActivity;
import androidx.appcompat.widget.AppCompatEditText;
import androidx.appcompat.widget.AppCompatTextView;
import androidx.lifecycle.ViewModel;
import androidx.lifecycle.ViewModelProvider;
import androidx.lifecycle.ViewModelProviders;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;
import androidx.swiperefreshlayout.widget.SwipeRefreshLayout;
import com.ziploan.dsaapp.MyApplication;
import com.ziploan.dsaapp.R;
import com.ziploan.dsaapp.base.BaseRepository;
import com.ziploan.dsaapp.base.BindingFragment;
import com.ziploan.dsaapp.databinding.EditApplicationLayoutBinding;
import com.ziploan.dsaapp.utils.KeyboardUtils;
import com.ziploan.dsaapp.viewmodel.edit_app.EditApplicationViewModel;

public class EditApplicationFragment extends BindingFragment<EditApplicationLayoutBinding,EditApplicationViewModel,BaseRepository>  {

    private AppCompatEditText editText;
    private AppCompatTextView mNoResulFound;

    public static EditApplicationFragment newInstance() {
        EditApplicationFragment fragment = new EditApplicationFragment();
        Bundle args = new Bundle();
        fragment.setArguments(args);
        return fragment;
    }

    @Override
    public EditApplicationViewModel getViewModel(BaseRepository repository) {
        return  ViewModelProviders.of(this, new ViewModelProvider.Factory() {
            @NonNull
            @Override
            public <T extends ViewModel> T create(@NonNull Class<T> modelClass) {
                return (T)new EditApplicationViewModel();
            }
        }).get(EditApplicationViewModel.class);
    }

    @Override
    public int getLayoutId() {
        return R.layout.edit_application_layout;
    }

    @Override
    public void onResume() {
        super.onResume();
        ((AppCompatActivity)getActivity()).getSupportActionBar().setTitle(getString(R.string.edit_application));
        if(mainActivity.get().getSupportActionBar() != null) {
            mainActivity.get().getSupportActionBar().show();
            mainActivity.get().enableViews(true);
        }
        if(editText != null)
            editText.addTextChangedListener(textWatcher);
    }



    @Override
    public void onPause() {
        super.onPause();
        KeyboardUtils.hideKeyboard((AppCompatActivity) getActivity());
    }

    @Override
    public void onDestroyView() {
        super.onDestroyView();
        if(editText != null){
            editText.removeTextChangedListener(textWatcher);
        }
        editText.setText("");
        if(getViewModel() != null)
            getViewModel().resetText();
    }

    @Override
    public BaseRepository getRepository() {
        return null;
    }

    @Override
    public void onViewCreated(@NonNull View view, @Nullable Bundle savedInstanceState) {
        super.onViewCreated(view, savedInstanceState);
        editText = view.findViewById(R.id.search);
        RecyclerView recyclerView = view.findViewById(R.id.edit_recycler);
        recyclerView.setHasFixedSize(true);
        recyclerView.setLayoutManager(new LinearLayoutManager(getContext()));
        if(getViewModel() != null) {
            getViewModel().setLoanRecycler(recyclerView);
            getViewModel().setSwipObject(getBinding().swipeLayout);

        }
        MyApplication.LOAN_REQ_ID = "";

//        editText.addTextChangedListener(new TextWatcher() {
//            @Override
//            public void beforeTextChanged(CharSequence charSequence, int i, int i1, int i2) {
//
//            }
//
//            @Override
//            public void onTextChanged(CharSequence charSequence, int i, int i1, int i2) {
//                if(!TextUtils.isEmpty(charSequence)){
//                    getViewModel().setSearchText(charSequence.toString());
//                }
//            }
//
//            @Override
//            public void afterTextChanged(Editable editable) {
//
//            }
//        });
        editText.setOnEditorActionListener(new TextView.OnEditorActionListener() {
            @Override
            public boolean onEditorAction(TextView v, int actionId, KeyEvent event) {
                if (actionId == EditorInfo.IME_ACTION_SEARCH) {
                    if(getViewModel() != null)
                        getViewModel().setSearchText(v.getText().toString(), getContext(),false);
                    return true;
                }
                return false;
            }
        });


        if(getViewModel() != null)
            getViewModel().setSearchText("", getContext(),false);

        editText.addTextChangedListener(textWatcher);

        editText.setOnTouchListener(new View.OnTouchListener() {
            @Override
            public boolean onTouch(View v, MotionEvent event) {
                final int DRAWABLE_LEFT = 0;
                final int DRAWABLE_TOP = 1;
                final int DRAWABLE_RIGHT = 2;
                final int DRAWABLE_BOTTOM = 3;

                if(event.getAction() == MotionEvent.ACTION_UP) {
                    if(event.getRawX() >= (editText.getRight() - editText.getCompoundDrawables()[DRAWABLE_RIGHT].getBounds().width())) {
                        if(getViewModel() != null && !TextUtils.isEmpty(editText.getText().toString()))
                            getViewModel().setSearchText(editText.getText().toString(), getActivity(),false);
                        return true;
                    }
                }
                return false;
            }
        });
        getArguments().clear();
    }

    TextWatcher textWatcher = new TextWatcher() {
        boolean isOnTextChanged = false;
        int i1 = 0;
        @Override
        public void beforeTextChanged(CharSequence charSequence, int i, int i1, int i2) {

        }

        @Override
        public void onTextChanged(CharSequence charSequence, int i, int i1, int i2) {
            isOnTextChanged = true;
            this.i1 = i1;
        }

        @Override
        public void afterTextChanged(Editable editable) {
            if (isOnTextChanged) {
                isOnTextChanged = false;
               if(editable.toString().length() == 0 && i1 > 0){
                   if(getViewModel() != null)
                       getViewModel().resetSearch();
               }
            }
        }
    };


}
