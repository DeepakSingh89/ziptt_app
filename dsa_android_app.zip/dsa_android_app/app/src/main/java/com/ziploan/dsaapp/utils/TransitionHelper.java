package com.ziploan.dsaapp.utils;

import android.annotation.TargetApi;
import android.os.Build;

import androidx.fragment.app.Fragment;
import androidx.transition.AutoTransition;
import androidx.transition.Fade;
import androidx.transition.Slide;
import androidx.transition.TransitionSet;


public class TransitionHelper extends TransitionSet {

    @TargetApi(Build.VERSION_CODES.LOLLIPOP)
    public void initTransitionN(Fragment fragment) {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.LOLLIPOP) {
            fragment.setSharedElementReturnTransition(new Transition());
            fragment.setExitTransition(new Fade());
            fragment.setSharedElementEnterTransition(new Transition());
            fragment.setEnterTransition(new Slide());
        }
    }

    private class Transition extends TransitionSet {
        private Transition() {
            setOrdering(ORDERING_TOGETHER);
            addTransition(new AutoTransition());
        }
    }
}
