
package com.ziploan.dsaapp.model.response.document;

import java.util.List;
import com.google.gson.annotations.Expose;
import com.google.gson.annotations.SerializedName;

public class Response {

    @SerializedName("kyc_documents")
    @Expose
    private KycDocuments kycDocuments;
    @SerializedName("itr_data")
    @Expose
    private List<ItrDatum> itrData = null;
    @SerializedName("scanned")
    @Expose
    private Scanned scanned;

    public KycDocuments getKycDocuments() {
        return kycDocuments;
    }

    public void setKycDocuments(KycDocuments kycDocuments) {
        this.kycDocuments = kycDocuments;
    }

    public List<ItrDatum> getItrData() {
        return itrData;
    }

    public void setItrData(List<ItrDatum> itrData) {
        this.itrData = itrData;
    }

    public Scanned getScanned() {
        return scanned;
    }

    public void setScanned(Scanned scanned) {
        this.scanned = scanned;
    }

}
