
package com.ziploan.dsaapp.model.request.document;

import java.util.List;
import com.google.gson.annotations.Expose;
import com.google.gson.annotations.SerializedName;

public class Secondary {

    @SerializedName("account_type")
    @Expose
    private String accountType;
    @SerializedName("bank_name")
    @Expose
    private String bankName = null;
    @SerializedName("password")
    @Expose
    private String password;


    @SerializedName("start_date")
    @Expose
    private String startDate;

    public String getStartDate() {
        return startDate;
    }

    public void setStartDate(String startDate) {
        this.startDate = startDate;
    }

    public String getEndDate() {
        return endDate;
    }

    public void setEndDate(String endDate) {
        this.endDate = endDate;
    }

    @SerializedName("end_date")
    @Expose
    private String endDate;


    public String getAccountType() {
        return accountType;
    }

    public void setAccountType(String accountType) {
        this.accountType = accountType;
    }

    public String getBankName() {
        return bankName;
    }

    public void setBankName(String bankName) {
        this.bankName = bankName;
    }

    public String getPassword() {
        return password;
    }

    public void setPassword(String password) {
        this.password = password;
    }

}
