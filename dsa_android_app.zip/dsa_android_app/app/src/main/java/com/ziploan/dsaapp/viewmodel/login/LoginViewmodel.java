package com.ziploan.dsaapp.viewmodel.login;

import android.text.TextUtils;
import android.view.View;

import androidx.databinding.ObservableBoolean;
import androidx.databinding.ObservableField;

import com.ziploan.dsaapp.BuildConfig;
import com.ziploan.dsaapp.R;
import com.ziploan.dsaapp.base.BaseViewModel;
import com.ziploan.dsaapp.base.extras.network.APIExecutor;
import com.ziploan.dsaapp.base.extras.network.ApiResponse;
import com.ziploan.dsaapp.fragments.home.HomeFragment;
import com.ziploan.dsaapp.fragments.login.LoginFragment;
import com.ziploan.dsaapp.model.request.LoginRequest;
import com.ziploan.dsaapp.model.response.LoginResponse;
import com.ziploan.dsaapp.utils.CommonUtils;
import com.ziploan.dsaapp.utils.NavController;
import com.ziploan.dsaapp.utils.PreferencesManager;
import com.ziploan.dsaapp.utils.ZiploanDSAUtil;
import retrofit2.Call;
import retrofit2.Callback;
import retrofit2.Response;

public class LoginViewmodel extends BaseViewModel {
    public ObservableField<String> Email = new ObservableField<>();
    public ObservableField<String> Password = new ObservableField<>();
    public ObservableBoolean EmailInvalid = new ObservableBoolean(true);
    public ObservableBoolean PasswordInvalid = new ObservableBoolean(true);
    public ObservableField<String> PasswordErrorText = new ObservableField<>();
    public ObservableField<String> EmailErrorText = new ObservableField<>();
    private LoginFragment.IDoneLogin iDoneLogin;

    public void onClick(View view, LoginFragment loginFragment) {
        switch (view.getId()) {
            case R.id.login:
                if (!TextUtils.isEmpty(Email.get())) {
                    if (CommonUtils.isEmailValid(Email.get()) || Email.get().equalsIgnoreCase("others")) {
                        EmailInvalid.set(true);
                        if (!TextUtils.isEmpty(Password.get())) {
                            PasswordInvalid.set(true);
                            loginFragment.hideKeyBoard();
                            showLoading(loginFragment.getContext());
                            doLogin(loginFragment);
                        } else {
                            PasswordInvalid.set(false);
                            PasswordErrorText.set(loginFragment.getContext().getString(R.string.empty_password));
                        }
                    } else {
                        EmailInvalid.set(false);
                        EmailErrorText.set(loginFragment.getContext().getString(R.string.invalid_email));
                    }
                } else {
                    EmailInvalid.set(false);
                    EmailErrorText.set(loginFragment.getContext().getString(R.string.invalid_email));
                }
                break;
        }
    }

    private void doLogin(LoginFragment loginFragment){
        LoginRequest loginRequest = new LoginRequest();
        loginRequest.setEmail(Email.get());
        loginRequest.setPassword(Password.get());
        Call<LoginResponse> login;

        if (BuildConfig.BUILD_TYPE.equalsIgnoreCase("prep") || BuildConfig.BUILD_TYPE.equalsIgnoreCase("qa")){
            login = APIExecutor.getAPIService_LS().login(loginRequest);
        }else{
            login = APIExecutor.getAPIService().login(loginRequest);
        }

        login.enqueue(new Callback<LoginResponse>() {
            @Override
            public void onResponse(Call<LoginResponse> call, Response<LoginResponse> response) {
                if(response.isSuccessful()
                        && response.body() != null
                        && response.body().getAccessToken() != null){
                    PreferencesManager.getInstance().setUserLoggedIn(true);
                    PreferencesManager.getInstance().setString(PreferencesManager.AUTH_ID,response.body().getPartnerId());
                    PreferencesManager.getInstance().setString(PreferencesManager.AUTH_TOKEN,response.body().getAccessToken());
                    PreferencesManager.getInstance().setString(PreferencesManager.EXPIRE_TIME,response.body().getTokenExpirationTime());
                    PreferencesManager.getInstance().setString(PreferencesManager.PARTNER_ACCOUNT_NAME,response.body().getPartnerAccountName());
                    ZiploanDSAUtil.getInstance(loginFragment.getContext()).setExpirationDate(response.body().getTokenExpirationTime());
                    NavController.getInstance().addFragment(HomeFragment.newInstance(),false);
                    hideLoading();
                    if(iDoneLogin != null)
                        iDoneLogin.doneLogin(response.body());
                } else {
                    showToast(loginFragment.getContext(),loginFragment.getString(R.string.login_error));
                    hideLoading();
                }
            }

            @Override
            public void onFailure(Call<LoginResponse> call, Throwable t) {
                hideLoading();
                showToast(loginFragment.getContext(),loginFragment.getString(R.string.something_went_wrong));
            }
        });
    }

    public void setLoginDone(LoginFragment.IDoneLogin iDoneLogin){
        this.iDoneLogin = iDoneLogin;
    }
}
