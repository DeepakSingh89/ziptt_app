package com.ziploan.dsaapp.fragments.weview;

import android.os.Bundle;
import android.view.View;
import android.webkit.WebResourceResponse;
import android.webkit.WebSettings;
import android.webkit.WebView;
import android.webkit.WebViewClient;

import org.apache.http.Header;
import org.apache.http.HttpResponse;
import org.apache.http.client.ClientProtocolException;
import org.apache.http.client.methods.HttpGet;
import org.apache.http.impl.client.DefaultHttpClient;

import java.io.IOException;
import java.io.InputStream;
import java.util.HashMap;
import java.util.Map;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.appcompat.app.AppCompatActivity;
import com.ziploan.dsaapp.R;
import com.ziploan.dsaapp.base.BaseRepository;
import com.ziploan.dsaapp.base.BaseViewModel;
import com.ziploan.dsaapp.base.BindingFragment;
import com.ziploan.dsaapp.databinding.WebviewLayoutBinding;
import com.ziploan.dsaapp.utils.Constant;
import com.ziploan.dsaapp.utils.PreferencesManager;
import okhttp3.OkHttpClient;
import okhttp3.Request;
import okhttp3.Response;
import okhttp3.internal.http.HttpHeaders;

public class ZipWebviewFragment extends BindingFragment<WebviewLayoutBinding,BaseViewModel,BaseRepository> {

    public static ZipWebviewFragment newInstance(String url) {
        ZipWebviewFragment fragment = new ZipWebviewFragment();
        Bundle args = new Bundle();
        args.putString("url",url);
        fragment.setArguments(args);
        return fragment;
    }
    @Override
    public int getLayoutId() {
        return R.layout.webview_layout;
    }
    @Override
    public void onResume() {
        super.onResume();
        if(mainActivity.get().getSupportActionBar() != null) {
            mainActivity.get().getSupportActionBar().hide();
        }
    }

    @Override
    public BaseViewModel getViewModel(BaseRepository repository) {
        return null;
    }

    @Override
    public BaseRepository getRepository() {
        return null;
    }

    @Override
    public void onViewCreated(@NonNull View view, @Nullable Bundle savedInstanceState) {
        super.onViewCreated(view, savedInstanceState);
        WebView myWebView = view.findViewById(R.id.webView);
        WebSettings webSettings = myWebView.getSettings();
        webSettings.setJavaScriptEnabled(true);
        myWebView.loadUrl(getArguments().getString("url"));
    }

    private WebResourceResponse getNewResponse(String url) {

        try {
            OkHttpClient httpClient = new OkHttpClient();

            Request request = new Request.Builder()
                    .url(url.trim())
                    .addHeader(Constant.ACCESS_TOKEN, PreferencesManager.getInstance().getString(PreferencesManager.AUTH_TOKEN))
                    .addHeader(Constant.ACCESS_ID, PreferencesManager.getInstance().getString(PreferencesManager.AUTH_ID))
                    .build();

            Response response = httpClient.newCall(request).execute();

            return new WebResourceResponse(
                    null,
                    response.header("content-encoding", "utf-8"),
                    response.body().byteStream()
            );

        } catch (Exception e) {
            return null;
        }

    }
}
