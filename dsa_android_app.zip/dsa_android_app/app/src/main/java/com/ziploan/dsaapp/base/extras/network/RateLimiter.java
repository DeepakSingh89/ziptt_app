package com.ziploan.dsaapp.base.extras.network;

import android.os.SystemClock;
import android.util.ArrayMap;

import java.util.concurrent.TimeUnit;

public class RateLimiter<KEY> {
    private ArrayMap<KEY, Long> timestamps = new ArrayMap<>();
    private final long timeout;

    public RateLimiter(long timeout, TimeUnit timeUnit) {
        this.timeout = timeUnit.toMillis(timeout);
    }

    public void setTime(KEY key, long val){
        timestamps.put(key,val);
    }

    public synchronized boolean shouldFetch(long key) {
        Long lastFetched = key;
        long now = now();
        if (now - lastFetched > timeout) {
            return true;
        }
        return false;
    }

    private long now() {
        return SystemClock.uptimeMillis();
    }

    public synchronized void reset(KEY key) {
        timestamps.remove(key);
    }
}
