package com.ziploan.dsaapp.base;

import android.app.ProgressDialog;
import android.content.Context;
import android.content.Intent;
import android.content.pm.PackageManager;
import android.location.Address;
import android.location.Location;
import android.os.Bundle;
import android.os.Handler;
import android.os.ResultReceiver;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;

import com.google.android.material.snackbar.Snackbar;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.fragment.app.Fragment;
import com.ziploan.dsaapp.base.extras.network.Status;
import com.ziploan.dsaapp.utils.CommonUtils;
import com.ziploan.dsaapp.utils.Constant;
import com.ziploan.dsaapp.utils.LocationUpdates;
import com.ziploan.dsaapp.utils.permissons.Func2;
import com.ziploan.dsaapp.utils.permissons.PermissionConstant;
import com.ziploan.dsaapp.utils.permissons.PermissionUtils;
import com.ziploan.dsaapp.workers.FetchAddressIntentService;

public abstract class BaseFragment extends Fragment implements LocationUpdates.LocationUpdatesCallback {

    private Location mLastLocation;
    private PermissionUtils.PermissionRequestObject permissionRequestObject;
    private ProgressDialog mProgressDialog;
    private String mAddressOutput;
    private Snackbar errorBar;


    public abstract void refreshData();


    public void loading(boolean isLoading) {
        if(isLoading)
            showLoading(getContext());
        else
            hideLoading();
    }

    @Nullable
    @Override
    public View onCreateView(@NonNull LayoutInflater inflater, @Nullable ViewGroup container, @Nullable Bundle savedInstanceState) {
        return super.onCreateView(inflater, container, savedInstanceState);
    }

    public void showError(Status status, final String message) {
        loading(status == Status.LOADING);
        switch (status) {
            case SUCCESS:
                if (errorBar != null) {
                    errorBar.dismiss();
                }
                break;
            case LOADING:
                if (errorBar != null) {
                    errorBar.dismiss();
                }
                break;
            case ERROR:
                if (getErrorBar(message) != null) {
                    errorBar.show();
                }
                break;
        }
    }

    private Snackbar getErrorBar(String message) {
        if (errorBar == null && getView() != null) {
            errorBar = Snackbar.make(getView(), message, Snackbar.LENGTH_LONG);
            errorBar.setAction("Retry", new View.OnClickListener() {
                @Override
                public void onClick(View v) {
                    errorBar = null;
                    refreshData();
                }
            });
            return errorBar;
        }
        else if (errorBar != null) {
            errorBar.setText(message);
            return errorBar;
        }
//        else if (!((TextView) errorBar.getView().findViewById(android.support.design.R.id.snackbar_text)).getText().toString().equals(message)) {
//            return errorBar;
//        }
        else {
            return null;
        }
    }

    // Start Permission Utils
    protected boolean checkRequest(int requestCode) {
        boolean checked = false;
        String[] permissions = PermissionConstant.getAuthorityByCode(requestCode);
        if (!checkPermission(permissions)) {
            requestPermission(requestCode, permissions);
            checked = true;
        }
        return checked;
    }

    protected boolean checkPermission(String... permission){
        return PermissionUtils.with(this).has(permission);
    }

    protected void requestPermission(int requestCode, String... permission) {
        permissionRequestObject =
                PermissionUtils.with(this).request(permission);
        permissionRequestObject
                .onResult(new Func2() {
                    @Override
                    protected void call(int requestCode, String[] permissions, int[] grantResults) {
                        onPermission(requestCode, permissions,grantResults);
                    }
                }).ask(requestCode);
    }

    protected void requestSinglePermission(int requestCode, String permission) {
        permissionRequestObject =
                PermissionUtils.with(this).request(permission);
        permissionRequestObject
                .onResult(new Func2() {
                    @Override
                    protected void call(int requestCode, String[] permissions, int[] grantResults) {
                        onPermission(requestCode, permissions,grantResults);
                    }
                }).ask(requestCode);
    }

    protected void onPermission(int permissionRequest,String[] permissions, int[] grantResults){
        if(grantResults != null
                && permissionRequest == (PermissionConstant.LOCATION_CODE)
                && grantResults[0] == PackageManager.PERMISSION_GRANTED){

        }
    }

    @Override
    public void onRequestPermissionsResult(int requestCode, @NonNull String[] permissions, @NonNull int[] grantResults) {
        if(permissionRequestObject != null)
            permissionRequestObject.onRequestPermissionsResult(requestCode,permissions,grantResults);
        super.onRequestPermissionsResult(requestCode, permissions, grantResults);
    }
    // End Permission Utils

    public void hideLoading() {
        if (mProgressDialog != null && mProgressDialog.isShowing()) {
            mProgressDialog.cancel();
        }
    }

    public void showLoading(Context context) {
        hideLoading();
        mProgressDialog = CommonUtils.showLoadingDialog(context);
    }

    protected void fetchLocation(){
        new LocationUpdates
                .LocationBuilder()
                .setContext(getContext())
                .setLocationUpdatesCallback(this)
                .build()
                .getLastKnownLocation();
    }

    @Override
    public void onLocationUpdate(Location location) {
        this.mLastLocation = location;
        if(mLastLocation != null) {
            startIntentService();
            getLatlong(location);
        }
    }

    protected void getLatlong(Location location){

    }

    private void startIntentService() {
        Intent intent = new Intent(getContext(), FetchAddressIntentService.class);
        intent.putExtra(Constant.RECEIVER, new AddressResultReceiver(new Handler()));
        intent.putExtra(Constant.LOCATION_DATA_EXTRA, mLastLocation);
        getContext().startService(intent);
    }

    class AddressResultReceiver extends ResultReceiver {
        public AddressResultReceiver(Handler handler) {
            super(handler);
        }

        @Override
        protected void onReceiveResult(int resultCode, Bundle resultData) {

            if (resultData == null) {
                return;
            }

            mAddressOutput = resultData.getString(Constant.RESULT_DATA_KEY);
            Address address = resultData.getParcelable(Constant.ADDRESS_INFO);
            if (mAddressOutput == null) {
                mAddressOutput = "";
            } else {
                if (address != null)
                    getFullAddress(mAddressOutput, address, mLastLocation);
            }
        }
    }

    protected void getFullAddress(String mAddressOutput, Address address, Location location) {

    }
}
