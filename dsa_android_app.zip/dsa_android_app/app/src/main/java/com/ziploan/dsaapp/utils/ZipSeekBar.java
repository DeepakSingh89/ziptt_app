package com.ziploan.dsaapp.utils;


import android.content.Context;
import android.graphics.drawable.Drawable;

import androidx.appcompat.widget.AppCompatSeekBar;

public class ZipSeekBar extends AppCompatSeekBar {
    public ZipSeekBar(Context context) {
        super(context);
    }

    @Override
    public Drawable getThumb() {
        return super.getThumb();
    }

}
