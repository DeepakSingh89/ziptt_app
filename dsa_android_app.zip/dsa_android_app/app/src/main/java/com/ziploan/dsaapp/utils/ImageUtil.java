package com.ziploan.dsaapp.utils;

import android.widget.ImageView;

import com.bumptech.glide.Glide;
import com.bumptech.glide.load.resource.drawable.DrawableTransitionOptions;
import com.bumptech.glide.request.RequestOptions;

public class ImageUtil {

    public static void loadImage(String url, ImageView view, RequestOptions requestOptions, boolean iscircle){
        if(iscircle){
            requestOptions.circleCrop();
        }
        Glide.with(view.getContext())
                .load(url)
                .apply(requestOptions)
                .into(view);
    }

    public static void loadImage(String url, ImageView view){
        Glide.with(view.getContext())
                .load(url)
                .transition(DrawableTransitionOptions.withCrossFade())
                .into(view);
    }


}
