package com.ziploan.dsaapp.utils.permissons;

import android.Manifest;

import java.util.HashMap;
import java.util.Iterator;
import java.util.Map;

public class PermissionConstant {

    public static final String WRITE_EXTERNAL_STORAGE = Manifest.permission.WRITE_EXTERNAL_STORAGE;
    public static final String WRITE_CONTACTS = Manifest.permission.WRITE_CONTACTS;
    public static final String CAMERA_PERMISSION = Manifest.permission.CAMERA;
    public static final String ACCESS_FINE_LOCATION = Manifest.permission.ACCESS_FINE_LOCATION;
    public static final String ACCESS_COARSE_LOCATION = Manifest.permission.ACCESS_COARSE_LOCATION;
    public static final String READ_EXTERNAL_STORAGE = Manifest.permission.READ_EXTERNAL_STORAGE;


    public static final String READ_PHONE_STATE_PERMISSION = Manifest.permission.READ_PHONE_STATE;
    public static final String ACCESS_NETWORK_STATE = Manifest.permission.ACCESS_NETWORK_STATE;
    public static final String READ_CALENDAR = Manifest.permission.READ_CALENDAR;
    public static final String READ_CONTACTS = Manifest.permission.READ_CONTACTS;
    public static final String BODY_SENSORS = Manifest.permission.BODY_SENSORS;
    public static final String VIBRATE = Manifest.permission.READ_EXTERNAL_STORAGE;
    public static final String WAKE_LOCK = Manifest.permission.WAKE_LOCK;
    public static final String CALL_PHONE = Manifest.permission.CALL_PHONE;

    public static final int CAMERA = 1001;
    public static final int STORATE_WRITE = 1002;
    public static final int LOCATION_CODE = 1003;
    public static final int READ_PHONE_STATE = 1004;
    public static final int CALENDER = 1005;
    public static final int CONTACTS = 1006;
    public static final int REST = 1007;

    private static Map<Integer,String[]> authoritys = new HashMap<>();

    static {
        authoritys.put(CAMERA,new String[]{CAMERA_PERMISSION});
        authoritys.put(LOCATION_CODE,
                new String[]{ACCESS_COARSE_LOCATION,ACCESS_FINE_LOCATION});
        authoritys.put(STORATE_WRITE,
                new String[]{CAMERA_PERMISSION,READ_EXTERNAL_STORAGE, WRITE_EXTERNAL_STORAGE});
        authoritys.put(READ_PHONE_STATE,
                new String[]{READ_PHONE_STATE_PERMISSION,ACCESS_NETWORK_STATE});
        authoritys.put(CALENDER,
                new String[]{READ_CALENDAR,WRITE_CONTACTS});
        authoritys.put(CONTACTS,
                new String[]{READ_CONTACTS,WRITE_CONTACTS});
        authoritys.put(REST,
                new String[]{BODY_SENSORS,VIBRATE,WAKE_LOCK});
    }

    public static String[] getAuthorityByCode(int requstCode) {
        Iterator iterator = authoritys.entrySet().iterator();
        while (iterator.hasNext()) {
            Map.Entry entry = (Map.Entry) iterator.next();
            Integer key = (Integer) entry.getKey();
            String[] val = (String[])entry.getValue();
            if(requstCode == key) {
                return val;
            }
        }

        return null;
    }

}
