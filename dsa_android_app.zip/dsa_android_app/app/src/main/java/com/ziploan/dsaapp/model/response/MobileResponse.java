package com.ziploan.dsaapp.model.response;

import com.google.gson.annotations.Expose;
import com.google.gson.annotations.SerializedName;

public class MobileResponse {
    @SerializedName("loan_request_id")
    @Expose
    private String loanRequestId;

    public String getLoanRequestId() {
        return loanRequestId;
    }

    public void setLoanRequestId(String loanRequestId) {
        this.loanRequestId = loanRequestId;
    }
}
