package com.ziploan.dsaapp.base.extras.network;

import android.app.Dialog;
import android.app.ProgressDialog;
import android.content.Context;
import android.graphics.Color;
import android.graphics.drawable.ColorDrawable;
import android.os.Bundle;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.view.Window;
import android.widget.Toast;

import com.google.android.material.snackbar.Snackbar;

import java.lang.ref.WeakReference;
import java.lang.reflect.InvocationTargetException;
import java.lang.reflect.Method;
import java.lang.reflect.ParameterizedType;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.databinding.ViewDataBinding;
import androidx.fragment.app.DialogFragment;
import com.ziploan.dsaapp.BR;
import com.ziploan.dsaapp.MainActivity;
import com.ziploan.dsaapp.base.BaseRepository;
import com.ziploan.dsaapp.base.BaseViewModel;
import com.ziploan.dsaapp.utils.CommonUtils;

public abstract class BindingDialogueFragment<BindingT extends ViewDataBinding,T extends BaseViewModel, R extends BaseRepository> extends DialogFragment {
    private BindingT mBinding = null;
    private T mViewModel;
    private R mRepository;
    private ProgressDialog mProgressDialog;
    private Snackbar errorBar;
    protected WeakReference<MainActivity> mainActivity;

    public abstract T getViewModel(R repository);
    public abstract R getRepository();

    @Nullable
    @Override
    public final View onCreateView(final LayoutInflater inflater, @Nullable final ViewGroup container, @Nullable final Bundle savedInstanceState) {
        try {
            final Method inflateMethod = ((Class<BindingT>) ((ParameterizedType) getClass().getGenericSuperclass()).getActualTypeArguments()[0])
                    .getMethod("inflate", LayoutInflater.class, ViewGroup.class, boolean.class);
            //noinspection unchecked
            mBinding = (BindingT) inflateMethod.invoke(null, inflater, container, false);
            onBindingCompleted(mBinding.getRoot());
            return mBinding.getRoot();
        } catch (IllegalAccessException | NoSuchMethodException | InvocationTargetException ex) {
            Log.e("iliga",ex.getMessage());
        }
        return null;
    }

    @Override
    public void onViewCreated(@NonNull View view, @Nullable Bundle savedInstanceState) {
        super.onViewCreated(view, savedInstanceState);
        mRepository = getRepository();
        mViewModel = getViewModel(mRepository);
        getCurrentViewModel(mViewModel);
        mBinding.setVariable(BR.viewmodel, mViewModel);
        mBinding.setVariable(BR.fragment, this);
        mBinding.executePendingBindings();
    }

    @NonNull
    @Override
    public Dialog onCreateDialog(@Nullable Bundle savedInstanceState) {
        Dialog dialog = super.onCreateDialog(savedInstanceState);
        dialog.getWindow().requestFeature(Window.FEATURE_NO_TITLE);
        if (dialog.getWindow() != null) {
            dialog.getWindow().setBackgroundDrawable(new ColorDrawable(Color.TRANSPARENT));
        }
        dialog.setCanceledOnTouchOutside(false);
        return dialog;
    }

    protected void onBindingCompleted(View view){

    }

    protected void getCurrentViewModel(T viewmodel){

    }

    protected T getViewModel(){
        return mViewModel;
    }

    @Override
    public void onDestroyView() {
        mBinding = null;
        mViewModel = null;
        hideLoading();
        super.onDestroyView();
    }

    public void hideLoading() {
        if (mProgressDialog != null && mProgressDialog.isShowing()) {
            mProgressDialog.cancel();
        }
    }

    public void showLoading(Context context) {
        hideLoading();
        mProgressDialog = CommonUtils.showLoadingDialog(context);
    }

    protected void loading(boolean isLoading){
        if(isLoading)
            showLoading(getContext());
        else
            hideLoading();
    }

    protected void refreshData() {
        getViewModel().refresh();
    }

    public void showError(Status status, final String message) {
        loading(status == Status.LOADING);
        switch (status) {
            case SUCCESS:
                if (errorBar != null) {
                    errorBar.dismiss();
                }
                break;
            case LOADING:
                if (errorBar != null) {
                    errorBar.dismiss();
                }
                break;
            case ERROR:
                if (getErrorBar(message) != null) {
                    // errorBar.show();
                }
                break;
        }
    }

    private Snackbar getErrorBar(String message) {
        if (errorBar == null && getView() != null) {
            errorBar = Snackbar.make(getView(), message, Snackbar.LENGTH_INDEFINITE);
            errorBar.setAction("Retry", new View.OnClickListener() {
                @Override
                public void onClick(View v) {
                    errorBar = null;
                    refreshData();
                }
            });
            return errorBar;
        } else {
            return null;
        }
    }
    @Override
    public void onAttach(Context context) {
        mainActivity = new WeakReference<>((MainActivity)context);
        super.onAttach(context);

    }

    @Override
    public void onDetach() {
        super.onDetach();
        mainActivity = null;
    }

    public void showToast(String message){
        Toast.makeText(getContext(),message,Toast.LENGTH_SHORT).show();
    }

}
