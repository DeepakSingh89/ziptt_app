package com.ziploan.dsaapp.base.extras.network;

import android.text.TextUtils;

import androidx.annotation.MainThread;
import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.annotation.WorkerThread;
import androidx.lifecycle.LiveData;
import androidx.lifecycle.MediatorLiveData;
import androidx.lifecycle.Observer;

// ResultType: Type for the Resource data
// RequestType: Type for the API response
public abstract class NetworkBoundResource<ResultType, RequestType> {

    private static final String NETWORK_FAIL_MESSAGE  = "Network not available";
    private final AppExecutors appExecutors;

    private final MediatorLiveData<Resource<ResultType>> result = new MediatorLiveData<>();

    @MainThread
    public NetworkBoundResource(AppExecutors appExecutors) {
        this.appExecutors = appExecutors;
        if (fromForeGround()) {
            result.setValue(Resource.<ResultType>loading(null));
            final LiveData<ResultType> dbSource = loadFromDb();
            result.addSource(dbSource, new Observer<ResultType>() {
                @Override
                public void onChanged(@Nullable ResultType data) {
                    result.removeSource(dbSource);
                    if (NetworkBoundResource.this.shouldFetch(data)) {
                        NetworkBoundResource.this.fetchFromNetwork(dbSource);
                    } else {
                        result.addSource(dbSource, new Observer<ResultType>() {
                            @Override
                            public void onChanged(@Nullable ResultType newData) {
                                NetworkBoundResource.this.setValue(Resource.success(newData));
                            }
                        });
                    }
                }
            });
        } else {
            if (isNetworkConnected())
                NetworkBoundResource.this.fetchForcedFromNetwork();
            else
                NetworkBoundResource.this.setValue(Resource.<ResultType>error(NETWORK_FAIL_MESSAGE, null));
        }
    }

    @MainThread
    private void setValue(Resource<ResultType> newValue) {
        if (!areEqual(result.getValue(), newValue) && fromForeGround()) {
            result.setValue(newValue);
        }
    }

    private boolean areEqual(Object a, Object b) {
        return (a == b) || (a != null && a.equals(b));
    }

    public void fetchFromNetwork(final LiveData<ResultType> dbSource) {
        final LiveData<ApiResponse<RequestType>> apiResponse = createCall();
        // we re-attach dbSource as a new source, it will dispatch its latest value quickly
        result.addSource(dbSource, new Observer<ResultType>() {
            @Override
            public void onChanged(@Nullable ResultType newData) {
                NetworkBoundResource.this.setValue(Resource.loading(newData));
            }
        });
        result.addSource(apiResponse, new Observer<ApiResponse<RequestType>>() {
            @Override
            public void onChanged(@Nullable final ApiResponse<RequestType> response) {
                result.removeSource(apiResponse);
                result.removeSource(dbSource);
                //noinspection ConstantConditions
                if (response.isSuccessful()) {
                    appExecutors.diskIO().execute(new Runnable() {
                        @Override
                        public void run() {
                            //if(NetworkBoundResource.this.shouldResetDB())
                            NetworkBoundResource.this.resetDB();
                            if (!TextUtils.isEmpty(response.authToken))
                                getAuthHeaders(response.authToken);
                            NetworkBoundResource.this.saveCallResult(NetworkBoundResource.this.processResponse(response));
                            appExecutors.mainThread().execute(new Runnable() {
                                @Override
                                public void run() {
                                    result.addSource(NetworkBoundResource.this.loadFromDb(), new Observer<ResultType>() {
                                        @Override
                                        public void onChanged(@Nullable ResultType newData) {
                                            NetworkBoundResource.this.setValue(Resource.success(newData));
                                        }
                                    });
                                }
                            });
                        }
                    });
                } else {
                    if (isNetworkConnected()){

                    }
                    NetworkBoundResource.this.onFetchFailed();
                    result.addSource(dbSource, new Observer<ResultType>() {
                        @Override
                        public void onChanged(@Nullable ResultType newData) {
                            NetworkBoundResource.this.setValue(Resource.error(response.errorMessage,
                                    newData));
                        }
                    });
                }
            }
        });
    }

    public void fetchForcedFromNetwork() {
        result.setValue(Resource.<ResultType>loading(null));
        final LiveData<ApiResponse<RequestType>> apiResponse = createCall();

        result.addSource(apiResponse, new Observer<ApiResponse<RequestType>>() {
            @Override
            public void onChanged(@Nullable final ApiResponse<RequestType> response) {
                result.removeSource(apiResponse);
                if (response != null && response.isSuccessful()) {
                    appExecutors.diskIO().execute(new Runnable() {
                        @Override
                        public void run() {
                            if(NetworkBoundResource.this.shouldResetDB())
                                NetworkBoundResource.this.resetDB();
                            if(!TextUtils.isEmpty(response.authToken))
                                getAuthHeaders(response.authToken);
                            NetworkBoundResource.this.saveCallResult(NetworkBoundResource.this.processResponse(response));
                            appExecutors.mainThread().execute(new Runnable() {
                                @Override
                                public void run() {
                                    // we specially request a new live data,
                                    // otherwise we will get immediately last cached value,
                                    // which may not be updated with latest results received from network.
                                    result.addSource(NetworkBoundResource.this.loadFromDb(), new Observer<ResultType>() {
                                        @Override
                                        public void onChanged(@Nullable ResultType newData) {
                                            NetworkBoundResource.this.setValue(Resource.success(newData));
                                        }
                                    });
                                }
                            });
                        }
                    });
                } else {
                    onFetchFailed();
                    result.addSource(apiResponse, new Observer<ApiResponse<RequestType>>() {
                        @Override
                        public void onChanged(@Nullable ApiResponse<RequestType> requestTypeApiResponse) {
                            Resource resource = Resource.error(response.errorMessage, requestTypeApiResponse);
                            NetworkBoundResource.this.setValue(resource);
                        }
                    });
                }
            }
        });
    }

    protected void onFetchFailed() {
    }

    public LiveData<Resource<ResultType>> asLiveData() {
        return result;
    }

    @WorkerThread
    protected RequestType processResponse(ApiResponse<RequestType> response) {
        return response.body;
    }

    @WorkerThread
    protected abstract void saveCallResult(@NonNull RequestType item);

    @MainThread
    protected abstract boolean shouldFetch(@Nullable ResultType data);

    @NonNull
    @MainThread
    protected abstract LiveData<ResultType> loadFromDb();

    @NonNull
    @MainThread
    protected abstract LiveData<ApiResponse<RequestType>> createCall();

    @NonNull
    @MainThread
    protected void resetDB(){

    }
    @NonNull
    protected void getAuthHeaders(String auth){

    }

    @MainThread
    protected boolean shouldResetDB(){
        return false;
    }

    protected boolean fromForeGround(){
        return true;
    }

    @MainThread
    protected abstract boolean isNetworkConnected();


}
