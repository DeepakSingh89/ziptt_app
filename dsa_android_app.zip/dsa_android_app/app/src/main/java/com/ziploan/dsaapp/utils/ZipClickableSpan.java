package com.ziploan.dsaapp.utils;

import android.content.Context;
import android.text.TextPaint;
import android.text.style.ClickableSpan;
import android.view.View;

import com.ziploan.dsaapp.R;

public class ZipClickableSpan extends ClickableSpan {// extend ClickableSpan

    String clicked;
    private Context context;

    public ZipClickableSpan(String string, Context context) {
        super();
        this.context = context;
        clicked = string;
    }

    public void onClick(View tv) {
    }

    public void updateDrawState(TextPaint ds) {// override updateDrawState
        ds.setUnderlineText(false); // set to false to remove underline
        ds.setColor(context.getResources().getColor(R.color.orange_ff6317));
    }

}
