
package com.ziploan.dsaapp.model.bank_list;

import android.text.TextUtils;

import com.google.gson.annotations.Expose;
import com.google.gson.annotations.SerializedName;

public class Response {

    @SerializedName("bank_display_name")
    @Expose
    private String bankDisplayName;
    @SerializedName("bank_name")
    @Expose
    private String bankName;

    public String getBankDisplayName() {
        return bankDisplayName;
    }

    public void setBankDisplayName(String bankDisplayName) {
        this.bankDisplayName = bankDisplayName;
    }

    public String getBankName() {
        return bankName;
    }

    public void setBankName(String bankName) {
        this.bankName = bankName;
    }

    @Override
    public String toString() {
        return bankDisplayName;
    }
}
