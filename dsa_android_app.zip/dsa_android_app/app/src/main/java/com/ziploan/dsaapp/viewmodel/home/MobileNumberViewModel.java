package com.ziploan.dsaapp.viewmodel.home;

import android.text.Editable;
import android.text.TextUtils;
import android.text.TextWatcher;
import android.view.View;
import android.widget.EditText;

import androidx.databinding.BindingAdapter;
import androidx.databinding.ObservableBoolean;
import androidx.databinding.ObservableField;

import com.ziploan.dsaapp.MyApplication;
import com.ziploan.dsaapp.R;
import com.ziploan.dsaapp.base.BaseViewModel;
import com.ziploan.dsaapp.base.extras.network.APIExecutor;
import com.ziploan.dsaapp.fragments.details.BusinessDetailsFragment;
import com.ziploan.dsaapp.fragments.details.DocumentUploadDetailsFragment;
import com.ziploan.dsaapp.fragments.details.PersonalDetailsFragment;
import com.ziploan.dsaapp.fragments.home.MobileNumberFramgnet;
import com.ziploan.dsaapp.model.request.StartApplicationRequest;
import com.ziploan.dsaapp.model.response.MobileBaseResponse;
import com.ziploan.dsaapp.utils.CommonUtils;
import com.ziploan.dsaapp.utils.Constant;
import com.ziploan.dsaapp.utils.NavController;

import retrofit2.Call;
import retrofit2.Callback;
import retrofit2.Response;

public class MobileNumberViewModel extends BaseViewModel {

    public ObservableBoolean Mobilevalid = new ObservableBoolean(true);
    public ObservableField<String> Mobile = new ObservableField<>();
    public ObservableField<String> MobileErrorText = new ObservableField<>();
    private TextWatcher textWatcher;

    public MobileNumberViewModel() {
        this.textWatcher = getTextWatcherIns();
    }


    private TextWatcher getTextWatcherIns() {
        return new TextWatcher() {
            @Override
            public void beforeTextChanged(CharSequence s, int start, int count, int after) {
                //do some thing
            }

            @Override
            public void onTextChanged(CharSequence s, int start, int before, int count) {

                if (!TextUtils.isEmpty(s.toString())) {
                    if (s.toString().length() == 10 && CommonUtils.validateSolePersonalPan(s.toString())) {
                        Mobilevalid.set(true);
                    }
                }
                }

                @Override
                public void afterTextChanged (Editable s){
                    //do some thing
                }
            }

            ;
        }


        public TextWatcher getTextWatcher () {
            return textWatcher;
        }

        public void setTextWatcher (TextWatcher textWatcher){
            this.textWatcher = textWatcher;
        }

        @BindingAdapter("textChangedListener")
        public static void bindTextWatcher (EditText editText, TextWatcher textWatcher){
            editText.addTextChangedListener(textWatcher);
        }

        public void onClick (View view, MobileNumberFramgnet mobileNumberFramgnet){
            switch (view.getId()) {
                case R.id.mobile_verify_btn:
                    if (!TextUtils.isEmpty(Mobile.get())) {
                        if (Mobile.get().length() == 10 && CommonUtils.validateSolePersonalPan(Mobile.get())) {
                            Mobilevalid.set(true);
                            mobileNumberFramgnet.hideKeyBoard();
                            showLoading(mobileNumberFramgnet.getContext());
                            doMobileVerification(mobileNumberFramgnet);
                        } else {
                            Mobilevalid.set(false);
                            MobileErrorText.set(mobileNumberFramgnet.getString(R.string.empty_pan));
                        }
                    } else {
                        Mobilevalid.set(false);
                        MobileErrorText.set(mobileNumberFramgnet.getString(R.string.empty_pan));
                    }
                    break;
            }
        }

        private void doMobileVerification (MobileNumberFramgnet mobileNumberFramgnet){
            StartApplicationRequest startApplicationRequest = new StartApplicationRequest();
            startApplicationRequest.setMobile(Mobile.get());
            Call<MobileBaseResponse> login = APIExecutor.getAPIService().start_application(startApplicationRequest);

            login.enqueue(new Callback<MobileBaseResponse>() {
                @Override
                public void onResponse(Call<MobileBaseResponse> call, Response<MobileBaseResponse> response) {
                    if (response.isSuccessful()
                            && response.body() != null) {
                        if (response.body().getStatus().equalsIgnoreCase(Constant.SUCCESS)) {
                            if (response.body().getResponse() != null
                                    && !TextUtils.isEmpty(response.body().getResponse().getLoanRequestId())) {
                                MyApplication.LOAN_REQ_ID = response.body().getResponse().getLoanRequestId();
                                reqFormConfig(response.body().getResponse().getLoanRequestId());
                            } else {
                                reqFormConfig("");
                            }
                        } else {
                            Mobilevalid.set(false);
                            MobileErrorText.set(response.body().getStatusMessage());
                            hideLoading();
                        }
                    } else {
                        if (response.body() != null)
                            showToast(mobileNumberFramgnet.getContext(), response.body().getStatusMessage());
                        hideLoading();
                    }

                }

                @Override
                public void onFailure(Call<MobileBaseResponse> call, Throwable t) {
                    hideLoading();
                }
            });
        }

        @Override
        protected void getFormConfigResponse (com.ziploan.dsaapp.model.response.form_config.Response
        response){
            MyApplication.FromMobile = true;
            if (response != null) {
                if (response.getLandsOn() != null) {
                    MyApplication.formResponse = response;
                    if (response.getLandsOn().equalsIgnoreCase("personal_info")) {
                        if (response.getPersonalInfoFilled())
                            NavController.getInstance().addFragment(PersonalDetailsFragment.newInstance(response.getCustomerPan(), response.getLoanRequestId(),
                                    response.getShowPages() != null ? response.getShowPages().size() : 3), true);
                        else
                            NavController.getInstance().addFragment(PersonalDetailsFragment.newInstance(Mobile.get(), response.getLoanRequestId(),
                                    response.getShowPages() != null ? response.getShowPages().size() : 3), true);
                    } else if (response.getLandsOn().equalsIgnoreCase("business_info")) {
                        NavController.getInstance().addFragment(BusinessDetailsFragment.newInstance(response.getLoanRequestId()
                                , response.getShowPages() != null ? response.getShowPages().size() : 3), true);
                    } else if (response.getLandsOn().equalsIgnoreCase("documents")) {
                        NavController.getInstance().addFragment(DocumentUploadDetailsFragment.newInstance(response.getLoanRequestId()
                                , response.getShowPages() != null ? response.getShowPages().size() : 3), true);
                    }
                } else {
                    showToast(MyApplication.getInstance(), MyApplication.getInstance().getString(R.string.duplicate_info));
                }
            } else {
                NavController.getInstance().addFragment(PersonalDetailsFragment.newInstance(Mobile.get(), "", 3), true);
            }
            hideLoading();
        }

        public void onUsernameTextChanged (CharSequence s){
            if (s.length() == 10 && CommonUtils.validateSolePersonalPan(s.toString())) {
                Mobilevalid.set(true);
            }
        }
    }
