package com.ziploan.dsaapp.utils.permissons;

abstract public class Func3 {
    protected abstract void call(String permissionName);
}
