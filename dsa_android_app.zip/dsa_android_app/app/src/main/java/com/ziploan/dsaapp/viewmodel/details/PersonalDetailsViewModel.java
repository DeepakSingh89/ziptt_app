package com.ziploan.dsaapp.viewmodel.details;

import android.content.ClipData;
import android.content.Context;
import android.graphics.Point;
import android.os.Handler;
import android.text.TextUtils;
import android.util.Log;
import android.view.View;
import android.view.ViewGroup;
import android.view.ViewParent;
import android.widget.EditText;
import android.widget.ScrollView;
import android.widget.TextView;

import com.google.android.material.textfield.TextInputEditText;
import com.google.android.material.textfield.TextInputLayout;

import java.util.ArrayList;
import java.util.List;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

import androidx.appcompat.widget.AppCompatButton;
import androidx.databinding.BindingAdapter;
import androidx.databinding.ObservableBoolean;
import androidx.databinding.ObservableField;
import com.ziploan.dsaapp.MyApplication;
import com.ziploan.dsaapp.R;
import com.ziploan.dsaapp.base.BaseViewModel;
import com.ziploan.dsaapp.base.extras.network.APIExecutor;
import com.ziploan.dsaapp.fragments.details.BusinessDetailsFragment;
import com.ziploan.dsaapp.fragments.details.PersonalDetailsFragment;
import com.ziploan.dsaapp.model.header.HeaderModel;
import com.ziploan.dsaapp.model.request.PersonalInfoRequest;
import com.ziploan.dsaapp.model.response.personal.PersonalInfoResponse;
import com.ziploan.dsaapp.model.response.personal.get_personal.GetPersonalInfoResponse;
import com.ziploan.dsaapp.model.response.pincode.PincodeResponse;
import com.ziploan.dsaapp.utils.CommonUtils;
import com.ziploan.dsaapp.utils.Constant;
import com.ziploan.dsaapp.utils.NavController;
import com.ziploan.dsaapp.utils.ZiploanDSAUtil;
import retrofit2.Call;
import retrofit2.Callback;
import retrofit2.Response;

public class PersonalDetailsViewModel extends BaseViewModel {

    public ObservableField<String> FirstName = new ObservableField<>();
    public ObservableField<String> LastName = new ObservableField<>();
    public ObservableField<String> Mobile = new ObservableField<>();
    public ObservableBoolean EnableMobile = new ObservableBoolean(true);
    public ObservableBoolean EnablePan = new ObservableBoolean(true);
    public ObservableField<String> Pan = new ObservableField<>();
    public ObservableField<String> DOB = new ObservableField<>();
    public ObservableField<String> Address = new ObservableField<>();
    public ObservableField<String> Pincode = new ObservableField<>();
    public ObservableField<String> City = new ObservableField<>();
    public ObservableField<String> State = new ObservableField<>();
    public ObservableBoolean AcceptCheck = new ObservableBoolean();
    public ObservableBoolean SelfOwnedSelected = new ObservableBoolean(false);
    public ObservableBoolean RentedSelected = new ObservableBoolean(false);
    public ObservableBoolean MaleSelected = new ObservableBoolean(false);
    public ObservableBoolean FemaleSelected = new ObservableBoolean(false);
    public ObservableBoolean OthersSelected = new ObservableBoolean(false);
    public ObservableBoolean ShowPanAlert = new ObservableBoolean(false);
    public ObservableBoolean GenderError = new ObservableBoolean(false);
    public ObservableBoolean PropertyError = new ObservableBoolean(false);
    private String gender;
    private String residentialPlaceOwnership;
    private boolean validPincode;
    private String loan_req_id;
    private boolean callPatch;
    private com.ziploan.dsaapp.model.response.form_config.Response formResponse;
    private Context context;

    public ObservableField<HeaderModel> headerModelObservableField = new ObservableField<>();
    private Pattern pattern;
    private Matcher matcher;

    private static final String DATE_PATTERN =
            "(0?[1-9]|[12][0-9]|3[01])/(0?[1-9]|1[012])/((19|20)\\d\\d)";


    public ObservableBoolean FirstNameInvalid = new ObservableBoolean();
    public ObservableField<String> FirstNameInvalidText = new ObservableField<>();
    public ObservableBoolean LastNameInvalid = new ObservableBoolean();
    public ObservableField<String> LastNameInvalidText = new ObservableField<>();

    public ObservableBoolean MobileInvalid = new ObservableBoolean();
    public ObservableField<String> MobileInvalidText = new ObservableField<>();
    public ObservableBoolean PanInvalid = new ObservableBoolean();
    public ObservableField<String> PanInvalidText = new ObservableField<>();

    public ObservableBoolean DOBInvalid = new ObservableBoolean();
    public ObservableField<String> DOBInvalidText = new ObservableField<>();
    public ObservableBoolean AddressInvalid = new ObservableBoolean();
    public ObservableField<String> AddressInvalidText = new ObservableField<>();
    public ObservableBoolean PincodeInvalid = new ObservableBoolean();
    public ObservableField<String> PincodeInvalidText = new ObservableField<>();


    public PersonalDetailsViewModel(){
        if(MyApplication.formResponse != null)
            getFormConfigResponse(MyApplication.formResponse);
        else
            headerModelObservableField.set(HeaderModel.setForPersonal());
    }

    public void setContext(Context context){
        this.context = context;
    }

    public void seNumOfPages(int numOfPages){
//        if(numOfPages > 3){
//            headerModelObservableField.set(HeaderModel.setForPersonalWtihCoApplicent());
//        } else {
//            headerModelObservableField.set(HeaderModel.setForPersonal());
//        }
    }

    public void setMobile(String mobile){
        if(!TextUtils.isEmpty(mobile)) {
            Mobile.set(mobile);
            EnableMobile.set(false);
        }
    }


    public void setPan(String pan){
        if(!TextUtils.isEmpty(pan)) {
            Pan.set(pan);
            EnablePan.set(false);
        }
    }

    public void setLonReqId(String lonReqId){
        loan_req_id = lonReqId;
        if(!TextUtils.isEmpty(loan_req_id)){
            getProductInfo(loan_req_id);
            reqFormConfig(loan_req_id);
        }
    }

    public void onClick(View view, PersonalDetailsFragment personalDetailsFragment) {
        switch (view.getId()){
            case R.id.rented:
                residentialPlaceOwnership = "rented";
                RentedSelected.set(true);
                SelfOwnedSelected.set(false);
                break;
            case R.id.self_owned:
                residentialPlaceOwnership = "self_owned";
                SelfOwnedSelected.set(true);
                RentedSelected.set(false);
                break;
            case R.id.male:
                gender = "male";
                MaleSelected.set(true);
                FemaleSelected.set(false);
                OthersSelected.set(false);
                break;
            case R.id.female:
                gender = "female";
                MaleSelected.set(false);
                FemaleSelected.set(true);
                OthersSelected.set(false);
                break;
            case R.id.other:
                gender = "other";
                MaleSelected.set(false);
                FemaleSelected.set(false);
                OthersSelected.set(true);
                break;
            case R.id.calender_icon:
                personalDetailsFragment.selectDate();
                break;
            case R.id.dob:
                personalDetailsFragment.selectDate();
                break;
            case R.id.personal_save_btn:
                if(canSubmit(personalDetailsFragment.getContext())){
                    personalDetailsFragment.hideKeyBoard();
                    showLoading(personalDetailsFragment.getContext());
                    postPersonalInfo(personalDetailsFragment);
                }
                break;
        }
    }

    public void setPincode(String pincode){
        checkPincode(pincode);
    }

    private void reset(){
        FirstNameInvalidText.set("");
        FirstNameInvalid.set(false);
        LastNameInvalidText.set("");
        LastNameInvalid.set(false);
        MobileInvalidText.set("");
        MobileInvalid.set(false);
        PanInvalidText.set("");
        PanInvalid.set(false);

        DOBInvalidText.set("");
        DOBInvalid.set(false);
        AddressInvalidText.set("");
        AddressInvalid.set(false);
        PincodeInvalidText.set("");
        PincodeInvalid.set(false);
        GenderError.set(false);
        PropertyError.set(false);
    }

    private boolean canSubmit(Context context){
        reset();
        if(!TextUtils.isEmpty(FirstName.get())){
            if(!TextUtils.isEmpty(LastName.get())){
                if(!TextUtils.isEmpty(Mobile.get())){
                   if(ZiploanDSAUtil.isValidMobile(Mobile.get())){
                       if (!TextUtils.isEmpty(Pan.get())) {
                           if (CommonUtils.validateSolePersonalPan(Pan.get())) {
                               if (!TextUtils.isEmpty(DOB.get())) {
                                   if (validate(DOB.get())) {
                                       if (!TextUtils.isEmpty(gender)) {
                                           if (!TextUtils.isEmpty(Address.get())) {
                                               if (!TextUtils.isEmpty(Pincode.get())) {
                                                   if (validPincode) {
                                                       if (!TextUtils.isEmpty(City.get())) {
                                                           if (!TextUtils.isEmpty(State.get())) {
                                                               if (!TextUtils.isEmpty(residentialPlaceOwnership)) {
                                                                   return true;
                                                               } else {
                                                                   showToast(context, context.getString(R.string.recidentail_status));
                                                                   PropertyError.set(true);
                                                               }
                                                           } else {
                                                               showToast(context, context.getString(R.string.fill_state_name));
                                                           }
                                                       } else {
                                                           showToast(context, context.getString(R.string.fill_city_name));
                                                       }
                                                   } else {
                                                       PincodeInvalidText.set(context.getString(R.string.pincode_invalid));
                                                       PincodeInvalid.set(true);
                                                   }
                                               } else {
                                                   PincodeInvalidText.set(context.getString(R.string.invalid_field));
                                                   PincodeInvalid.set(true);
                                               }
                                           } else {
                                               AddressInvalidText.set(context.getString(R.string.invalid_field));
                                               AddressInvalid.set(true);
                                           }
                                       } else {
                                           GenderError.set(true);
                                           showToast(context, context.getString(R.string.gender_invalid));
                                       }
                                   } else {
                                       DOBInvalidText.set(context.getString(R.string.invalid_field));
                                       DOBInvalid.set(true);
                                   }
                               } else {
                                   DOBInvalidText.set(context.getString(R.string.invalid_field));
                                   DOBInvalid.set(true);
                               }
                           } else {
                               PanInvalidText.set(context.getString(R.string.pan_not_valid));
                               PanInvalid.set(true);
                           }
                       } else {
                           PanInvalidText.set(context.getString(R.string.pan_not_valid));
                           PanInvalid.set(true);
                       }
                   }else{
                       MobileInvalidText.set(context.getString(R.string.invalid_mobile));
                       MobileInvalid.set(true);
                   }
                } else {
                    MobileInvalidText.set(context.getString(R.string.invalid_field));
                    MobileInvalid.set(true);
                }
            } else {
                LastNameInvalidText.set(context.getString(R.string.invalid_field));
                LastNameInvalid.set(true);
            }
        } else {
            FirstNameInvalidText.set(context.getString(R.string.invalid_field));
            FirstNameInvalid.set(true);
        }

        return false;
    }

    private void postPersonalInfo(PersonalDetailsFragment personalDetailsFragment) {
        PersonalInfoRequest personalInfoRequest = new PersonalInfoRequest();
        personalInfoRequest.setApplicantType(Constant.PERSONAL_INFO_APPLICANT_TYPE);
        if(MyApplication.formResponse != null)
            personalInfoRequest.setApplicationType(MyApplication.formResponse.getApplicationType());
        else
            personalInfoRequest.setApplicationType(Constant.NEW_APPLICATION_TYPE);

        personalInfoRequest.setFirstName(FirstName.get());
        personalInfoRequest.setLastName(LastName.get());
        personalInfoRequest.setDateOfBirth(DOB.get());
        personalInfoRequest.setMobile(Mobile.get());
        personalInfoRequest.setPan(Pan.get());

        personalInfoRequest.setResidentialAddress(Address.get());
        personalInfoRequest.setResidentialPincode(Pincode.get());
        personalInfoRequest.setResidentialCity(City.get());
        personalInfoRequest.setResidentialState(State.get());
        personalInfoRequest.setGender(gender);
        personalInfoRequest.setResidentialPlaceOwnership(residentialPlaceOwnership);
        personalInfoRequest.setLoanProductId(Constant.LOAN_PRODUCT_ID);
        personalInfoRequest.setSourcingType(0);
        personalInfoRequest.setLoanRequestId(MyApplication.LOAN_REQ_ID);


        new Handler().postDelayed(new Runnable() {
            @Override
            public void run() {
             hideLoading();
            }
        },6*1000);
        Call<PersonalInfoResponse> personalInfoResponseCall;
        if (formResponse != null && formResponse.getPersonalInfoFilled())
            personalInfoResponseCall = APIExecutor.getAPIService().patchPersonalInfo(personalInfoRequest);
//            else if(callPatch)
//                personalInfoResponseCall = APIExecutor.getAPIService().patchPersonalInfo(personalInfoRequest);
        else
            personalInfoResponseCall = APIExecutor.getAPIService().postPersonalInfo(personalInfoRequest);

        personalInfoResponseCall.enqueue(new Callback<PersonalInfoResponse>() {
            @Override
            public void onResponse(Call<PersonalInfoResponse> call, Response<PersonalInfoResponse> response) {
                if (response.isSuccessful()
                        && response.body() != null) {
                    if (response.body().getStatus().equalsIgnoreCase(Constant.SUCCESS)) {
                        if (response.body().getResponse().getLoanRequestId() != null) {
                            MyApplication.LOAN_REQ_ID = response.body().getResponse().getLoanRequestId();
                            reqFormConfigForNavigation(MyApplication.LOAN_REQ_ID);
                        } else {
                            hideLoading();
                        }
                    } else {
                        try {
                            if (response.body().getResponse().getPan() != null) {
                                List<String> panError = (ArrayList<String>) response.body().getResponse().getPan();
                                if (panError != null) {
                                    PanInvalidText.set(panError.get(0));
                                    PanInvalid.set(true);
                                    scrollToView(personalDetailsFragment.getParentView().mainScroll, personalDetailsFragment.getParentView().personalPan);
                                }
                            }
                        } catch (Exception e){}
                        showToast(personalDetailsFragment.getContext(), response.body().getStatusMessage());
                        hideLoading();
                    }
                }
            }

            @Override
            public void onFailure(Call<PersonalInfoResponse> call, Throwable t) {
                hideLoading();
                Log.d("failed", t.getMessage());
            }
        });
    }

    @Override
    protected void getFormConfigResponseForNav(com.ziploan.dsaapp.model.response.form_config.Response response) {
        hideLoading();
        NavController.getInstance().addFragment(BusinessDetailsFragment.newInstance(MyApplication.LOAN_REQ_ID, Pan.get()), true);
    }

    private void checkPincode(String pincode){
        Call<PincodeResponse> pincodeResponseCall = APIExecutor.getAPIService().checkPincode(pincode);
        pincodeResponseCall.enqueue(new Callback<PincodeResponse>() {
            @Override
            public void onResponse(Call<PincodeResponse> call, Response<PincodeResponse> response) {
                if(response.isSuccessful() && response.body().getStatus().equalsIgnoreCase(Constant.SUCCESS)){
                    validPincode = true;
                    City.set(response.body().getResponse().getCity().getValue());
                    State.set(response.body().getResponse().getState().getValue());
                } else {
                    if(response.body() != null) {
                        PincodeInvalidText.set(response.body().getStatusMessage());
                        PincodeInvalid.set(true);
                    }
                }
                hideLoading();
            }

            @Override
            public void onFailure(Call<PincodeResponse> call, Throwable t) {
                hideLoading();
                Log.d("failed",t.getMessage());
            }
        });
    }

    public void getProductInfo(String loan_req_id){
        showLoading(context);
        Call<GetPersonalInfoResponse> getPersonalInfoResponseCall = APIExecutor.getAPIService().getPersonalInfo(loan_req_id,Constant.PERSONAL_INFO_APPLICANT_TYPE,Constant.EDIT_APPLICATION_TYPE);
        getPersonalInfoResponseCall.enqueue(new Callback<GetPersonalInfoResponse>() {
            @Override
            public void onResponse(Call<GetPersonalInfoResponse> call, Response<GetPersonalInfoResponse> response) {
                if(response.isSuccessful() && response.body() != null
                                            && response.body().getResponse() != null){
                    callPatch = true;
                    fillPersonalInfoData(response.body().getResponse());
                }
                hideLoading();
            }

            @Override
            public void onFailure(Call<GetPersonalInfoResponse> call, Throwable t) {
                hideLoading();
                Log.d("failed",t.getMessage());
            }
        });
    }

    private void fillPersonalInfoData(com.ziploan.dsaapp.model.response.personal.get_personal.Response response) {
        FirstName.set(response.getFirstName());
        LastName.set(response.getLastName());
        DOB.set(response.getDateOfBirth());
        Mobile.set(response.getMobile());
        Pan.set(response.getPan());
        EnablePan.set(false);

        Address.set(response.getResidentialAddress());
        Pincode.set(response.getResidentialPincode());
        validPincode = true;
        City.set(response.getResidentialCity());
        State.set(response.getResidentialState());

        if(!TextUtils.isEmpty(response.getResidentialPlaceOwnership())) {
            if (response.getResidentialPlaceOwnership().equalsIgnoreCase("rented")) {
                residentialPlaceOwnership = "rented";
                SelfOwnedSelected.set(false);
                RentedSelected.set(true);
            } else if (response.getResidentialPlaceOwnership().equalsIgnoreCase("self_owned")) {
                residentialPlaceOwnership = "self_owned";
                SelfOwnedSelected.set(true);
                RentedSelected.set(false);
            }
        }

        if(!TextUtils.isEmpty(response.getGender())) {
            if (response.getGender().equalsIgnoreCase("male")) {
                gender = "male";
                MaleSelected.set(true);
                FemaleSelected.set(false);
                OthersSelected.set(false);
            } else if (response.getGender().equalsIgnoreCase("female")) {
                gender = "female";
                MaleSelected.set(false);
                FemaleSelected.set(true);
                OthersSelected.set(false);
            }  else if (response.getGender().equalsIgnoreCase("other")) {
                gender = "other";
                MaleSelected.set(false);
                FemaleSelected.set(false);
                OthersSelected.set(true);
            }
        }
        validPincode = true;
    }

    public void setAlertVisible(){
        ShowPanAlert.set(true);
    }

    @Override
    protected void getFormConfigResponse(com.ziploan.dsaapp.model.response.form_config.Response response) {
        this.formResponse = response;
        if(response != null) {
            MyApplication.formResponse  = response;
            if (response.getDocumentsFilled()) {
                if (response.getCoapplicantFilled()) {
                    headerModelObservableField.set(HeaderModel.setForDocumentFilledWithCoApplicant(Constant.PERSONAL_INFO_TAG));
                } else if (response.getShowPages().size() == 4) {
                    headerModelObservableField.set(HeaderModel.setForDocumentFilledWithCoApplicantunfilled(Constant.PERSONAL_INFO_TAG));
                }  else {
                    headerModelObservableField.set(HeaderModel.setForDocumentFilled(Constant.PERSONAL_INFO_TAG));
                }
            } else if (response.getCoapplicantFilled()) {
                headerModelObservableField.set(HeaderModel.setForCoapplicantFilled(Constant.PERSONAL_INFO_TAG));
            } else if (response.getBusinessInfoFilled()) {
                if (response.getShowPages().size() == 4) {
                    headerModelObservableField.set(HeaderModel.setForBusinessCoapplicantFilled(Constant.PERSONAL_INFO_TAG));
                } else {
                    headerModelObservableField.set(HeaderModel.setForBusinessFilled(Constant.PERSONAL_INFO_TAG));
                }
            } else if (response.getPersonalInfoFilled()) {
                if (response.getCoapplicantFilled()) {
                    headerModelObservableField.set(HeaderModel.setForPersonalInfoFilledCo(Constant.PERSONAL_INFO_TAG));
                } else {
                    headerModelObservableField.set(HeaderModel.setForPersonalInfoFilled(Constant.PERSONAL_INFO_TAG));
                }
            } else{
                headerModelObservableField.set(HeaderModel.setForPersonal());
            }
        }
        else {
            headerModelObservableField.set(HeaderModel.setForPersonal());
        }
    }

    private boolean validate(final String date){
        pattern = Pattern.compile(DATE_PATTERN);
//        matcher = Pattern.compile(DATE_PATTERN).matcher(date);
        matcher = pattern.matcher(date.trim());

        if(matcher.matches()){
            matcher.reset();

            if(matcher.find()){
                String day = matcher.group(1);
                String month = matcher.group(2);
                int year = Integer.parseInt(matcher.group(3));

                if (day.equals("31") &&
                        (month.equals("4") || month .equals("6") || month.equals("9") ||
                                month.equals("11") || month.equals("04") || month .equals("06") ||
                                month.equals("09"))) {
                    return false; // only 1,3,5,7,8,10,12 has 31 days
                }

                else if (month.equals("2") || month.equals("02")) {
                    //leap year
                    if(year % 4==0){
                        if(day.equals("30") || day.equals("31")){
                            return false;
                        }
                        else{
                            return true;
                        }
                    }
                    else{
                        if(day.equals("29")||day.equals("30")||day.equals("31")){
                            return false;
                        }
                        else{
                            return true;
                        }
                    }
                }

                else{
                    return true;
                }
            }

            else{
                return false;
            }
        }
        else{
            return false;
        }
    }

    private void scrollToView(final ScrollView scrollViewParent, final View view) {
        Point childOffset = new Point();
        getDeepChildOffset(scrollViewParent, view.getParent(), view, childOffset);
        scrollViewParent.smoothScrollTo(0, childOffset.y);
    }

    private void getDeepChildOffset(final ViewGroup mainParent, final ViewParent parent, final View child, final Point accumulatedOffset) {
        ViewGroup parentGroup = (ViewGroup) parent;
        accumulatedOffset.x += child.getLeft();
        accumulatedOffset.y += child.getTop();
        if (parentGroup.equals(mainParent)) {
            return;
        }
        getDeepChildOffset(mainParent, parentGroup.getParent(), parentGroup, accumulatedOffset);
    }

    @BindingAdapter({"color"})
    public static void setFont(TextView textView, ObservableBoolean error) {
        if(error.get()) {
            textView.setTextColor(textView.getResources().getColor(R.color.dark_orange));
        } else {
            textView.setTextColor(textView.getResources().getColor(R.color.edittext_color));
        }
    }
}
