package com.ziploan.dsaapp.fragments.login;

import android.os.Bundle;
import android.text.Spannable;
import android.text.SpannableString;
import android.text.Spanned;
import android.text.method.LinkMovementMethod;
import android.view.View;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.appcompat.widget.AppCompatTextView;
import androidx.lifecycle.ViewModel;
import androidx.lifecycle.ViewModelProvider;
import androidx.lifecycle.ViewModelProviders;
import com.ziploan.dsaapp.R;
import com.ziploan.dsaapp.base.BaseRepository;
import com.ziploan.dsaapp.base.BindingFragment;
import com.ziploan.dsaapp.databinding.LoginFragmentLayoutBinding;
import com.ziploan.dsaapp.fragments.weview.ZipWebviewFragment;
import com.ziploan.dsaapp.model.response.LoginResponse;
import com.ziploan.dsaapp.utils.KeyboardUtils;
import com.ziploan.dsaapp.utils.NavController;
import com.ziploan.dsaapp.utils.ZipClickableSpan;
import com.ziploan.dsaapp.viewmodel.login.LoginViewmodel;

public class LoginFragment extends BindingFragment<LoginFragmentLayoutBinding, LoginViewmodel, BaseRepository> {

    private IDoneLogin iDoneLogin;
    public static LoginFragment newInstance() {
        LoginFragment fragment = new LoginFragment();
        Bundle args = new Bundle();
        fragment.setArguments(args);
        return fragment;
    }

    @Override
    public LoginViewmodel getViewModel(BaseRepository repository) {
        return  ViewModelProviders.of(this, new ViewModelProvider.Factory() {
            @NonNull
            @Override
            public <T extends ViewModel> T create(@NonNull Class<T> modelClass) {
                return (T)new LoginViewmodel();
            }
        }).get(LoginViewmodel.class);
    }

    @Override
    public void onResume() {
        super.onResume();
        if(mainActivity.get() != null
                && mainActivity.get().getSupportActionBar() != null)
            mainActivity.get().getSupportActionBar().hide();
    }

    @Override
    public void onPause() {
        super.onPause();
        KeyboardUtils.hideKeyboard(mainActivity.get());
    }
    @Override
    public int getLayoutId() {
        return R.layout.login_fragment_layout;
    }
    @Override
    public BaseRepository getRepository() {
        return null;
    }

    @Override
    public void onViewCreated(@NonNull View view, @Nullable Bundle savedInstanceState) {
        super.onViewCreated(view, savedInstanceState);
        iDoneLogin = mainActivity.get();
        if(getViewModel() != null)
            getViewModel().setLoginDone(iDoneLogin);

        AppCompatTextView TV = view.findViewById(R.id.t_and_c);
        TV.setMovementMethod(LinkMovementMethod.getInstance());
        Spannable wordtoSpan = new SpannableString(getString(R.string.tandc_signin));
        wordtoSpan.setSpan(new ZipClickableSpan(getString(R.string.tandc),getContext()){
            @Override
            public void onClick(View tv) {
                NavController.getInstance().addFragment(ZipWebviewFragment.newInstance("https://ziploan.in/policies#privacy"),true);
            }
        }, 62, 76, Spanned.SPAN_EXCLUSIVE_EXCLUSIVE);

        wordtoSpan.setSpan(new ZipClickableSpan(getString(R.string.tandc),getContext()){
            @Override
            public void onClick(View tv) {
                NavController.getInstance().addFragment(ZipWebviewFragment.newInstance("https://ziploan.in/policies#terms"),true);
            }
        }, 41, 57, Spanned.SPAN_EXCLUSIVE_EXCLUSIVE);

        TV.setText(wordtoSpan);
    }

    public interface IDoneLogin {
        void doneLogin(LoginResponse loginResponse);
    }
}
