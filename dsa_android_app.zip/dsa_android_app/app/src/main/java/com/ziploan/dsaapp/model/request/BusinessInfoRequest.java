package com.ziploan.dsaapp.model.request;

import com.google.gson.annotations.Expose;
import com.google.gson.annotations.SerializedName;

public class BusinessInfoRequest {
    @SerializedName("application_type")
    @Expose
    private String applicationType;
    @SerializedName("business_address")
    @Expose
    private String businessAddress;
    @SerializedName("business_name")
    @Expose
    private String businessName;
    @SerializedName("business_pan_no")
    @Expose
    private String businessPanNo;
    @SerializedName("business_place_ownership")
    @Expose
    private String businessPlaceOwnership;
    @SerializedName("city")
    @Expose
    private String city;
    @SerializedName("entity_type_name")
    @Expose
    private String entityTypeName;
    @SerializedName("loan_request_id")
    @Expose
    private String loanRequestId;
    @SerializedName("pincode")
    @Expose
    private String pincode;
    @SerializedName("state")
    @Expose
    private String state;

    @SerializedName("specified_margin")
    @Expose
    private int specifiedMargin;

    public String getApplicationType() {
        return applicationType;
    }

    public void setApplicationType(String applicationType) {
        this.applicationType = applicationType;
    }

    public String getBusinessAddress() {
        return businessAddress;
    }

    public void setBusinessAddress(String businessAddress) {
        this.businessAddress = businessAddress;
    }

    public String getBusinessName() {
        return businessName;
    }

    public void setBusinessName(String businessName) {
        this.businessName = businessName;
    }

    public String getBusinessPanNo() {
        return businessPanNo;
    }

    public void setBusinessPanNo(String businessPanNo) {
        this.businessPanNo = businessPanNo;
    }

    public String getBusinessPlaceOwnership() {
        return businessPlaceOwnership;
    }

    public void setBusinessPlaceOwnership(String businessPlaceOwnership) {
        this.businessPlaceOwnership = businessPlaceOwnership;
    }

    public String getCity() {
        return city;
    }

    public void setCity(String city) {
        this.city = city;
    }

    public String getEntityTypeName() {
        return entityTypeName;
    }

    public void setEntityTypeName(String entityTypeName) {
        this.entityTypeName = entityTypeName;
    }

    public String getLoanRequestId() {
        return loanRequestId;
    }

    public void setLoanRequestId(String loanRequestId) {
        this.loanRequestId = loanRequestId;
    }

    public String getPincode() {
        return pincode;
    }

    public void setPincode(String pincode) {
        this.pincode = pincode;
    }

    public String getState() {
        return state;
    }

    public void setState(String state) {
        this.state = state;
    }

    public int getSpecifiedMargin() {
        return specifiedMargin;
    }

    public void setSpecifiedMargin(int specifiedMargin) {
        this.specifiedMargin = specifiedMargin;
    }
}
