package com.ziploan.dsaapp.fragments.details;

import android.os.Bundle;
import android.text.Editable;
import android.text.TextWatcher;
import android.view.View;
import android.widget.ImageView;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.appcompat.app.AppCompatActivity;
import androidx.appcompat.widget.AppCompatTextView;
import androidx.lifecycle.ViewModel;
import androidx.lifecycle.ViewModelProvider;
import androidx.lifecycle.ViewModelProviders;

import com.github.florent37.viewtooltip.ViewTooltip;
import com.google.android.material.textfield.TextInputEditText;
import com.warkiz.widget.IndicatorSeekBar;
import com.warkiz.widget.OnSeekChangeListener;
import com.warkiz.widget.SeekParams;

import com.ziploan.dsaapp.R;
import com.ziploan.dsaapp.base.BaseRepository;
import com.ziploan.dsaapp.base.BindingFragment;
import com.ziploan.dsaapp.databinding.BusinessDetailsFragmentLayoutBinding;
import com.ziploan.dsaapp.utils.KeyboardUtils;
import com.ziploan.dsaapp.viewmodel.details.BusinessDetailsViewModel;

public class BusinessDetailsFragment extends BindingFragment<BusinessDetailsFragmentLayoutBinding, BusinessDetailsViewModel, BaseRepository> {

    private static final int MIN = 10;
    public static BusinessDetailsFragment newInstance(String loan_req_id) {
        BusinessDetailsFragment fragment = new BusinessDetailsFragment();
        Bundle args = new Bundle();
        args.putString("loan_req_id",loan_req_id);
        fragment.setArguments(args);
        return fragment;
    }

    public static BusinessDetailsFragment newInstance(String loan_req_id, String pan) {
        BusinessDetailsFragment fragment = new BusinessDetailsFragment();
        Bundle args = new Bundle();
        args.putString("loan_req_id",loan_req_id);
        args.putString("pan",pan);
        fragment.setArguments(args);
        return fragment;
    }

    public static BusinessDetailsFragment newInstance(String loan_req_id, int num_of_pages) {
        BusinessDetailsFragment fragment = new BusinessDetailsFragment();
        Bundle args = new Bundle();
        args.putString("loan_req_id",loan_req_id);
        args.putInt("num_of_pages",num_of_pages);
        fragment.setArguments(args);
        return fragment;
    }

    @Override
    public BusinessDetailsViewModel getViewModel(BaseRepository repository) {
        return  ViewModelProviders.of(this, new ViewModelProvider.Factory() {
            @NonNull
            @Override
            public <T extends ViewModel> T create(@NonNull Class<T> modelClass) {
                return (T)new BusinessDetailsViewModel(getArguments(), getContext());
            }
        }).get(BusinessDetailsViewModel.class);
    }

    @Override
    public void onPause() {
        super.onPause();
        KeyboardUtils.hideKeyboard(mainActivity.get());
    }

    @Override
    public void onResume() {
        super.onResume();
        ((AppCompatActivity)getActivity()).getSupportActionBar().setTitle(getString(R.string.business_detail));
        if(mainActivity.get().getSupportActionBar() != null) {
            mainActivity.get().getSupportActionBar().show();
            mainActivity.get().enableViews(true);
        }
    }

    @Override
    public BaseRepository getRepository() {
        return null;
    }

    @Override
    public int getLayoutId() {
        return R.layout.business_details_fragment_layout;
    }

    @Override
    public void onViewCreated(@NonNull View view, @Nullable Bundle savedInstanceState) {
        super.onViewCreated(view, savedInstanceState);
//        SeekBar indicatorSeekBar = view.findViewById(R.id.seekbar);
        IndicatorSeekBar indecativeseekbar = view.findViewById(R.id.indecativeseekbar);
        if(getViewModel() != null)
            getViewModel().setSeekbar(indecativeseekbar);
        if(getArguments() != null){
            if(getViewModel() != null) {
                getViewModel().seNumOfPages();
                getViewModel().setPanNumber(getArguments().getString("pan"));
            }
        }

        AppCompatTextView ten = view.findViewById(R.id.ten_text);
        View ten_line = view.findViewById(R.id.ten_line);

        AppCompatTextView fifteen = view.findViewById(R.id.fifteen_text);
        View fifteen_line = view.findViewById(R.id.fifteen_line);

        AppCompatTextView twenty = view.findViewById(R.id.twenty_text);
        View twentry_line = view.findViewById(R.id.twenty_line);

        AppCompatTextView twenty_five = view.findViewById(R.id.twente_five_text);
        View twenty_five_line = view.findViewById(R.id.twente_five_line);

        AppCompatTextView thirty = view.findViewById(R.id.thirty_text);
        View thirty_line = view.findViewById(R.id.thirty_line);

        AppCompatTextView thirty_five = view.findViewById(R.id.thirty_five_text);
        View thirty_five_line = view.findViewById(R.id.thirty_five_line);

        AppCompatTextView fourty = view.findViewById(R.id.fourty_text);
        View fourty_line = view.findViewById(R.id.fourty_line);

        indecativeseekbar.setOnSeekChangeListener(new OnSeekChangeListener() {
            @Override
            public void onSeeking(SeekParams seekParams) {
                int seektime = 0;
                if (getContext() != null) {
                    if (seekParams.progress <= 10) {
                        seektime = 10;
                        ten.setTextColor(getContext().getResources().getColor(R.color.orange_ff6317));
                        ten_line.setBackgroundColor(getContext().getResources().getColor(R.color.orange_ff6317));

                        fifteen.setTextColor(getContext().getResources().getColor(R.color.hint_edittext_color));
                        fifteen_line.setBackgroundColor(getContext().getResources().getColor(R.color.light_grey));

                        twenty.setTextColor(getContext().getResources().getColor(R.color.hint_edittext_color));
                        twentry_line.setBackgroundColor(getContext().getResources().getColor(R.color.light_grey));

                        twenty_five.setTextColor(getContext().getResources().getColor(R.color.hint_edittext_color));
                        twenty_five_line.setBackgroundColor(getContext().getResources().getColor(R.color.light_grey));

                        thirty.setTextColor(getContext().getResources().getColor(R.color.hint_edittext_color));
                        thirty_line.setBackgroundColor(getContext().getResources().getColor(R.color.light_grey));

                        thirty_five.setTextColor(getContext().getResources().getColor(R.color.hint_edittext_color));
                        thirty_five_line.setBackgroundColor(getContext().getResources().getColor(R.color.light_grey));

                        fourty.setTextColor(getContext().getResources().getColor(R.color.hint_edittext_color));
                        fourty_line.setBackgroundColor(getContext().getResources().getColor(R.color.light_grey));


                    } else {
                        seektime = seekParams.progress;
                        if (seektime == 15) {
                            ten.setTextColor(getContext().getResources().getColor(R.color.hint_edittext_color));
                            ten_line.setBackgroundColor(getContext().getResources().getColor(R.color.light_grey));

                            fifteen.setTextColor(getContext().getResources().getColor(R.color.orange_ff6317));
                            fifteen_line.setBackgroundColor(getContext().getResources().getColor(R.color.orange_ff6317));

                            twenty.setTextColor(getContext().getResources().getColor(R.color.hint_edittext_color));
                            twentry_line.setBackgroundColor(getContext().getResources().getColor(R.color.light_grey));

                            twenty_five.setTextColor(getContext().getResources().getColor(R.color.hint_edittext_color));
                            twenty_five_line.setBackgroundColor(getContext().getResources().getColor(R.color.light_grey));

                            thirty.setTextColor(getContext().getResources().getColor(R.color.hint_edittext_color));
                            thirty_line.setBackgroundColor(getContext().getResources().getColor(R.color.light_grey));

                            thirty_five.setTextColor(getContext().getResources().getColor(R.color.hint_edittext_color));
                            thirty_five_line.setBackgroundColor(getContext().getResources().getColor(R.color.light_grey));

                            fourty.setTextColor(getContext().getResources().getColor(R.color.hint_edittext_color));
                            fourty_line.setBackgroundColor(getContext().getResources().getColor(R.color.light_grey));
                        } else if (seektime == 20) {
                            ten.setTextColor(getContext().getResources().getColor(R.color.hint_edittext_color));
                            ten_line.setBackgroundColor(getContext().getResources().getColor(R.color.light_grey));

                            fifteen.setTextColor(getContext().getResources().getColor(R.color.hint_edittext_color));
                            fifteen_line.setBackgroundColor(getContext().getResources().getColor(R.color.light_grey));

                            twenty.setTextColor(getContext().getResources().getColor(R.color.orange_ff6317));
                            twentry_line.setBackgroundColor(getContext().getResources().getColor(R.color.orange_ff6317));

                            twenty_five.setTextColor(getContext().getResources().getColor(R.color.hint_edittext_color));
                            twenty_five_line.setBackgroundColor(getContext().getResources().getColor(R.color.light_grey));

                            thirty.setTextColor(getContext().getResources().getColor(R.color.hint_edittext_color));
                            thirty_line.setBackgroundColor(getContext().getResources().getColor(R.color.light_grey));

                            thirty_five.setTextColor(getContext().getResources().getColor(R.color.hint_edittext_color));
                            thirty_five_line.setBackgroundColor(getContext().getResources().getColor(R.color.light_grey));

                            fourty.setTextColor(getContext().getResources().getColor(R.color.hint_edittext_color));
                            fourty_line.setBackgroundColor(getContext().getResources().getColor(R.color.light_grey));
                        } else if (seektime == 25) {
                            ten.setTextColor(getContext().getResources().getColor(R.color.hint_edittext_color));
                            ten_line.setBackgroundColor(getContext().getResources().getColor(R.color.light_grey));

                            fifteen.setTextColor(getContext().getResources().getColor(R.color.hint_edittext_color));
                            fifteen_line.setBackgroundColor(getContext().getResources().getColor(R.color.light_grey));

                            twenty.setTextColor(getContext().getResources().getColor(R.color.hint_edittext_color));
                            twentry_line.setBackgroundColor(getContext().getResources().getColor(R.color.light_grey));

                            twenty_five.setTextColor(getContext().getResources().getColor(R.color.orange_ff6317));
                            twenty_five_line.setBackgroundColor(getContext().getResources().getColor(R.color.orange_ff6317));

                            thirty.setTextColor(getContext().getResources().getColor(R.color.hint_edittext_color));
                            thirty_line.setBackgroundColor(getContext().getResources().getColor(R.color.light_grey));

                            thirty_five.setTextColor(getContext().getResources().getColor(R.color.hint_edittext_color));
                            thirty_five_line.setBackgroundColor(getContext().getResources().getColor(R.color.light_grey));

                            fourty.setTextColor(getContext().getResources().getColor(R.color.hint_edittext_color));
                            fourty_line.setBackgroundColor(getContext().getResources().getColor(R.color.light_grey));
                        } else if (seektime == 30) {
                            ten.setTextColor(getContext().getResources().getColor(R.color.hint_edittext_color));
                            ten_line.setBackgroundColor(getContext().getResources().getColor(R.color.light_grey));

                            fifteen.setTextColor(getContext().getResources().getColor(R.color.hint_edittext_color));
                            fifteen_line.setBackgroundColor(getContext().getResources().getColor(R.color.light_grey));

                            twenty.setTextColor(getContext().getResources().getColor(R.color.hint_edittext_color));
                            twentry_line.setBackgroundColor(getContext().getResources().getColor(R.color.light_grey));

                            twenty_five.setTextColor(getContext().getResources().getColor(R.color.hint_edittext_color));
                            twenty_five_line.setBackgroundColor(getContext().getResources().getColor(R.color.light_grey));

                            thirty.setTextColor(getContext().getResources().getColor(R.color.orange_ff6317));
                            thirty_line.setBackgroundColor(getContext().getResources().getColor(R.color.orange_ff6317));

                            thirty_five.setTextColor(getContext().getResources().getColor(R.color.hint_edittext_color));
                            thirty_five_line.setBackgroundColor(getContext().getResources().getColor(R.color.light_grey));

                            fourty.setTextColor(getContext().getResources().getColor(R.color.hint_edittext_color));
                            fourty_line.setBackgroundColor(getContext().getResources().getColor(R.color.light_grey));
                        } else if (seektime == 35) {
                            ten.setTextColor(getContext().getResources().getColor(R.color.hint_edittext_color));
                            ten_line.setBackgroundColor(getContext().getResources().getColor(R.color.light_grey));

                            fifteen.setTextColor(getContext().getResources().getColor(R.color.hint_edittext_color));
                            fifteen_line.setBackgroundColor(getContext().getResources().getColor(R.color.light_grey));

                            twenty.setTextColor(getContext().getResources().getColor(R.color.hint_edittext_color));
                            twentry_line.setBackgroundColor(getContext().getResources().getColor(R.color.light_grey));

                            twenty_five.setTextColor(getContext().getResources().getColor(R.color.hint_edittext_color));
                            twenty_five_line.setBackgroundColor(getContext().getResources().getColor(R.color.light_grey));

                            thirty.setTextColor(getContext().getResources().getColor(R.color.hint_edittext_color));
                            thirty_line.setBackgroundColor(getContext().getResources().getColor(R.color.light_grey));

                            thirty_five.setTextColor(getContext().getResources().getColor(R.color.orange_ff6317));
                            thirty_five_line.setBackgroundColor(getContext().getResources().getColor(R.color.orange_ff6317));

                            fourty.setTextColor(getContext().getResources().getColor(R.color.hint_edittext_color));
                            fourty_line.setBackgroundColor(getContext().getResources().getColor(R.color.light_grey));
                        } else if (seektime >= 40) {
                            ten.setTextColor(getContext().getResources().getColor(R.color.hint_edittext_color));
                            ten_line.setBackgroundColor(getContext().getResources().getColor(R.color.light_grey));

                            fifteen.setTextColor(getContext().getResources().getColor(R.color.hint_edittext_color));
                            fifteen_line.setBackgroundColor(getContext().getResources().getColor(R.color.light_grey));

                            twenty.setTextColor(getContext().getResources().getColor(R.color.hint_edittext_color));
                            twentry_line.setBackgroundColor(getContext().getResources().getColor(R.color.light_grey));

                            twenty_five.setTextColor(getContext().getResources().getColor(R.color.hint_edittext_color));
                            twenty_five_line.setBackgroundColor(getContext().getResources().getColor(R.color.light_grey));

                            thirty.setTextColor(getContext().getResources().getColor(R.color.hint_edittext_color));
                            thirty_line.setBackgroundColor(getContext().getResources().getColor(R.color.light_grey));

                            thirty_five.setTextColor(getContext().getResources().getColor(R.color.hint_edittext_color));
                            thirty_five_line.setBackgroundColor(getContext().getResources().getColor(R.color.light_grey));

                            fourty.setTextColor(getContext().getResources().getColor(R.color.orange_ff6317));
                            fourty_line.setBackgroundColor(getContext().getResources().getColor(R.color.orange_ff6317));
                        }
                    }
                    if (getViewModel() != null)
                        getViewModel().setMargine(seektime);
                }
            }

            @Override
            public void onStartTrackingTouch(IndicatorSeekBar seekBar) {

            }

            @Override
            public void onStopTrackingTouch(IndicatorSeekBar seekBar) {

            }
        });

            indecativeseekbar.setProgress(25);

        TextInputEditText textInputEditTextPincode = view.findViewById(R.id.pincode_business_info);
//        textInputEditTextPincode.setOnFocusChangeListener(new View.OnFocusChangeListener() {
//            @Override
//            public void onFocusChange(View view, boolean b) {
//                if(!b && !TextUtils.isEmpty(textInputEditTextPincode.getText())
//                        && textInputEditTextPincode.length() == 6){
//                    if(getViewModel() != null)
//                        getViewModel().setPincode(textInputEditTextPincode.getText().toString());
//                }
//            }
//        });

        textInputEditTextPincode.addTextChangedListener(new TextWatcher() {
            @Override
            public void beforeTextChanged(CharSequence charSequence, int i, int i1, int i2) {

            }

            @Override
            public void onTextChanged(CharSequence charSequence, int i, int i1, int i2) {
                if(charSequence.length()>5) {
                    getViewModel().setPincode(charSequence.toString());
                }
            }

            @Override
            public void afterTextChanged(Editable editable) {

            }
        });

        ImageView info_icon = view.findViewById(R.id.info_icon);
        info_icon.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                View child = getLayoutInflater().inflate(R.layout.alert_pan, null);
                ViewTooltip
                        .on(mainActivity.get(),view)
                        .autoHide(true, 2000)
                        .withShadow(true)
                        .distanceWithView(-10)
                        .color(getResources().getColor(R.color.white))
                        .position(ViewTooltip.Position.LEFT)
                        .customView(child)
                        .arrowHeight(0)
                        .arrowWidth(0)
                        .show();
            }
        });
        getArguments().clear();
    }
    public int getConvertedValue(int intVal){
        int floatVal = intVal/2;
        floatVal = floatVal + intVal;
        return floatVal;
    }

    public BusinessDetailsFragmentLayoutBinding getParentView(){
        return getBinding();
    }
}
