package com.ziploan.dsaapp.model.response;

import com.google.gson.annotations.Expose;
import com.google.gson.annotations.SerializedName;

public class DocumentUploadResponse {

    @SerializedName("url")
    @Expose
    private String url;
    @SerializedName("msg")
    @Expose
    private String msg;
    @SerializedName("persisted")
    @Expose
    private Boolean persisted;
    @SerializedName("persist_error_msg")
    @Expose
    private String persistErrorMsg;

    public String getUrl() {
        return url;
    }

    public void setUrl(String url) {
        this.url = url;
    }

    public String getMsg() {
        return msg;
    }

    public void setMsg(String msg) {
        this.msg = msg;
    }

    public Boolean getPersisted() {
        return persisted;
    }

    public void setPersisted(Boolean persisted) {
        this.persisted = persisted;
    }

    public String getPersistErrorMsg() {
        return persistErrorMsg;
    }

    public void setPersistErrorMsg(String persistErrorMsg) {
        this.persistErrorMsg = persistErrorMsg;
    }
}
