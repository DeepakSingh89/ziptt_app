package com.ziploan.dsaapp.model.request;

import com.google.gson.annotations.Expose;
import com.google.gson.annotations.SerializedName;

public class PersonalInfoRequest {

    @SerializedName("aadhaar_no")
    @Expose
    private String aadhaarNo;
    @SerializedName("applicant_type")
    @Expose
    private Integer applicantType;
    @SerializedName("application_type")
    @Expose
    private String applicationType;
    @SerializedName("date_of_birth")
    @Expose
    private String dateOfBirth;
    @SerializedName("father_name")
    @Expose
    private String fatherName;
    @SerializedName("first_name")
    @Expose
    private String firstName;
    @SerializedName("gender")
    @Expose
    private String gender;
    @SerializedName("last_name")
    @Expose
    private String lastName;
    @SerializedName("loan_product_id")
    @Expose
    private String loanProductId;
    @SerializedName("loan_request_id")
    @Expose
    private String loanRequestId;
    @SerializedName("mobile")
    @Expose
    private String mobile;
    @SerializedName("otp")
    @Expose
    private String otp;
    @SerializedName("pan")
    @Expose
    private String pan;
    @SerializedName("relationship")
    @Expose
    private String relationship;
    @SerializedName("residential_address")
    @Expose
    private String residentialAddress;
    @SerializedName("residential_city")
    @Expose
    private String residentialCity;
    @SerializedName("residential_pincode")
    @Expose
    private String residentialPincode;
    @SerializedName("residential_place_ownership")
    @Expose
    private String residentialPlaceOwnership;
    @SerializedName("residential_state")
    @Expose
    private String residentialState;
    @SerializedName("shareholding_percentage")
    @Expose
    private String shareholdingPercentage;
    @SerializedName("sourcing_type")
    @Expose
    private Integer sourcingType;

    public String getAadhaarNo() {
        return aadhaarNo;
    }

    public void setAadhaarNo(String aadhaarNo) {
        this.aadhaarNo = aadhaarNo;
    }

    public Integer getApplicantType() {
        return applicantType;
    }

    public void setApplicantType(Integer applicantType) {
        this.applicantType = applicantType;
    }

    public String getApplicationType() {
        return applicationType;
    }

    public void setApplicationType(String applicationType) {
        this.applicationType = applicationType;
    }

    public String getDateOfBirth() {
        return dateOfBirth;
    }

    public void setDateOfBirth(String dateOfBirth) {
        this.dateOfBirth = dateOfBirth;
    }

    public String getFatherName() {
        return fatherName;
    }

    public void setFatherName(String fatherName) {
        this.fatherName = fatherName;
    }

    public String getFirstName() {
        return firstName;
    }

    public void setFirstName(String firstName) {
        this.firstName = firstName;
    }

    public String getGender() {
        return gender;
    }

    public void setGender(String gender) {
        this.gender = gender;
    }

    public String getLastName() {
        return lastName;
    }

    public void setLastName(String lastName) {
        this.lastName = lastName;
    }

    public String getLoanProductId() {
        return loanProductId;
    }

    public void setLoanProductId(String loanProductId) {
        this.loanProductId = loanProductId;
    }

    public String getLoanRequestId() {
        return loanRequestId;
    }

    public void setLoanRequestId(String loanRequestId) {
        this.loanRequestId = loanRequestId;
    }

    public String getMobile() {
        return mobile;
    }

    public void setMobile(String mobile) {
        this.mobile = mobile;
    }

    public String getOtp() {
        return otp;
    }

    public void setOtp(String otp) {
        this.otp = otp;
    }

    public String getPan() {
        return pan;
    }

    public void setPan(String pan) {
        this.pan = pan;
    }

    public String getRelationship() {
        return relationship;
    }

    public void setRelationship(String relationship) {
        this.relationship = relationship;
    }

    public String getResidentialAddress() {
        return residentialAddress;
    }

    public void setResidentialAddress(String residentialAddress) {
        this.residentialAddress = residentialAddress;
    }

    public String getResidentialCity() {
        return residentialCity;
    }

    public void setResidentialCity(String residentialCity) {
        this.residentialCity = residentialCity;
    }

    public String getResidentialPincode() {
        return residentialPincode;
    }

    public void setResidentialPincode(String residentialPincode) {
        this.residentialPincode = residentialPincode;
    }

    public String getResidentialPlaceOwnership() {
        return residentialPlaceOwnership;
    }

    public void setResidentialPlaceOwnership(String residentialPlaceOwnership) {
        this.residentialPlaceOwnership = residentialPlaceOwnership;
    }

    public String getResidentialState() {
        return residentialState;
    }

    public void setResidentialState(String residentialState) {
        this.residentialState = residentialState;
    }

    public String getShareholdingPercentage() {
        return shareholdingPercentage;
    }

    public void setShareholdingPercentage(String shareholdingPercentage) {
        this.shareholdingPercentage = shareholdingPercentage;
    }

    public Integer getSourcingType() {
        return sourcingType;
    }

    public void setSourcingType(Integer sourcingType) {
        this.sourcingType = sourcingType;
    }
}
