package com.ziploan.dsaapp.utils;

public class ReturnObject{

    public ReturnObject(String path, String mimeType){
        this.mimeType = mimeType;
        this.path = path;
    }
    String path;
    String mimeType;

    public String getPath() {
        return path;
    }

    public void setPath(String path) {
        this.path = path;
    }

    public String getMimeType() {
        return mimeType;
    }

    public void setMimeType(String mimeType) {
        this.mimeType = mimeType;
    }
}
