package com.ziploan.dsaapp.model.request;

import com.google.gson.annotations.SerializedName;

public class StartApplicationRequest {
    @SerializedName("pan")
    private String mobile;
    @SerializedName("loan_request_id")
    private String loan_request_id;

    public String getMobile() {
        return mobile;
    }

    public void setMobile(String mobile) {
        this.mobile = mobile;
    }

    public String getLoan_request_id() {
        return loan_request_id;
    }

    public void setLoan_request_id(String loan_request_id) {
        this.loan_request_id = loan_request_id;
    }
}
