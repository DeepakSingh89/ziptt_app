
package com.ziploan.dsaapp.model.response.document;

import com.google.gson.annotations.Expose;
import com.google.gson.annotations.SerializedName;

public class ItrDatum {

    @SerializedName("date")
    @Expose
    private String date;
    @SerializedName("itr_url")
    @Expose
    private String itrUrl;
    @SerializedName("itr_financial_year")
    @Expose
    private Object itrFinancialYear;

    public String getDate() {
        return date;
    }

    public void setDate(String date) {
        this.date = date;
    }

    public String getItrUrl() {
        return itrUrl;
    }

    public void setItrUrl(String itrUrl) {
        this.itrUrl = itrUrl;
    }

    public Object getItrFinancialYear() {
        return itrFinancialYear;
    }

    public void setItrFinancialYear(Object itrFinancialYear) {
        this.itrFinancialYear = itrFinancialYear;
    }

}
