package com.ziploan.dsaapp.fragments.home;

import android.os.Bundle;

import androidx.annotation.NonNull;
import androidx.lifecycle.ViewModel;
import androidx.lifecycle.ViewModelProvider;
import androidx.lifecycle.ViewModelProviders;
import com.ziploan.dsaapp.R;
import com.ziploan.dsaapp.base.BaseRepository;
import com.ziploan.dsaapp.base.BindingFragment;
import com.ziploan.dsaapp.databinding.SuccessLayoutBinding;
import com.ziploan.dsaapp.viewmodel.home.SuccessViewmodel;

public class SuccessFragment extends BindingFragment<SuccessLayoutBinding,SuccessViewmodel,BaseRepository> {

    public static SuccessFragment newInstance(boolean success) {
        SuccessFragment fragment = new SuccessFragment();
        Bundle args = new Bundle();
        args.putBoolean("success", success);
        fragment.setArguments(args);
        return fragment;
    }

    public static SuccessFragment newInstance(boolean success, String message) {
        SuccessFragment fragment = new SuccessFragment();
        Bundle args = new Bundle();
        args.putBoolean("success", success);
        args.putString("message",message);
        fragment.setArguments(args);
        return fragment;
    }

    @Override
    public int getLayoutId() {
        return R.layout.success_layout;
    }

    @Override
    public void onResume() {
        super.onResume();
        if(mainActivity.get() != null
                && mainActivity.get().getSupportActionBar() != null)
            mainActivity.get().getSupportActionBar().hide();
    }

    @Override
    public SuccessViewmodel getViewModel(BaseRepository repository) {
        return  ViewModelProviders.of(this, new ViewModelProvider.Factory() {
            @NonNull
            @Override
            public <T extends ViewModel> T create(@NonNull Class<T> modelClass) {
                return (T)new SuccessViewmodel(getArguments().getBoolean("success"), getArguments().getString("message"), getContext());
            }
        }).get(SuccessViewmodel.class);
    }

    @Override
    public BaseRepository getRepository() {
        return null;
    }
}
