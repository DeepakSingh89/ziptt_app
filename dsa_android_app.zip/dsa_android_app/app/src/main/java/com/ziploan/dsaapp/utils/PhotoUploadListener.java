package com.ziploan.dsaapp.utils;

import com.ziploan.dsaapp.model.ZiploanPhoto;

public interface PhotoUploadListener {
    void onUploadSuccess(ZiploanPhoto photo);
    void onUploadFailed(ZiploanPhoto photo);
    void onUploadStarted(ZiploanPhoto photo);
}
