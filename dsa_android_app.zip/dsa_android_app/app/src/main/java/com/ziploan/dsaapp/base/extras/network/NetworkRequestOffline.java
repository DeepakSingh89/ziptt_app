package com.ziploan.dsaapp.base.extras.network;

public class NetworkRequestOffline {
    public String url;
    public String strRequest;
}
