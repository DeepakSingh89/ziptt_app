package com.ziploan.dsaapp.fragments.home;

import android.os.Bundle;
import android.view.View;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.lifecycle.ViewModel;
import androidx.lifecycle.ViewModelProvider;
import androidx.lifecycle.ViewModelProviders;
import com.ziploan.dsaapp.MyApplication;
import com.ziploan.dsaapp.R;
import com.ziploan.dsaapp.base.BaseRepository;
import com.ziploan.dsaapp.base.BindingFragment;
import com.ziploan.dsaapp.databinding.HomeFragmentLayoutBinding;
import com.ziploan.dsaapp.utils.KeyboardUtils;
import com.ziploan.dsaapp.viewmodel.home.HomeViewmodel;

public class HomeFragment extends BindingFragment<HomeFragmentLayoutBinding, HomeViewmodel, BaseRepository> {


    public static HomeFragment newInstance() {
        HomeFragment fragment = new HomeFragment();
        Bundle args = new Bundle();
        fragment.setArguments(args);
        return fragment;
    }
    @Override
    public int getLayoutId() {
        return R.layout.home_fragment_layout;
    }
    @Override
    public void onResume() {
        super.onResume();
        if (mainActivity.get().getSupportActionBar() != null)
            mainActivity.get().getSupportActionBar().show();

        mainActivity.get().getSupportActionBar().setTitle("");

        if (mainActivity.get().backButtonVisible)
            mainActivity.get().enableViews(false);
    }

    @Override
    public void onPause() {
        super.onPause();
        KeyboardUtils.hideKeyboard(mainActivity.get());
    }

    @Override
    public HomeViewmodel getViewModel(BaseRepository repository) {
        return  ViewModelProviders.of(this, new ViewModelProvider.Factory() {
            @NonNull
            @Override
            public <T extends ViewModel> T create(@NonNull Class<T> modelClass) {
                return (T)new HomeViewmodel();
            }
        }).get(HomeViewmodel.class);
    }

    @Override
    public BaseRepository getRepository() {
        return null;
    }

    @Override
    public void onViewCreated(@NonNull View view, @Nullable Bundle savedInstanceState) {
        super.onViewCreated(view, savedInstanceState);
        if(getViewModel() != null)
            getViewModel().setMainActivity(mainActivity.get());
        MyApplication.LOAN_REQ_ID = "";
    }
}
