
package com.ziploan.dsaapp.model.response.business_info;

import android.text.TextUtils;

import com.google.gson.annotations.Expose;
import com.google.gson.annotations.SerializedName;

public class Response {

    @SerializedName("business_pan_no")
    @Expose
    private Object businessPanNo;
    @SerializedName("business_name")
    @Expose
    private String businessName;
    @SerializedName("entity_type_name")
    @Expose
    private String entityTypeName;
    @SerializedName("business_address")
    @Expose
    private String businessAddress;
    @SerializedName("pincode")
    @Expose
    private String pincode;
    @SerializedName("city")
    @Expose
    private String city;
    @SerializedName("state")
    @Expose
    private String state;
    @SerializedName("business_place_ownership")
    @Expose
    private String businessPlaceOwnership;
    @SerializedName("application_status")
    @Expose
    private String applicationStatus;

    @SerializedName("specified_margin")
    @Expose
    private String specifiedMargin;

    private String loan_request_status;

    public Object getBusinessPanNo() {
        return businessPanNo;
    }

    public void setBusinessPanNo(Object businessPanNo) {
        this.businessPanNo = businessPanNo;
    }

    public String getBusinessName() {
        return businessName;
    }

    public void setBusinessName(String businessName) {
        this.businessName = businessName;
    }

    public String getEntityTypeName() {
        return entityTypeName;
    }

    public void setEntityTypeName(String entityTypeName) {
        this.entityTypeName = entityTypeName;
    }

    public String getBusinessAddress() {
        return businessAddress;
    }

    public void setBusinessAddress(String businessAddress) {
        this.businessAddress = businessAddress;
    }

    public String getPincode() {
        return pincode;
    }

    public void setPincode(String pincode) {
        this.pincode = pincode;
    }

    public String getCity() {
        return city;
    }

    public void setCity(String city) {
        this.city = city;
    }

    public String getState() {
        return state;
    }

    public void setState(String state) {
        this.state = state;
    }

    public String getBusinessPlaceOwnership() {
        return businessPlaceOwnership;
    }

    public void setBusinessPlaceOwnership(String businessPlaceOwnership) {
        this.businessPlaceOwnership = businessPlaceOwnership;
    }

    public String getApplicationStatus() {
        return applicationStatus;
    }

    public void setApplicationStatus(String applicationStatus) {
        this.applicationStatus = applicationStatus;
    }

    public String getLoan_request_status() {
        return loan_request_status;
    }

    public void setLoan_request_status(String loan_request_status) {
        this.loan_request_status = loan_request_status;
    }

    public String getSpecifiedMargin() {
        return !TextUtils.isEmpty(specifiedMargin) ? specifiedMargin : "0";
    }

    public void setSpecifiedMargin(String specifiedMargin) {
        this.specifiedMargin = specifiedMargin;
    }
}
