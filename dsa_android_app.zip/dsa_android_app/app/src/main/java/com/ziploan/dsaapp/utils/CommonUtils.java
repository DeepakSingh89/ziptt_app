package com.ziploan.dsaapp.utils;

import android.annotation.SuppressLint;
import android.app.ProgressDialog;
import android.content.Context;
import android.content.res.AssetManager;
import android.graphics.Color;
import android.graphics.drawable.ColorDrawable;
import android.provider.Settings;
import android.util.Log;
import android.util.Patterns;
import android.view.Gravity;
import android.view.LayoutInflater;
import android.view.View;
import android.view.Window;
import android.view.WindowManager;
import android.widget.TextView;

import java.io.IOException;
import java.io.InputStream;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

import androidx.appcompat.app.AlertDialog;
import com.ziploan.dsaapp.R;
import com.ziploan.dsaapp.base.extras.network.APIExecutor;
import com.ziploan.dsaapp.model.response.form_config.FormConfigResponse;
import com.ziploan.dsaapp.model.response.pincode.PincodeResponse;
import retrofit2.Call;
import retrofit2.Callback;
import retrofit2.Response;

public class CommonUtils {
    private CommonUtils() {
        // This utility class is not publicly instantiable
    }

    @SuppressLint("all")
    public static String getDeviceId(Context context) {
        return Settings.Secure.getString(context.getContentResolver(), Settings.Secure.ANDROID_ID);
    }

    public static boolean isEmailValid(String email) {
        return Patterns.EMAIL_ADDRESS.matcher(email).matches();
    }

    public static String loadJSONFromAsset(Context context, String jsonFileName) throws IOException {
        AssetManager manager = context.getAssets();
        InputStream is = manager.open(jsonFileName);

        int size = is.available();
        byte[] buffer = new byte[size];
        is.read(buffer);
        is.close();

        return new String(buffer, "UTF-8");
    }

    public static ProgressDialog showLoadingDialog(Context context) {
        ProgressDialog progressDialog = new ProgressDialog(context);
        progressDialog.show();
        if (progressDialog.getWindow() != null) {
            progressDialog.getWindow().setBackgroundDrawable(new ColorDrawable(Color.TRANSPARENT));
        }
        progressDialog.setContentView(R.layout.progress_dialog);
        progressDialog.setIndeterminate(true);
        progressDialog.setCancelable(false);
        progressDialog.setCanceledOnTouchOutside(false);
        return progressDialog;
    }

    public static void showPanAlert(Context context, LayoutInflater inflater){
        AlertDialog.Builder dialogBuilder = new AlertDialog.Builder(context);
        View dialogView = inflater.inflate(R.layout.alert_pan, null);
        dialogBuilder.setView(dialogView);

        TextView editText = dialogView.findViewById(R.id.pan);
        editText.setText(context.getString(R.string.info_text));
        AlertDialog alertDialog = dialogBuilder.create();

        alertDialog.requestWindowFeature(Window.FEATURE_NO_TITLE);
        WindowManager.LayoutParams wmlp = alertDialog.getWindow().getAttributes();

        wmlp.gravity = Gravity.END;
        wmlp.y = 220;

        alertDialog.show();
        Window window = alertDialog.getWindow();
        window.setLayout(400, WindowManager.LayoutParams.WRAP_CONTENT);
        window.setGravity(Gravity.END);
        window.setBackgroundDrawable(new ColorDrawable(android.graphics.Color.TRANSPARENT));
    }

    public static boolean validateSolePersonalPan(String pan) {
        Pattern pattern = Pattern.compile("([a-zA-Z]){3}[Pp][a-zA-Z]([0-9]){4}([a-zA-Z]){1}");
        Matcher matcher = pattern.matcher(pan.toUpperCase());
        if (matcher.matches()) {
            return true;
        } else
            return false;
    }

    public static boolean validateCompanyOnePersonPan(String pan, String name) {
        String firstbusinessletter = name.substring(0,1);
        Pattern pattern = Pattern.compile("([a-zA-Z]){3}[Cc][" + firstbusinessletter.toUpperCase() + "Bb]([0-9]){4}([a-zA-Z]){1}");
        Matcher matcher = pattern.matcher(pan.toUpperCase());
        if (matcher.matches()) {
            return true;
        } else
            return false;
    }

    public static boolean validateLLPPartnershipPan(String pan, String name) {

        String firstbusinessletter = name.substring(0,1);
        Pattern pattern = Pattern.compile("([a-zA-Z]){3}[Ff][" + firstbusinessletter.toUpperCase() + "Bb]([0-9]){4}([a-zA-Z]){1}");
        Matcher matcher = pattern.matcher(pan.toUpperCase());
        if (matcher.matches()) {
            return true;
        } else
            return false;
    }

    public static boolean validatePan(String pan, String name) {
        String firstbusinessletter = name.substring(0,1);
//        String rx = "[A-Z]{3}([CF])(?:(?<=P)" + firstbusinessletter + "|(?<!P)" + firstbusinessletter + ")[0-9]{4}[A-Z]";
        String rx = "[A-Z]{3}([CF])" + firstbusinessletter + ")[0-9]{4}[A-Z]";

        if (pan.toUpperCase().matches(rx)) {
            return true;
        } else
            return false;
    }
}
