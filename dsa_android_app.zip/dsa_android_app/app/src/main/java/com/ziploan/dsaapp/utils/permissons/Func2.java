package com.ziploan.dsaapp.utils.permissons;

public abstract class Func2{
    protected abstract void call(int requestCode, String permissions[], int[] grantResults);
}
