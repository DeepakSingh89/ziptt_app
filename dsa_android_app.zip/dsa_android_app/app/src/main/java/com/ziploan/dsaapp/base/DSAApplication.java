package com.ziploan.dsaapp.base;

import android.app.Application;

import com.jaiselrahman.filepicker.model.MediaFile;

import java.util.ArrayList;

public class DSAApplication extends Application {

    public static DSAApplication getmInstance() {
        return mInstance;
    }

    public ArrayList<MediaFile> getAllMedia() {
        return allMedia;
    }

    public void setAllMedia(ArrayList<MediaFile> allMedia) {
        this.allMedia = allMedia;
    }

    ArrayList<MediaFile> allMedia = new ArrayList<>();

    private static DSAApplication  mInstance= null;

    @Override
    public void onCreate() {
        super.onCreate();
        mInstance = this;

    }
}
