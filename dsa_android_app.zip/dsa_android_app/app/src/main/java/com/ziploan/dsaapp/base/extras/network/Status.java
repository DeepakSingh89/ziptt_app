package com.ziploan.dsaapp.base.extras.network;

public enum Status {
    SUCCESS,
    ERROR,
    LOADING
}
