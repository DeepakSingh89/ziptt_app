
package com.ziploan.dsaapp.model.request.document;

import com.google.gson.annotations.Expose;
import com.google.gson.annotations.SerializedName;

public class PostDocumentRequest {

    @SerializedName("loan_request_id")
    @Expose
    private String loanRequestId;
    @SerializedName("primary")
    @Expose
    private Primary primary;
    @SerializedName("secondary")
    @Expose
    private Secondary secondary;

    public String getLoanRequestId() {
        return loanRequestId;
    }

    public void setLoanRequestId(String loanRequestId) {
        this.loanRequestId = loanRequestId;
    }

    public Primary getPrimary() {
        return primary;
    }

    public void setPrimary(Primary primary) {
        this.primary = primary;
    }

    public Secondary getSecondary() {
        return secondary;
    }

    public void setSecondary(Secondary secondary) {
        this.secondary = secondary;
    }

}
