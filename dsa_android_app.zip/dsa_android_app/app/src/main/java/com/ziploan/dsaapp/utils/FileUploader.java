package com.ziploan.dsaapp.utils;

import android.content.Context;
import android.text.TextUtils;
import android.util.Log;

import com.google.gson.Gson;
import com.google.gson.JsonObject;

import org.json.JSONException;
import org.json.JSONObject;

import java.io.File;
import java.io.IOException;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import com.ziploan.dsaapp.base.extras.network.APIExecutor;
import com.ziploan.dsaapp.model.ZiploanPhoto;
import com.ziploan.dsaapp.model.response.FileUploadResponse;
import okhttp3.MediaType;
import okhttp3.RequestBody;
import retrofit2.Call;
import retrofit2.Callback;
import retrofit2.Response;

public class FileUploader {

    private final Context mContext;

    public FileUploader(Context context) {
        this.mContext = context;
    }

    public static FileUploader getInstance(Context context){
        return new FileUploader(context);
    }

    public void upload(String file_type, ZiploanPhoto filePaths, int bucket_id, String loanId, String bank_type, final PhotoUploadListener photoUploadListener) {
        final ZiploanPhoto photo = filePaths;
        File file = new File(photo.getPhotoPath());
        RequestBody fileBody = RequestBody.create(MediaType.parse(photo.getMedia_type()), file);
        RequestBody loanRequestId = RequestBody.create(MediaType.parse("text/plain"), loanId);
        RequestBody persist = RequestBody.create(MediaType.parse("application/json"), String.valueOf(true));
        RequestBody bucketId = RequestBody.create(MediaType.parse("application/json"), String.valueOf(bucket_id));
        RequestBody env = RequestBody.create(MediaType.parse("application/json"), Constant.ENV);
        RequestBody filename = RequestBody.create(MediaType.parse("text/plain"), file.getName());



        Map<String, RequestBody> map = new HashMap<>();
        map.put("uploaded_file\"; filename=\"" + file.getName(), fileBody);
        map.put("loan_request_id", loanRequestId);
        map.put("persist", persist);
        map.put("bucket_id", bucketId);
        map.put("env", env);
        map.put("fname", filename);
        if(!TextUtils.isEmpty(bank_type)) {
            RequestBody bankType = RequestBody.create(MediaType.parse("application/json"), bank_type);
            map.put("bank_type", bankType);
        }

        if(bucket_id == 1){
            RequestBody fileType = RequestBody.create(MediaType.parse("application/json"), file_type);
            map.put("file_type", fileType);
        }


        photoUploadListener.onUploadStarted(photo);
        Call<FileUploadResponse> call = APIExecutor.getAPIService_Media().uploadFile(map);
        call.enqueue(new Callback<FileUploadResponse>() {
            @Override
            public void onResponse(Call<FileUploadResponse> call, Response<FileUploadResponse> response) {
                if (response.code() == 200) {
                    if (response.body() != null && !TextUtils.isEmpty(response.body().getUrl())) {
                        photo.setRemote_path(response.body().getUrl());
                        photo.setPhotoIdentifier(response.body().getUpdated_id());
                        photoUploadListener.onUploadSuccess(photo);
                    } else {
                        photoUploadListener.onUploadFailed(photo);
                    }
                } else {
                    try {
                        if(response.errorBody() != null) {
                            String error = response.errorBody().string();
                            if (!TextUtils.isEmpty(error)) {
                                JSONObject jsonObj = new JSONObject(error);
                                photo.setError_message(jsonObj.getString("err"));
                            }
                        }
                    } catch (IOException e) {
                        e.printStackTrace();
                    } catch (JSONException e) {
                        e.printStackTrace();
                    }
                    photoUploadListener.onUploadFailed(photo);
                }
            }

            @Override
            public void onFailure(Call<FileUploadResponse> call, Throwable t) {
                photoUploadListener.onUploadFailed(photo);
            }
        });
    }

    public void deleteFile(ZiploanPhoto file, int bucket_id,String loanId, String bank_type){
        Map<String, String> query = new HashMap<>();
        query.put("loan_request_id",loanId);
        query.put("file_url",file.getRemote_path());
        query.put("bucket_id", String.valueOf(bucket_id));
        query.put("v", "v2");
        if(!bank_type.equalsIgnoreCase("0"))
            query.put("bank_type", bank_type);

        Call<FileUploadResponse> call = APIExecutor.getAPIService().deleteFile(query);
        call.enqueue(new Callback<FileUploadResponse>() {
            @Override
            public void onResponse(Call<FileUploadResponse> call, Response<FileUploadResponse> response) {
                Log.d("data",response.message());
            }
            @Override
            public void onFailure(Call<FileUploadResponse> call, Throwable t) {
                Log.d("data",t.getMessage());
            }
        });
    }
}
