
package com.ziploan.dsaapp.model.response.loan_list;

import java.util.List;
import com.google.gson.annotations.Expose;
import com.google.gson.annotations.SerializedName;

public class LoanListResponse {

    @SerializedName("total_count")
    @Expose
    private Integer totalCount;
    @SerializedName("num_pages")
    @Expose
    private Integer numPages;
    @SerializedName("partner_incomplete_loan_request_data")
    @Expose
    private List<PartnerIncompleteLoanRequestDatum> partnerIncompleteLoanRequestData = null;

    public Integer getTotalCount() {
        return totalCount;
    }

    public void setTotalCount(Integer totalCount) {
        this.totalCount = totalCount;
    }

    public Integer getNumPages() {
        return numPages;
    }

    public void setNumPages(Integer numPages) {
        this.numPages = numPages;
    }

    public List<PartnerIncompleteLoanRequestDatum> getPartnerIncompleteLoanRequestData() {
        return partnerIncompleteLoanRequestData;
    }

    public void setPartnerIncompleteLoanRequestData(List<PartnerIncompleteLoanRequestDatum> partnerIncompleteLoanRequestData) {
        this.partnerIncompleteLoanRequestData = partnerIncompleteLoanRequestData;
    }

}
