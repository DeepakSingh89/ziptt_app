package com.ziploan.dsaapp;

import android.content.BroadcastReceiver;
import android.content.Context;
import android.content.DialogInterface;
import android.content.Intent;
import android.content.IntentFilter;
import android.content.res.Configuration;
import android.net.ConnectivityManager;
import android.os.Build;
import android.os.Bundle;
import android.os.Handler;
import android.text.TextUtils;
import android.view.MenuItem;
import android.view.View;
import android.widget.FrameLayout;
import android.widget.TextView;
import android.widget.Toast;

import androidx.appcompat.app.ActionBar;
import androidx.appcompat.app.ActionBarDrawerToggle;
import androidx.appcompat.app.AlertDialog;
import androidx.appcompat.app.AppCompatActivity;
import androidx.appcompat.app.AppCompatDelegate;
import androidx.appcompat.widget.AppCompatButton;
import androidx.appcompat.widget.Toolbar;
import androidx.core.view.GravityCompat;
import androidx.databinding.BindingAdapter;
import androidx.drawerlayout.widget.DrawerLayout;

import com.google.android.material.navigation.NavigationView;

import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.Calendar;
import java.util.Date;
import java.util.Locale;
import java.util.TimeZone;

import com.ziploan.dsaapp.fragments.details.BusinessDetailsFragment;
import com.ziploan.dsaapp.fragments.details.CoApplicantFragment;
import com.ziploan.dsaapp.fragments.details.DocumentUploadDetailsFragment;
import com.ziploan.dsaapp.fragments.details.PersonalDetailsFragment;
import com.ziploan.dsaapp.fragments.edit_app.EditApplicationFragment;
import com.ziploan.dsaapp.fragments.home.HomeFragment;
import com.ziploan.dsaapp.fragments.home.MobileNumberFramgnet;
import com.ziploan.dsaapp.fragments.login.LoginFragment;
import com.ziploan.dsaapp.fragments.weview.ZipWebviewFragment;
import com.ziploan.dsaapp.model.response.LoginResponse;
import com.ziploan.dsaapp.utils.NavController;
import com.ziploan.dsaapp.utils.NetworkUtils;
import com.ziploan.dsaapp.utils.PreferencesManager;
import com.ziploan.dsaapp.utils.ZiploanDSAUtil;

public class MainActivity extends AppCompatActivity implements LoginFragment.IDoneLogin {
    private boolean doubleBackToExitPressedOnce = false;
    private DrawerLayout mDrawerLayout;
    private ActionBarDrawerToggle drawerToggle;
    private ActionBarDrawerToggle mDrawerToggle;
    private boolean mToolBarNavigationListenerIsRegistered;
    public boolean backButtonVisible = false;
    private TextView name;
    private Toolbar toolbar;
    private FrameLayout no_network_layout;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setTheme(R.style.AppThemeDark);
        setContentView(R.layout.activity_main);
        toolbar = findViewById(R.id.toolbar);
        no_network_layout = findViewById(R.id.relative_no_network);
        setSupportActionBar(toolbar);
        ActionBar actionbar = getSupportActionBar();
        actionbar.setDisplayHomeAsUpEnabled(true);
        actionbar.setHomeAsUpIndicator(R.drawable.ic_menu);

        AppCompatDelegate.setCompatVectorFromResourcesEnabled(true);
        NavController.init(getSupportFragmentManager());
        initNavBar();
        if (PreferencesManager.getInstance().isUserLoggedIn()
                && isTokenAlive(ZiploanDSAUtil.getInstance(this).getExpirationDate())) {
            NavController
                    .getInstance()
                    .addFragment(HomeFragment.newInstance(), false);
        } else {
            if (getSupportActionBar() != null)
                getSupportActionBar().hide();
            enableViews(true);

            NavController
                    .getInstance()
                    .addFragment(LoginFragment.newInstance(), false);

        }
    }

    private void initNavBar() {
        mDrawerLayout = findViewById(R.id.drawer_layout);
        AppCompatButton logout = findViewById(R.id.logout);
        logout.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                mDrawerLayout.closeDrawers();
                mDrawerLayout.setDrawerLockMode(DrawerLayout.LOCK_MODE_LOCKED_CLOSED);
                mDrawerToggle.setDrawerIndicatorEnabled(false);
                logout();
                NavController.getInstance().clearBack();
                NavController.getInstance()
                        .addFragment(LoginFragment.newInstance(), false);
            }
        });
        drawerToggle = setupDrawerToggle();
        mDrawerLayout.addDrawerListener(drawerToggle);
        enableViews(false);
        initNavbar();
    }

    private void initNavbar() {
        NavigationView navigationView = findViewById(R.id.nav_view);
        navigationView.setNavigationItemSelectedListener(
                new NavigationView.OnNavigationItemSelectedListener() {
                    @Override
                    public boolean onNavigationItemSelected(MenuItem menuItem) {
                        menuItem.setChecked(true);
                        mDrawerLayout.closeDrawers();
                        handleMenuitemClick(menuItem);
                        return true;
                    }
                });
        View hView = navigationView.getHeaderView(0);
        name = hView.findViewById(R.id.user_name);
        name.setText(PreferencesManager.getInstance().getString(PreferencesManager.PARTNER_ACCOUNT_NAME));
    }

    @Override
    public void onBackPressed() {
        if (mDrawerLayout.isDrawerOpen(GravityCompat.START))
            mDrawerLayout.closeDrawer(GravityCompat.START);
        else {
            try {
                ZipWebviewFragment zipWebviewFragment = (ZipWebviewFragment) getSupportFragmentManager().findFragmentByTag(ZipWebviewFragment.class.getName());
                if (zipWebviewFragment != null && zipWebviewFragment.isVisible()) {
                    super.onBackPressed();
                } else {
                    if ((NavController.getInstance().getCurrentFragment(BusinessDetailsFragment.class.getName()) != null && NavController.getInstance().getCurrentFragment(BusinessDetailsFragment.class.getName()).getClass().getName().equalsIgnoreCase(BusinessDetailsFragment.class.getName()))
                            || (NavController.getInstance().getCurrentFragment(PersonalDetailsFragment.class.getName()) != null && NavController.getInstance().getCurrentFragment(PersonalDetailsFragment.class.getName()).getClass().getName().equalsIgnoreCase(PersonalDetailsFragment.class.getName()))
                            || (NavController.getInstance().getCurrentFragment(DocumentUploadDetailsFragment.class.getName()) != null && NavController.getInstance().getCurrentFragment(DocumentUploadDetailsFragment.class.getName()).getClass().getName().equalsIgnoreCase(DocumentUploadDetailsFragment.class.getName()))
                            || (NavController.getInstance().getCurrentFragment(CoApplicantFragment.class.getName()) != null && NavController.getInstance().getCurrentFragment(CoApplicantFragment.class.getName()).getClass().getName().equalsIgnoreCase(CoApplicantFragment.class.getName()))) {
                        showDialogue(this, getString(R.string.leave_text), null);
                    } else {
                        if (NavController.getInstance().getCurrentFragment(LoginFragment.class.getName()) != null
                                && NavController.getInstance().getCurrentFragment(LoginFragment.class.getName()).getClass().getName().equalsIgnoreCase(LoginFragment.class.getName())) {
                            if (doubleBackToExitPressedOnce) {
                                super.onBackPressed();
                                return;
                            }
                            this.doubleBackToExitPressedOnce = true;
                            Toast.makeText(this, getString(R.string.press_exit), Toast.LENGTH_SHORT).show();

                            new Handler().postDelayed(new Runnable() {

                                @Override
                                public void run() {
                                    doubleBackToExitPressedOnce = false;
                                }
                            }, 2000);
                        } else {
                            super.onBackPressed();
                        }
                    }
                }
            } catch (Exception e) {
                super.onBackPressed();
            }
        }
    }

    protected void showDialogue(Context context, String message, String title) {
        AlertDialog.Builder builder;
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.LOLLIPOP) {
            builder = new AlertDialog.Builder(context, android.R.style.Theme_Material_Light_Dialog_NoActionBar);
        } else {
            builder = new AlertDialog.Builder(context);
        }
        builder.setTitle(title)
                .setMessage(message)
                .setPositiveButton(android.R.string.yes, new DialogInterface.OnClickListener() {
                    public void onClick(DialogInterface dialog, int which) {
                        dialog.dismiss();
                        if (!MyApplication.FromMobile) {
                            NavController.getInstance().clearBackTo(EditApplicationFragment.class.getName());
                        } else {
                            NavController.getInstance().clearBackTo(HomeFragment.class.getName());
                        }
                    }
                })
                .setNegativeButton("No", new DialogInterface.OnClickListener() {
                    @Override
                    public void onClick(DialogInterface dialogInterface, int i) {
                        dialogInterface.dismiss();
                    }
                }).setIcon(null)
                .show();
    }

    private void handleMenuitemClick(MenuItem menuItem) {
        switch (menuItem.getItemId()) {
            case R.id.create_menu:
                enableViews(true);
                NavController.getInstance()
                        .addFragment(MobileNumberFramgnet.newInstance(), true);
                break;
            case R.id.edit_menu:
                enableViews(true);
                NavController.getInstance()
                        .addFragment(EditApplicationFragment.newInstance(), true);
                break;
        }
    }

    private void logout() {
        PreferencesManager.getInstance().setUserLoggedIn(false);
        PreferencesManager.getInstance().setString(PreferencesManager.AUTH_ID, null);
        PreferencesManager.getInstance().setString(PreferencesManager.AUTH_TOKEN, null);
        PreferencesManager.getInstance().setString(PreferencesManager.EXPIRE_TIME, null);
        PreferencesManager.getInstance().setString(PreferencesManager.PARTNER_ACCOUNT_NAME, null);
        ZiploanDSAUtil.getInstance(this).setExpirationDate(null);
    }

    public void enableViews(boolean b) {
        if (b) {
            backButtonVisible = true;
            mDrawerLayout.setDrawerLockMode(DrawerLayout.LOCK_MODE_LOCKED_CLOSED);
            mDrawerToggle.setDrawerIndicatorEnabled(false);
            getSupportActionBar().setHomeAsUpIndicator(R.drawable.ic_arrow_back_black_24dp);
            getSupportActionBar().setDisplayHomeAsUpEnabled(true);
            if (!mToolBarNavigationListenerIsRegistered) {
                mDrawerToggle.setToolbarNavigationClickListener(new View.OnClickListener() {
                    @Override
                    public void onClick(View v) {
                        onBackPressed();
                    }
                });

                mToolBarNavigationListenerIsRegistered = true;
            }
        } else {
            backButtonVisible = false;
            mDrawerLayout.setDrawerLockMode(DrawerLayout.LOCK_MODE_UNLOCKED);
            getSupportActionBar().setHomeAsUpIndicator(R.drawable.ic_menu);
            getSupportActionBar().setDisplayHomeAsUpEnabled(true);
            mDrawerToggle.setDrawerIndicatorEnabled(true);
            mDrawerToggle.setToolbarNavigationClickListener(null);
            mToolBarNavigationListenerIsRegistered = false;
        }
    }

    @Override
    public boolean onOptionsItemSelected(MenuItem item) {
        if (drawerToggle.onOptionsItemSelected(item)) {
            return true;
        }
        switch (item.getItemId()) {
            case android.R.id.home:
                if (backButtonVisible) {
                    onBackPressed();
                } else {
                    mDrawerLayout.openDrawer(GravityCompat.START);
                }
                return true;

        }
        return super.onOptionsItemSelected(item);
    }

    @Override
    protected void onPostCreate(Bundle savedInstanceState) {
        super.onPostCreate(savedInstanceState);
        if (drawerToggle != null)
            drawerToggle.syncState();
    }

    @Override
    public void onConfigurationChanged(Configuration newConfig) {
        super.onConfigurationChanged(newConfig);
        if (drawerToggle != null)
            drawerToggle.onConfigurationChanged(newConfig);
    }

    private ActionBarDrawerToggle setupDrawerToggle() {
        mDrawerToggle = new ActionBarDrawerToggle(this, mDrawerLayout, toolbar,
                R.string.drawer_open, R.string.drawer_close);
        return mDrawerToggle;
    }

    @Override
    protected void onDestroy() {
        super.onDestroy();
        NavController.destroy();
    }

    private boolean isTokenAlive(String expirationDate) {
        if (!checkInternetConnection(this))
            return true;
        if (!TextUtils.isEmpty(expirationDate)
                && expirationDate.length() > 0) {
            Calendar cal = Calendar.getInstance();
            long expirationTimeInMillis = getTimeInLong("yyyy-MM-dd HH:mm:ss", expirationDate.substring(0, 19));
            if (expirationTimeInMillis != -1
                    && (expirationTimeInMillis - cal.getTimeInMillis()) > 60 * 1000) {
                return true;
            }
        }

        return false;
    }

    protected boolean checkInternetConnection(Context mContext) {
        if (NetworkUtils.isNetworkConnected(mContext)) return true;
        else {
            return false;
        }
    }

    public static long getTimeInLong(String format, String dateString) {
        try {
            SimpleDateFormat dateFormat = new SimpleDateFormat(format, Locale.ENGLISH);
            dateFormat.setTimeZone(TimeZone.getTimeZone("IST"));
            Date date = dateFormat.parse(dateString);
            return date.getTime();
        } catch (ParseException e) {
            e.printStackTrace();
        }
        return -1;
    }

    @Override
    public void doneLogin(LoginResponse loginResponse) {
        try {
            enableViews(false);
            name.setText(loginResponse.getPartnerAccountName());
        } catch (Exception e) {
        }
    }

    @BindingAdapter({"color"})
    public static void setFont(AppCompatButton button, boolean selfOwnedSelected) {
        if (selfOwnedSelected)
            button.setTextColor(button.getResources().getColor(R.color.white));
        else
            button.setTextColor(button.getResources().getColor(R.color.hint_edittext_color));
    }

    @Override
    protected void onStart() {
        super.onStart();
        registerReceiver(mMessageReceiver, new IntentFilter(ConnectivityManager.CONNECTIVITY_ACTION));
    }

    @Override
    protected void onStop() {
        super.onStop();
        unregisterReceiver(mMessageReceiver);
    }


    private BroadcastReceiver mMessageReceiver = new BroadcastReceiver() {
        @Override
        public void onReceive(Context context, Intent intent) {
            boolean noConnectivity = intent.getBooleanExtra(ConnectivityManager
                    .EXTRA_NO_CONNECTIVITY, false);
            if (no_network_layout != null) {
                if (noConnectivity) {
                    no_network_layout.setVisibility(View.VISIBLE);
                } else {
                    no_network_layout.setVisibility(View.GONE);
                }
            }
        }
    };

    @Override
    protected void onSaveInstanceState(Bundle oldInstanceState) {
        super.onSaveInstanceState(oldInstanceState);
        oldInstanceState.clear();
    }
}
