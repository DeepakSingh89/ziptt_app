package com.ziploan.dsaapp;

import androidx.appcompat.app.AlertDialog;
import androidx.appcompat.app.AppCompatActivity;
import com.ziploan.dsaapp.base.extras.network.APIExecutor;
import com.ziploan.dsaapp.model.config.AppConfigModel;
import com.ziploan.dsaapp.model.config.SystemInfo;
import com.ziploan.dsaapp.model.response.loan_list.LoanListResponse;
import com.ziploan.dsaapp.utils.PreferencesManager;
import retrofit2.Call;
import retrofit2.Callback;
import retrofit2.Response;

import android.app.Dialog;
import android.content.ActivityNotFoundException;
import android.content.DialogInterface;
import android.content.Intent;
import android.net.Uri;
import android.os.Bundle;
import android.os.Handler;
import android.view.Window;
import android.view.WindowManager;

import java.util.HashMap;
import java.util.Map;

public class SplashActivity extends AppCompatActivity {
    private final int SPLASH_DISPLAY_LENGTH = 500;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        requestWindowFeature(Window.FEATURE_NO_TITLE);
        this.getWindow().setFlags(WindowManager.LayoutParams.FLAG_FULLSCREEN, WindowManager.LayoutParams.FLAG_FULLSCREEN);
        setContentView(R.layout.activity_splash);
        getSupportActionBar().hide();
        new Handler().postDelayed(new Runnable() {
            @Override
            public void run() {
                getConfigData();
            }
        }, SPLASH_DISPLAY_LENGTH);
    }

    public void getConfigData() {
        Call<AppConfigModel> call = APIExecutor.getAPIService().getConfig();
        call.enqueue(new Callback<AppConfigModel>() {
            @Override
            public void onResponse(Call<AppConfigModel> call, Response<AppConfigModel> response) {
                try {
                    if (response.isSuccessful()
                            && response.body() != null
                            && response.body().getSystemInfo() != null) {
                        if (response.body().getSystemInfo().getForceUpgrade() == 1) {
                            showUpdateAppDialog(response.body().getSystemInfo(), true);
                        } else {
                            if (BuildConfig.VERSION_CODE >= response.body().getSystemInfo().getMinSupportedVersion()) {
                                if (BuildConfig.VERSION_CODE >= response.body().getSystemInfo().getCurrentAppVersion()) {
                                    moveToHome();
                                } else {
                                    showUpdateAppDialog(response.body().getSystemInfo(), false);
                                }
                            } else {
                                showUpdateAppDialog(response.body().getSystemInfo(), true);
                            }
                        }
                    } else {
                        moveToHome();
                    }
                } catch (Exception e){
                    moveToHome();
                }
            }

            @Override
            public void onFailure(Call<AppConfigModel> call, Throwable t) {
                moveToHome();
            }
        });
    }

    private void moveToHome() {
        Intent mainIntent = new Intent(SplashActivity.this, MainActivity.class);
        SplashActivity.this.startActivity(mainIntent);
        SplashActivity.this.finish();
    }

    protected void showUpdateAppDialog(SystemInfo systemInfo, boolean isForce) {
        AlertDialog.Builder builder = new AlertDialog.Builder(this);
        builder.setTitle(getString(R.string.update_app));
        builder.setMessage(systemInfo.getUpgradeMessage());
        builder.setPositiveButton(getString(R.string.update), new DialogInterface.OnClickListener() {
            @Override
            public void onClick(DialogInterface dialog, int which) {
                openPlayStoreToUpdate();
//                if(!isForce)
//                    finish();
            }
        });

        if (systemInfo.getForceUpgrade() == 1) {
            builder.setCancelable(false);
        } else {
            builder.setCancelable(false);
            if (!isForce) {
                builder.setNegativeButton(getString(R.string.later), new DialogInterface.OnClickListener() {
                    @Override
                    public void onClick(DialogInterface dialogInterface, int i) {
                        moveToHome();
                    }
                });
            }
        }

        Dialog dialog = builder.create();
        if (!isFinishing()) {
            dialog.show();
        }
    }

    private void openPlayStoreToUpdate() {
        Uri uri = Uri.parse("market://details?id=" + getPackageName());
        Intent goToMarket = new Intent(Intent.ACTION_VIEW, uri);
        try {
            startActivity(goToMarket);
        } catch (ActivityNotFoundException e) {
            e.printStackTrace();
        }
    }
}
