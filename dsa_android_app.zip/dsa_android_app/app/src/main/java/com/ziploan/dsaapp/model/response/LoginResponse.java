package com.ziploan.dsaapp.model.response;

import com.google.gson.annotations.Expose;
import com.google.gson.annotations.SerializedName;

public class LoginResponse {

    @SerializedName("agreement_document")
    @Expose
    private String agreementDocument;
    @SerializedName("token_expiration_time")
    @Expose
    private String tokenExpirationTime;
    @SerializedName("access_token")
    @Expose
    private String accessToken;
    @SerializedName("partner_status")
    @Expose
    private PartnerStatus partnerStatus;
    @SerializedName("partner_account_name")
    @Expose
    private String partnerAccountName;
    @SerializedName("result")
    @Expose
    private Integer result;
    @SerializedName("show_earned_commission")
    @Expose
    private Integer showEarnedCommission;
    @SerializedName("partner_id")
    @Expose
    private String partnerId;

    public String getAgreementDocument() {
        return agreementDocument;
    }

    public void setAgreementDocument(String agreementDocument) {
        this.agreementDocument = agreementDocument;
    }

    public String getTokenExpirationTime() {
        return tokenExpirationTime;
    }

    public void setTokenExpirationTime(String tokenExpirationTime) {
        this.tokenExpirationTime = tokenExpirationTime;
    }

    public String getAccessToken() {
        return accessToken;
    }

    public void setAccessToken(String accessToken) {
        this.accessToken = accessToken;
    }

    public PartnerStatus getPartnerStatus() {
        return partnerStatus;
    }

    public void setPartnerStatus(PartnerStatus partnerStatus) {
        this.partnerStatus = partnerStatus;
    }

    public String getPartnerAccountName() {
        return partnerAccountName;
    }

    public void setPartnerAccountName(String partnerAccountName) {
        this.partnerAccountName = partnerAccountName;
    }

    public Integer getResult() {
        return result;
    }

    public void setResult(Integer result) {
        this.result = result;
    }

    public Integer getShowEarnedCommission() {
        return showEarnedCommission;
    }

    public void setShowEarnedCommission(Integer showEarnedCommission) {
        this.showEarnedCommission = showEarnedCommission;
    }

    public String getPartnerId() {
        return partnerId;
    }

    public void setPartnerId(String partnerId) {
        this.partnerId = partnerId;
    }

}
