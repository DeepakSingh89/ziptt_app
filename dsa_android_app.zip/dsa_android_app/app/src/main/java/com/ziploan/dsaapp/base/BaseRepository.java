package com.ziploan.dsaapp.base;

public class BaseRepository {
}
