package com.ziploan.dsaapp.utils;


import com.google.android.material.textfield.TextInputLayout;

import androidx.databinding.BindingAdapter;
import androidx.databinding.ObservableBoolean;
import androidx.databinding.ObservableField;

public class LocalBindingAdapters {

    @BindingAdapter({"errors","invalid"})
    public static void errorMethod(TextInputLayout pEditText, ObservableField<String> textErrors, ObservableBoolean invalid) {
        if(invalid.get()) {
            pEditText.setError(textErrors.get());
            pEditText.requestFocus();
        } else {
            pEditText.setError(null);
        }
    }
}
