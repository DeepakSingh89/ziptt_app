package com.ziploan.dsaapp.base;

import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.TextView;

import java.util.ArrayList;
import java.util.List;

import androidx.annotation.LayoutRes;
import androidx.annotation.NonNull;
import androidx.databinding.DataBindingUtil;
import androidx.databinding.ViewDataBinding;
import androidx.recyclerview.widget.RecyclerView;
import com.ziploan.dsaapp.BR;
import com.ziploan.dsaapp.R;

public abstract class BindingAppAdapter<T> extends RecyclerView.Adapter<RecyclerView.ViewHolder> {
    private OnViewHolderClick<T> mListener;

    public static final int NORMAL_LAYOUT = 226;
    public static final int GROUP_HEADER = 342;

    public abstract int getLayout();

    @LayoutRes
    protected int groupLayoutRes;

    private List<T> items;


    public BindingAppAdapter(OnViewHolderClick<T> listener, @LayoutRes int groupLayoutRes) {
        this(listener);
        this.groupLayoutRes = groupLayoutRes;
    }

    public BindingAppAdapter(OnViewHolderClick<T> listener) {
        this.mListener = listener;
    }

    public void setItems(List<T> _items) {
        items = new ArrayList<>(_items);
        notifyDataSetChanged();
    }

    public void addItems(List<T> _items) {
        if (items == null)
            items = new ArrayList<>(_items);
        else {
            items.addAll(new ArrayList<>(_items));
        }
        notifyDataSetChanged();
    }

    public void removeItem(int position){
        if(items.size() > 0) {
            items.remove(position);
            notifyItemRemoved(position);
        }
    }


    public void notifyItem(int i){
        notifyItemChanged(i);
    }

    public void clear() {
        items = null;
        notifyDataSetChanged();
    }

    public void changedItem(int i, T item) {
        items.remove(i);
        items.add(i, item);
        notifyItemChanged(i);
    }

    public List<T> getItems() {
        return items;
    }

    @NonNull
    @Override
    public RecyclerView.ViewHolder onCreateViewHolder(@NonNull ViewGroup viewGroup, int i) {
        if(i == NORMAL_LAYOUT) {
            ViewDataBinding bind = DataBindingUtil.bind(LayoutInflater.from(viewGroup.getContext())
                    .inflate(getLayout(), viewGroup, false));
            if (bind != null) {
                return new ViewHolder<>(bind);
            } else {
                return null;
            }
        } else if (i == GROUP_HEADER) {
            return new GroupViewHolder((TextView) LayoutInflater
                    .from(viewGroup.getContext()).inflate(groupLayoutRes, viewGroup, false));
        }
        else
            return null;
    }

    @Override
    public void onBindViewHolder(@NonNull RecyclerView.ViewHolder viewHolder, int i) {
        if (viewHolder instanceof ViewHolder) {
            ViewHolder bindingViewholder = (ViewHolder) viewHolder;
            final T model = items.get(i);
            bindingViewholder.getBinding().setVariable(BR.model, model);
            bindingViewholder.getBinding().executePendingBindings();
            bindingViewholder.getBinding().getRoot().setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View view) {
                    if (mListener != null) {
                        int position = bindingViewholder.getAdapterPosition();
                        mListener.onClick(view, position, items.get(i));
                    }
                }
            });
            View view_btn = bindingViewholder.getBinding().getRoot().findViewById(R.id.view);
            if (view_btn != null) {
                view_btn.setOnClickListener(new View.OnClickListener() {
                    @Override
                    public void onClick(View view) {
                        if (mListener != null) {
                            int position = bindingViewholder.getAdapterPosition();
                            mListener.onClick(view, position, items.get(i));
                        }
                    }
                });
            }

            View delete_btn = bindingViewholder.getBinding().getRoot().findViewById(R.id.delete);
            if (delete_btn != null) {
                delete_btn.setOnClickListener(new View.OnClickListener() {
                    @Override
                    public void onClick(View view) {
                        if (mListener != null) {
                            int position = bindingViewholder.getAdapterPosition();
                            mListener.onClick(view, position, items.get(i));
                        }
                    }
                });
            }
        } else if (viewHolder instanceof GroupViewHolder) {
            ((GroupViewHolder) viewHolder).bind(items.get(i).toString());
        }
    }

    @Override
    public int getItemViewType(int position) {
        return NORMAL_LAYOUT;
    }

    @Override
    public int getItemCount() {
        return items != null ? items.size() : 0;
    }

    public static class ViewHolder<V extends ViewDataBinding> extends RecyclerView.ViewHolder {
        private V v;

        public ViewHolder(V v) {
            super(v.getRoot());
            this.v = v;
        }

        public V getBinding() {
            return v;
        }
    }

    public interface OnViewHolderClick<T> {
        void onClick(View view, int position, T item);
    }

    protected static class GroupViewHolder extends RecyclerView.ViewHolder {
        @NonNull
        private final TextView tvTitle;

        public GroupViewHolder(@NonNull TextView tvTitle) {
            super(tvTitle);
            this.tvTitle = tvTitle;
        }

        public void bind(String group) {
            tvTitle.setText(group);
        }
    }

    public static class Group {
        @NonNull
        private final String title;

        public Group(@NonNull String title) {
            this.title = title;
        }

        @NonNull
        public String getTitle() {
            return title;
        }
    }
}
