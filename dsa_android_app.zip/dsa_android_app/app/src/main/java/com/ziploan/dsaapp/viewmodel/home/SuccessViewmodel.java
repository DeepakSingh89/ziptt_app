package com.ziploan.dsaapp.viewmodel.home;

import android.content.Context;
import android.text.TextUtils;
import android.view.View;

import androidx.databinding.ObservableBoolean;
import androidx.databinding.ObservableField;
import com.ziploan.dsaapp.R;
import com.ziploan.dsaapp.base.BaseViewModel;
import com.ziploan.dsaapp.fragments.home.HomeFragment;
import com.ziploan.dsaapp.utils.NavController;

public class SuccessViewmodel extends BaseViewModel implements View.OnClickListener {

    public ObservableBoolean ShowError = new ObservableBoolean();
    public ObservableField<String>  ThanksYouText = new ObservableField<>();
    public ObservableField<String>  ApplicationStatusMessage = new ObservableField<>();
    public ObservableField<String>  ApplicationExtraDescriptionText = new ObservableField<>();

    public SuccessViewmodel(boolean success, String message, Context context){
        if(!success) {
            ShowError.set(true);
            ThanksYouText.set(context.getString(R.string.error_text));
            if(!TextUtils.isEmpty(message)){
                ApplicationStatusMessage.set(message);
            } else {
                ApplicationStatusMessage.set(context.getString(R.string.error_status_text));
            }
            ApplicationExtraDescriptionText.set(context.getString(R.string.error_long_text));
        } else {
            ShowError.set(false);
            ThanksYouText.set(context.getString(R.string.thank_you));
            ApplicationStatusMessage.set(context.getString(R.string.success_application_message));
            ApplicationExtraDescriptionText.set(context.getString(R.string.success_long_text));
        }
    }

    @Override
    public void onClick(View view) {
        if(view.getId() == R.id.go_back){
            NavController.getInstance().clearBack();
            NavController.getInstance().addFragment(HomeFragment.newInstance(),false);
        }
    }
}
