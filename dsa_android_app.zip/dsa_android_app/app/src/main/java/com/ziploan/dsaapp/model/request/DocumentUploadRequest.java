package com.ziploan.dsaapp.model.request;

import com.google.gson.annotations.Expose;
import com.google.gson.annotations.SerializedName;

import java.util.List;

public class DocumentUploadRequest {
    @SerializedName("uploaded_file")
    @Expose
    private List<Object> uploadedFile = null;
    @SerializedName("fname")
    @Expose
    private String fname;
    @SerializedName("env")
    @Expose
    private String env;
    @SerializedName("loan_request_id")
    @Expose
    private String loanRequestId;
    @SerializedName("bucket_id")
    @Expose
    private Integer bucketId;
    @SerializedName("persist")
    @Expose
    private Boolean persist;
    @SerializedName("bank_type")
    @Expose
    private Integer bankType;

    public List<Object> getUploadedFile() {
        return uploadedFile;
    }

    public void setUploadedFile(List<Object> uploadedFile) {
        this.uploadedFile = uploadedFile;
    }

    public String getFname() {
        return fname;
    }

    public void setFname(String fname) {
        this.fname = fname;
    }

    public String getEnv() {
        return env;
    }

    public void setEnv(String env) {
        this.env = env;
    }

    public String getLoanRequestId() {
        return loanRequestId;
    }

    public void setLoanRequestId(String loanRequestId) {
        this.loanRequestId = loanRequestId;
    }

    public Integer getBucketId() {
        return bucketId;
    }

    public void setBucketId(Integer bucketId) {
        this.bucketId = bucketId;
    }

    public Boolean getPersist() {
        return persist;
    }

    public void setPersist(Boolean persist) {
        this.persist = persist;
    }

    public Integer getBankType() {
        return bankType;
    }

    public void setBankType(Integer bankType) {
        this.bankType = bankType;
    }
}
