package com.ziploan.dsaapp.fragments.home;

import android.os.Bundle;
import android.view.View;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.lifecycle.ViewModel;
import androidx.lifecycle.ViewModelProvider;
import androidx.lifecycle.ViewModelProviders;
import com.ziploan.dsaapp.MyApplication;
import com.ziploan.dsaapp.R;
import com.ziploan.dsaapp.base.BaseRepository;
import com.ziploan.dsaapp.base.BindingFragment;
import com.ziploan.dsaapp.databinding.MobileVerificationLayoutBinding;
import com.ziploan.dsaapp.utils.KeyboardUtils;
import com.ziploan.dsaapp.viewmodel.home.MobileNumberViewModel;

public class MobileNumberFramgnet extends BindingFragment<MobileVerificationLayoutBinding, MobileNumberViewModel, BaseRepository> {

    public static MobileNumberFramgnet newInstance() {
        MobileNumberFramgnet fragment = new MobileNumberFramgnet();
        Bundle args = new Bundle();
        fragment.setArguments(args);
        return fragment;
    }
    @Override
    public int getLayoutId() {
        return R.layout.pan_verification_layout;
    }
    @Override
    public void onResume() {
        super.onResume();
        mainActivity.get().getSupportActionBar().setTitle(getString(R.string.mobile_number_title));
    }

    @Override
    public void onPause() {
        super.onPause();
        KeyboardUtils.hideKeyboard(mainActivity.get());
    }

    @Override
    public MobileNumberViewModel getViewModel(BaseRepository repository) {
        return  ViewModelProviders.of(this, new ViewModelProvider.Factory() {
            @NonNull
            @Override
            public <T extends ViewModel> T create(@NonNull Class<T> modelClass) {
                return (T)new MobileNumberViewModel();
            }
        }).get(MobileNumberViewModel.class);
    }


    @Override
    public BaseRepository getRepository() {
        return null;
    }

    @Override
    public void onViewCreated(@NonNull View view, @Nullable Bundle savedInstanceState) {
        super.onViewCreated(view, savedInstanceState);
        MyApplication.LOAN_REQ_ID = "";
    }
}
