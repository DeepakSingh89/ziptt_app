package com.ziploan.dsaapp.utils;

import android.content.Context;

import com.google.firebase.analytics.FirebaseAnalytics;

public class FirebaseUtils {

    private FirebaseAnalytics mFirebaseAnalytics;

    private static FirebaseUtils _instance;

    public static void init(Context context){
        if(_instance == null)
            _instance = new FirebaseUtils(context);
    }

    public static FirebaseUtils getInstance(){
        return _instance;
    }



    private FirebaseUtils(Context context){
        mFirebaseAnalytics = FirebaseAnalytics.getInstance(context);
    }
}
