package com.ziploan.dsaapp.utils;

import android.Manifest;
import android.app.Activity;
import android.content.Context;
import android.content.IntentSender;
import android.content.pm.PackageManager;
import android.location.Location;

import com.google.android.gms.common.api.ResolvableApiException;
import com.google.android.gms.location.FusedLocationProviderClient;
import com.google.android.gms.location.LocationCallback;
import com.google.android.gms.location.LocationRequest;
import com.google.android.gms.location.LocationResult;
import com.google.android.gms.location.LocationServices;
import com.google.android.gms.location.LocationSettingsRequest;
import com.google.android.gms.location.LocationSettingsResponse;
import com.google.android.gms.location.SettingsClient;
import com.google.android.gms.tasks.OnFailureListener;
import com.google.android.gms.tasks.OnSuccessListener;
import com.google.android.gms.tasks.Task;

import androidx.annotation.NonNull;
import androidx.core.content.ContextCompat;

public class LocationUpdates {
    public static final int REQUEST_CHECK_SETTINGS = 1012;
    private Context context;
    private FusedLocationProviderClient mFusedLocationClient;
    private LocationUpdatesCallback locationUpdatesCallback;
    private LocationCallback mLocationCallback;

    private LocationUpdates(Context context, LocationUpdatesCallback _locationUpdatesCallback) {
        this.context = context;
        mFusedLocationClient = LocationServices.getFusedLocationProviderClient(context);
        locationUpdatesCallback = _locationUpdatesCallback;
        mLocationCallback = new LocationCallback() {
            @Override
            public void onLocationResult(LocationResult locationResult) {
                if (locationResult == null) {
                    return;
                }
                for (Location location : locationResult.getLocations()) {
                    if (location != null) {
                        if (locationUpdatesCallback != null)
                            locationUpdatesCallback.onLocationUpdate(location);

                        stopLocationUpdates();
                    }
                }
            };
        };
    }

    public void getLastKnownLocation() {
        if (ContextCompat.checkSelfPermission(context, Manifest.permission.ACCESS_FINE_LOCATION)
                != PackageManager.PERMISSION_GRANTED) {
            if (locationUpdatesCallback != null)
                locationUpdatesCallback.onLocationUpdate(null);
            return;
        }
        mFusedLocationClient.getLastLocation().addOnSuccessListener(new OnSuccessListener<Location>() {
            @Override
            public void onSuccess(Location location) {
                if (location != null) {
                    if (locationUpdatesCallback != null)
                        locationUpdatesCallback.onLocationUpdate(location);
                }
            }
        });
    }

    public LocationRequest checkSettingsAndRequest(){
        LocationRequest mLocationRequest = new LocationRequest();
        mLocationRequest.setInterval(2 * 60 * 1000);
        mLocationRequest.setFastestInterval(2 * 60 * 1000);
        mLocationRequest.setPriority(LocationRequest.PRIORITY_HIGH_ACCURACY);
        mLocationRequest.setNumUpdates(1);
        mLocationRequest.setExpirationDuration(60 * 1000);
        LocationSettingsRequest.Builder builder = new LocationSettingsRequest.Builder()
                .addLocationRequest(mLocationRequest);
        SettingsClient client = LocationServices.getSettingsClient(context);
        Task<LocationSettingsResponse> task = client.checkLocationSettings(builder.build());

        task.addOnSuccessListener(new OnSuccessListener<LocationSettingsResponse>() {
            @Override
            public void onSuccess(LocationSettingsResponse locationSettingsResponse) {
                //getLastKnownLocation();
                // startLocationUpdates();
            }
        });

        task.addOnFailureListener(new OnFailureListener() {
            @Override
            public void onFailure(@NonNull Exception e) {
                if (e instanceof ResolvableApiException) {
                    try {
                        ResolvableApiException resolvable = (ResolvableApiException) e;
                        resolvable.startResolutionForResult((Activity) context,
                                REQUEST_CHECK_SETTINGS);
                    } catch (IntentSender.SendIntentException sendEx) { }
                }
            }
        });
        return mLocationRequest;
    }

    public void startLocationUpdates() {
        if (ContextCompat.checkSelfPermission(context, Manifest.permission.ACCESS_FINE_LOCATION)
                != PackageManager.PERMISSION_GRANTED) {
            if (locationUpdatesCallback != null)
                locationUpdatesCallback.onLocationUpdate(null);
            return;
        }

        mFusedLocationClient.requestLocationUpdates(checkSettingsAndRequest(),
                mLocationCallback,
                null);
    }

    private void stopLocationUpdates() {
        mFusedLocationClient.removeLocationUpdates(mLocationCallback);
    }

    public interface LocationUpdatesCallback {
        void onLocationUpdate(Location location);
    }

    public static class LocationBuilder{
        private Context mContext;
        private LocationUpdatesCallback _locationUpdatesCallback;

        public LocationBuilder setContext(Context context){
            this.mContext = context;
            return this;
        }

        public LocationBuilder setLocationUpdatesCallback(LocationUpdatesCallback locationUpdatesCallback){
            this._locationUpdatesCallback = locationUpdatesCallback;
            return this;
        }

        public LocationUpdates build(){
            return new LocationUpdates(mContext,_locationUpdatesCallback);
        }
    }
}

