package com.ziploan.dsaapp.utils.permissons;

public abstract class Func {
    protected abstract void call();
}

